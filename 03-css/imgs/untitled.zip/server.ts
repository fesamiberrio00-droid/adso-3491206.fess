import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";
import { STATIC_ROADMAPS } from "./src/data/roadmapsData";
import { STATIC_MODULES } from "./src/data";
import bcrypt from "bcrypt";
import crypto from "node:crypto";
import { testConnection, getPool, query } from "./src/db";

dotenv.config();

const app = express();
app.use(express.json());

const PORT = Number(process.env.PORT) || 3001;

const IS_PRODUCTION = process.env.NODE_ENV === "production";
const RAW_SESSION_SECRET = (process.env.SESSION_SECRET || "").trim();

if (IS_PRODUCTION && RAW_SESSION_SECRET.length < 32) {
  throw new Error(
    "[NODO Auth] Error crítico de configuración: SESSION_SECRET es obligatorio en producción y debe tener al menos 32 caracteres."
  );
}

let SESSION_SECRET = RAW_SESSION_SECRET;
if (!SESSION_SECRET) {
  SESSION_SECRET = crypto.randomBytes(32).toString("hex");
  console.warn(
    "[NODO Auth] ⚠️ SESSION_SECRET no definido en entorno local; usando clave temporal por proceso (las sesiones no persistirán tras reiniciar)."
  );
} else if (!IS_PRODUCTION && SESSION_SECRET.length < 32) {
  console.warn(
    "[NODO Auth] ⚠️ SESSION_SECRET tiene menos de 32 caracteres; se recomienda una clave de al menos 32 caracteres."
  );
}

const ALLOW_DEV_OTP_PREVIEW =
  !IS_PRODUCTION &&
  (process.env.ALLOW_DEV_OTP_PREVIEW || "").trim().toLowerCase() === "true";

const SESSION_TTL_MS = 24 * 60 * 60 * 1000;
const MIN_PASSWORD_LENGTH = 8;
const MAX_PASSWORD_BYTES = 72;

async function safeRollback(client: any): Promise<void> {
  if (!client) return;
  try {
    await client.query("ROLLBACK;");
  } catch (rollbackErr: any) {
    console.error("[NODO DB] Error controlado ejecutando ROLLBACK:", rollbackErr?.message || rollbackErr);
  }
}

function validateRegistrationPassword(
  password: unknown
): { ok: true; value: string } | { ok: false; error: string } {
  if (typeof password !== "string" || password.trim().length === 0) {
    return { ok: false, error: "Debes ingresar una contraseña válida." };
  }
  if (password.length < MIN_PASSWORD_LENGTH) {
    return {
      ok: false,
      error: `La contraseña debe tener al menos ${MIN_PASSWORD_LENGTH} caracteres.`
    };
  }
  if (Buffer.byteLength(password, "utf8") > MAX_PASSWORD_BYTES) {
    return {
      ok: false,
      error: `La contraseña no debe superar los ${MAX_PASSWORD_BYTES} bytes.`
    };
  }
  return { ok: true, value: password };
}

function validateLoginPassword(
  password: unknown
): { ok: true; value: string } | { ok: false; error: string } {
  if (typeof password !== "string" || password.length === 0) {
    return { ok: false, error: "Introduce correo y contraseña." };
  }
  if (Buffer.byteLength(password, "utf8") > MAX_PASSWORD_BYTES) {
    return {
      ok: false,
      error: `La contraseña excede el límite máximo permitido de ${MAX_PASSWORD_BYTES} bytes.`
    };
  }
  return { ok: true, value: password };
}

interface SessionPayload {
  userId: string;
  email: string;
  iat: number;
  exp: number;
}

function createSessionToken(userId: string, email: string): string {
  const now = Date.now();
  const payload: SessionPayload = {
    userId,
    email: email.trim().toLowerCase(),
    iat: now,
    exp: now + SESSION_TTL_MS
  };
  const payloadB64 = Buffer.from(JSON.stringify(payload), "utf8").toString("base64url");
  const signatureB64 = crypto
    .createHmac("sha256", SESSION_SECRET)
    .update(payloadB64)
    .digest("base64url");
  return `${payloadB64}.${signatureB64}`;
}

function verifySessionToken(token: string): SessionPayload | null {
  try {
    const parts = token.split(".");
    if (parts.length !== 2) return null;
    const [payloadB64, sigB64] = parts;
    if (!payloadB64 || !sigB64) return null;

    const expectedSigB64 = crypto
      .createHmac("sha256", SESSION_SECRET)
      .update(payloadB64)
      .digest("base64url");

    const sigBuf = Buffer.from(sigB64, "utf8");
    const expectedBuf = Buffer.from(expectedSigB64, "utf8");
    if (sigBuf.length !== expectedBuf.length || !crypto.timingSafeEqual(sigBuf, expectedBuf)) {
      return null;
    }

    const decoded = JSON.parse(Buffer.from(payloadB64, "base64url").toString("utf8"));
    if (
      !decoded ||
      typeof decoded.userId !== "string" ||
      typeof decoded.email !== "string" ||
      typeof decoded.exp !== "number" ||
      decoded.exp <= Date.now()
    ) {
      return null;
    }
    return decoded as SessionPayload;
  } catch {
    return null;
  }
}

function extractBearerToken(req: express.Request): string | null {
  const authHeader = req.headers.authorization;
  if (!authHeader || typeof authHeader !== "string") return null;
  const match = authHeader.match(/^Bearer\s+(.+)$/i);
  return match ? match[1].trim() : null;
}

function verifyUserOwnership(
  req: express.Request,
  targetEmail: string,
  expectedUserId?: string
): { ok: true; session: SessionPayload } | { ok: false; status: number; error: string } {
  const token = extractBearerToken(req);
  if (!token) {
    return {
      ok: false,
      status: 401,
      error: "Sesión no autenticada. Inicia sesión para consultar o modificar tu información."
    };
  }

  const session = verifySessionToken(token);
  if (!session) {
    return {
      ok: false,
      status: 401,
      error: "Tu sesión ha expirado o es inválida. Inicia sesión nuevamente."
    };
  }

  const normalizedTarget = targetEmail.trim().toLowerCase();
  if (session.email.trim().toLowerCase() !== normalizedTarget) {
    return {
      ok: false,
      status: 403,
      error: "Acceso denegado: solo puedes consultar o modificar tu propia información."
    };
  }

  if (expectedUserId && session.userId !== expectedUserId) {
    return {
      ok: false,
      status: 403,
      error: "Acceso denegado: identidad de usuario inconsistente con la sesión activa."
    };
  }

  return { ok: true, session };
}

// Initialize server-side Gemini AI gracefully as recommended
let ai: GoogleGenAI | null = null;
const API_KEY = process.env.GEMINI_API_KEY ? process.env.GEMINI_API_KEY.trim() : undefined;

if (API_KEY && API_KEY !== "MY_GEMINI_API_KEY") {
  try {
    ai = new GoogleGenAI({
      apiKey: API_KEY,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
    console.log("✅ Gemini AI configurado correctamente en el servidor con la clave suministrada.");
  } catch (error) {
    console.error("⚠️ Error inicializando Gemini SDK:", error);
  }
} else {
  console.log("⚠️ GEMINI_API_KEY no detectado o en valor default. Usando lógica simulada/fallbacks.");
}

// Resilient Gemini Invocation with automatic fast-model failover
async function callGeminiWithFallback(contents: string, responseSchema?: any): Promise<string | null> {
  if (!ai) return null;
  const models = ["gemini-3.1-flash-lite", "gemini-3.5-flash-lite", "gemini-3-flash-preview", "gemini-3.8-flash"];
  for (const model of models) {
    try {
      const config: any = { responseMimeType: "application/json" };
      if (responseSchema) {
        config.responseSchema = responseSchema;
      }
      const response = await ai.models.generateContent({
        model,
        contents,
        config
      });
      if (response && response.text) {
        console.log(`[Gemini] Llamada exitosa usando modelo: ${model}`);
        return response.text;
      }
    } catch (err: any) {
      console.warn(`[Gemini] Error con modelo ${model}:`, err.message || err.status);
    }
  }
  return null;
}

// Resilient Gemini Text Generation for Conversational Tutor
async function callGeminiText(prompt: string, systemInstruction?: string): Promise<string | null> {
  if (!ai) return null;
  const models = ["gemini-2.5-flash", "gemini-3.8-flash", "gemini-3.1-flash-lite"];
  for (const model of models) {
    try {
      const config: any = {};
      if (systemInstruction) {
        config.systemInstruction = systemInstruction;
      }
      
      const generatePromise = ai.models.generateContent({
        model,
        contents: prompt,
        config
      });

      // 7.5-second timeout per model
      const timeoutPromise = new Promise<null>((_, reject) => {
        setTimeout(() => reject(new Error("Timeout Gemini request")), 7500);
      });

      const response: any = await Promise.race([generatePromise, timeoutPromise]);
      if (response && response.text) {
        console.log(`[Gemini Tutor] Respuesta generada exitosamente con modelo: ${model}`);
        return response.text;
      }
    } catch (err: any) {
      console.warn(`[Gemini Tutor] Intento con modelo ${model}:`, err.message || err.status);
    }
  }
  return null;
}

// In-Memory Database for simplicity and local persistence across routes
const USERS_DB: { [email: string]: any } = {};

// Default initial question sets for fallback
const STATIC_FALLBACK_QUESTIONS: { [moduloId: string]: any[] } = {
  logica: [
    {
      id: "ai_log_1",
      type: "multiple_choice",
      difficulty: "basico",
      title: "Variables en Código",
      description: "¿Qué declaración almacena correctamente la suma de dos variables 'a' y 'b'?",
      options: [
        { id: "A", text: "let total = a + b;" },
        { id: "B", text: "total a + b = let;" },
        { id: "C", text: "define a + b en total;" },
        { id: "D", text: "a + b = total;" }
      ],
      correctOptionId: "A",
      explanation: "Utiliza el operador de asignación (=) para almacenar la suma del lado izquierdo."
    },
    {
      id: "ai_log_2",
      type: "multiple_choice",
      difficulty: "basico",
      title: "Control de Flujo",
      description: "¿Qué bucle se ejecuta al menos una vez antes de verificar la condición?",
      options: [
        { id: "A", text: "Bucle for" },
        { id: "B", text: "Bucle while" },
        { id: "C", text: "Bucle do-while" },
        { id: "D", text: "Estructura switch" }
      ],
      correctOptionId: "C",
      explanation: "El bucle do-while ejecuta su bloque de código y evalúa la condición al final."
    },
    {
      id: "ai_log_3",
      type: "multiple_choice",
      difficulty: "intermedio",
      title: "Comparadores Estrictos",
      description: "En JavaScript y lenguajes afines, ¿cuál es la diferencia clave entre '==' y '==='?",
      options: [
        { id: "A", text: "No hay diferencia real, son sinónimos absolutos." },
        { id: "B", text: "'==' realiza coerción de tipos; '===' valida de forma estricta valor y tipo." },
        { id: "C", text: "'===' es un operador exclusivo de sumas complejas." },
        { id: "D", text: "'==' es más seguro y moderno." }
      ],
      correctOptionId: "B",
      explanation: "=== no convierte tipos. Por ejemplo, 5 === '5' es false, mientras que 5 == '5' es true."
    },
    {
      id: "ai_log_4",
      type: "coding",
      difficulty: "intermedio",
      title: "Práctica Interactiva: Filtro Positivo",
      description: "Escribe una función interactiva en tiempo real `esPositivo(num)` que retorne `true` si el número es estrictamente mayor que cero, y `false` en caso contrario.",
      initialCode: "function esPositivo(num) {\n  // Tu código aquí\n  \n}",
      testCases: [
        { id: "tc_ai1", input: "5", codeCheck: "esPositivo(5)", expectedOutput: "true" },
        { id: "tc_ai2", input: "-2", codeCheck: "esPositivo(-2)", expectedOutput: "false" }
      ],
      explanation: "Implementa una verificación lineal con num > 0."
    },
    {
      id: "ai_log_5",
      type: "coding",
      difficulty: "avanzado",
      title: "Desafío Avanzado: Multiplicador Total",
      description: "Crea una función llamada `multiplicarRango(inicio, fin)` que multiplique secuencialmente todos los números enteros entre 'inicio' y 'fin' (inclusive). Ejemplo: multiplicarRango(2, 4) es 2 * 3 * 4 = 24.",
      initialCode: "function multiplicarRango(inicio, fin) {\n  // Algoritmo aquí\n  \n}",
      testCases: [
        { id: "tc_ai3", input: "(2, 4)", codeCheck: "multiplicarRango(2, 4)", expectedOutput: "24" },
        { id: "tc_ai4", input: "(1, 5)", codeCheck: "multiplicarRango(1, 5)", expectedOutput: "120" }
      ],
      explanation: "Usa un acumulador inicializado en 1 y un for loop que multiplique desde inicio hasta fin."
    }
  ]
};

// ==================== API ENDPOINTS ====================

// Check AI status
app.get("/api/ai/status", (req, res) => {
  res.json({
    configured: Boolean(API_KEY && API_KEY !== "MY_GEMINI_API_KEY"),
    active: Boolean(ai),
    models: ["gemini-3.1-flash-lite", "gemini-3.5-flash-lite", "gemini-3-flash-preview", "gemini-3.8-flash"]
  });
});

// Check Database connection status (development only)
app.get("/api/db/status", async (_req, res) => {
  if (process.env.NODE_ENV === "production") {
    return res.status(404).json({ error: "Endpoint no disponible en producción" });
  }

  try {
    const result = await testConnection();
    if (result.ok) {
      console.log(`[NODO DB] Verificación exitosa desde /api/db/status: ${result.message}`);
      return res.status(200).json({
        ok: true,
        status: "connected",
        message: "Conexión exitosa a la base de datos PostgreSQL.",
        serverTime: result.serverTime
      });
    }

    console.warn(`[NODO DB] Verificación fallida desde /api/db/status: ${result.message}`);
    return res.status(503).json({
      ok: false,
      status: "unavailable",
      message: "No se pudo establecer conexión con la base de datos."
    });
  } catch (error: any) {
    console.error("[NODO DB] Error no controlado en /api/db/status:", error?.message || error);
    return res.status(503).json({
      ok: false,
      status: "unavailable",
      message: "Servicio de base de datos no disponible temporalmente."
    });
  }
});

// Auth - Register (Conectado a Neon PostgreSQL con bcrypt, 300 Bits y OTP hasheado)
app.post("/api/auth/register", async (req, res) => {
  const { nombre, correo, edad, password, learningStyleProfile } = req.body;
  if (
    typeof nombre !== "string" ||
    nombre.trim().length === 0 ||
    typeof correo !== "string" ||
    correo.trim().length === 0 ||
    !password
  ) {
    return res.status(400).json({ error: "Faltan campos obligatorios" });
  }

  const passwordCheck = validateRegistrationPassword(password);
  if (!passwordCheck.ok) {
    return res.status(400).json({ error: passwordCheck.error });
  }

  const cleanName = nombre.trim();
  const cleanEmail = correo.trim().toLowerCase();
  const ageNum = Number(edad) || 20;

  let pool;
  try {
    pool = getPool();
  } catch (err: any) {
    console.error("[NODO Auth] Error obteniendo pool de base de datos:", err?.message || err);
    return res.status(503).json({ error: "Servicio de base de datos no configurado en el entorno." });
  }

  let client: any = null;
  let txActive = false;
  try {
    client = await pool.connect();
  } catch (connErr: any) {
    console.error("[NODO Auth] Error conectando a PostgreSQL:", connErr?.message || connErr);
    return res.status(503).json({ error: "No se pudo conectar a la base de datos de Neon." });
  }

  try {
    // 1. Iniciar transacción ACID y serializar registros concurrentes para el mismo correo
    await client.query("BEGIN;");
    txActive = true;

    await client.query("SELECT pg_advisory_xact_lock(hashtext($1));", [cleanEmail]);

    const existing = await client.query(
      `SELECT id, email, verified, deleted_at FROM usuarios WHERE email = $1 FOR UPDATE;`,
      [cleanEmail]
    );

    if (existing.rows.length > 0) {
      const userRow = existing.rows[0];
      await safeRollback(client);
      txActive = false;

      if (userRow.deleted_at) {
        return res.status(400).json({ error: "Esta cuenta fue dada de baja anteriormente." });
      }
      if (userRow.verified) {
        return res.status(409).json({
          error: "El correo ya se encuentra registrado y verificado. Por favor inicia sesión.",
          code: "ACCOUNT_ALREADY_VERIFIED"
        });
      }
      // Cuenta pendiente de verificación: NO sobrescribir datos, NO reiniciar intentos ni invalidar OTP previos
      return res.status(409).json({
        error: "Este correo ya tiene un registro pendiente de verificación. Inicia sesión con tu contraseña o recupera tu código OTP.",
        code: "ACCOUNT_PENDING_VERIFICATION",
        pendingVerification: true,
        email: cleanEmail
      });
    }

    // 2. Correo nuevo: calcular hashes bcrypt y OTP criptográfico
    const saltRounds = 10;
    const passwordHash = await bcrypt.hash(passwordCheck.value, saltRounds);
    const code = crypto.randomInt(100000, 1000000).toString();
    const codeHash = await bcrypt.hash(code, saltRounds);
    const expiresAt = new Date(Date.now() + 15 * 60 * 1000); // 15 minutos

    const insertUserRes = await client.query(
      `INSERT INTO usuarios (
        username, email, password_hash, auth_provider, age,
        streak_days, total_xp, bits_balance, level, title, interests, verified
      ) VALUES ($1, $2, $3, 'local', $4, 1, 50, 300, 1, 'Iniciado de Código 🐍', '[]'::jsonb, false)
      RETURNING id;`,
      [cleanName, cleanEmail, passwordHash, ageNum]
    );
    const userId: string = insertUserRes.rows[0].id;

    // Registrar OTP inicial con hash, vigencia de 15 minutos y límite de 5 intentos
    await client.query(
      `INSERT INTO otps_verificacion (
        user_id, email, codigo_hash, proposito, intentos, max_intentos, expira_en, usado
      ) VALUES ($1, $2, $3, 'registro_verificacion', 0, 5, $4, false);`,
      [userId, cleanEmail, codeHash, expiresAt]
    );

    await client.query("COMMIT;");
    txActive = false;

    // Mantener sincronizado USERS_DB en memoria para compatibilidad de etapas 2 a 6 (sin contraseñas)
    USERS_DB[cleanEmail] = {
      id: userId,
      username: cleanName,
      email: cleanEmail,
      age: ageNum,
      streakDays: 1,
      xpDays: { [new Date().toISOString().split('T')[0]]: 50 },
      totalXP: 50,
      bits: 300,
      level: 1,
      title: "Iniciado de Código 🐍",
      interests: [],
      verified: false,
      learningStyleProfile: learningStyleProfile || null,
      progress: {}
    };

    console.log(`[NODO Auth] 🔐 Registro procesado y OTP emitido (vigencia 15m, máx 5 intentos) para usuario ID: ${userId}`);

    const responsePayload: Record<string, any> = {
      success: true,
      message: "Código de verificación generado. Por favor confirma tu cuenta.",
      email: cleanEmail
    };
    if (ALLOW_DEV_OTP_PREVIEW) {
      responsePayload.code = code;
    }

    return res.json(responsePayload);
  } catch (error: any) {
    if (txActive) {
      await safeRollback(client);
      txActive = false;
    }
    if (error?.code === "23505") {
      return res.status(409).json({
        error: "El correo ya se encuentra registrado. Por favor inicia sesión o recupera tu verificación OTP.",
        code: "ACCOUNT_ALREADY_EXISTS"
      });
    }
    console.error("[NODO Auth] Error en /api/auth/register:", error?.message || error);
    return res.status(500).json({ error: "Error interno al procesar el registro del usuario." });
  } finally {
    if (client) {
      client.release();
      client = null;
    }
  }
});

// Auth - Verification (Validación transaccional con SELECT ... FOR UPDATE contra otps_verificacion en Neon PostgreSQL)
app.post("/api/auth/verify", async (req, res) => {
  const { correo, codigo } = req.body;
  if (typeof correo !== "string" || !correo.trim() || codigo === undefined || codigo === null) {
    return res.status(400).json({ error: "Se requiere correo y código de verificación." });
  }

  const cleanEmail = correo.trim().toLowerCase();
  const cleanCode = codigo.toString().trim();
  if (!cleanCode || cleanCode.length > 32) {
    return res.status(400).json({ error: "El formato del código de verificación no es válido." });
  }

  let pool;
  try {
    pool = getPool();
  } catch (err: any) {
    console.error("[NODO Auth] Error obteniendo pool de base de datos:", err?.message || err);
    return res.status(503).json({ error: "Servicio de base de datos no disponible." });
  }

  let client: any = null;
  let txActive = false;
  try {
    client = await pool.connect();
  } catch (connErr: any) {
    console.error("[NODO Auth] Error conectando a PostgreSQL:", connErr?.message || connErr);
    return res.status(503).json({ error: "No se pudo conectar a la base de datos de Neon." });
  }

  try {
    await client.query("BEGIN;");
    txActive = true;

    // 1. Bloquear registro de usuario en PostgreSQL para evitar carreras concurrentes
    const userRes = await client.query(
      `SELECT id, email, verified, deleted_at FROM usuarios WHERE email = $1 FOR UPDATE;`,
      [cleanEmail]
    );

    if (userRes.rows.length === 0) {
      await safeRollback(client);
      txActive = false;
      return res.status(404).json({ error: "Usuario no registrado." });
    }

    const user = userRes.rows[0];

    if (user.deleted_at) {
      await safeRollback(client);
      txActive = false;
      return res.status(400).json({ error: "Esta cuenta se encuentra inactiva." });
    }

    if (user.verified) {
      await safeRollback(client);
      txActive = false;
      return res.json({ success: true, message: "La cuenta ya se encuentra verificada." });
    }

    // 2. Bloquear el último código OTP activo no usado para serializar los intentos concurrentes
    const otpRes = await client.query(
      `SELECT id, codigo_hash, intentos, max_intentos, expira_en, usado
       FROM otps_verificacion
       WHERE user_id = $1 AND proposito = 'registro_verificacion' AND usado = false
       ORDER BY creado_en DESC
       LIMIT 1
       FOR UPDATE;`,
      [user.id]
    );

    if (otpRes.rows.length === 0) {
      await safeRollback(client);
      txActive = false;
      return res.status(400).json({
        error: "No hay un código de verificación activo o ya fue utilizado. Solicita un nuevo código."
      });
    }

    const otpRecord = otpRes.rows[0];

    // Comprobar expiración (15 minutos)
    if (new Date(otpRecord.expira_en) < new Date()) {
      await safeRollback(client);
      txActive = false;
      return res.status(400).json({
        error: "El código de verificación ha expirado. Solicita un nuevo código para continuar.",
        code: "OTP_EXPIRED"
      });
    }

    // Comprobar límite de 5 intentos
    if (otpRecord.intentos >= otpRecord.max_intentos) {
      await safeRollback(client);
      txActive = false;
      return res.status(400).json({
        error: "Has superado el límite de 5 intentos fallidos. Solicita un nuevo código de verificación.",
        code: "OTP_MAX_ATTEMPTS"
      });
    }

    // Comparar código con hash bcrypt bajo el bloqueo FOR UPDATE de la fila OTP
    const isCodeValid = await bcrypt.compare(cleanCode, otpRecord.codigo_hash);

    if (!isCodeValid) {
      const failUpdate = await client.query(
        `UPDATE otps_verificacion
         SET intentos = intentos + 1
         WHERE id = $1
         RETURNING intentos, max_intentos;`,
        [otpRecord.id]
      );
      await client.query("COMMIT;");
      txActive = false;

      const updatedOtp = failUpdate.rows[0] || {
        intentos: otpRecord.intentos + 1,
        max_intentos: otpRecord.max_intentos
      };
      const remaining = Math.max(0, Number(updatedOtp.max_intentos) - Number(updatedOtp.intentos));

      return res.status(400).json({
        error: remaining === 0
          ? "Código de verificación incorrecto. Has superado el límite de 5 intentos fallidos. Solicita un nuevo código."
          : `Código de verificación incorrecto. Te quedan ${remaining} intentos.`,
        code: remaining === 0 ? "OTP_MAX_ATTEMPTS" : "OTP_INVALID",
        attemptsRemaining: remaining
      });
    }

    // Código válido: Marcar OTP como usado y usuario como verificado en la misma transacción
    await client.query(
      `UPDATE otps_verificacion SET usado = true WHERE id = $1;`,
      [otpRecord.id]
    );
    await client.query(
      `UPDATE usuarios SET verified = true, updated_at = NOW() WHERE id = $1;`,
      [user.id]
    );
    await client.query("COMMIT;");
    txActive = false;

    // Sincronizar estado en memoria para compatibilidad de etapas pendientes
    if (USERS_DB[cleanEmail]) {
      USERS_DB[cleanEmail].verified = true;
    }

    console.log(`[NODO Auth] ✅ Usuario verificado exitosamente en PostgreSQL (ID: ${user.id})`);

    return res.json({
      success: true,
      message: "Cuenta verificada con éxito."
    });
  } catch (error: any) {
    if (txActive) {
      await safeRollback(client);
      txActive = false;
    }
    console.error("[NODO Auth] Error en /api/auth/verify:", error?.message || error);
    return res.status(500).json({ error: "Error interno al verificar la cuenta." });
  } finally {
    if (client) {
      client.release();
      client = null;
    }
  }
});

// Auth - Resend OTP (Recuperación controlada de cuentas pendientes previa validación de contraseña)
const OTP_RESEND_COOLDOWN_SECONDS = 60;
const OTP_RESEND_MAX_PER_HOUR = 5;

app.post("/api/auth/resend-otp", async (req, res) => {
  const { correo, password } = req.body;
  if (typeof correo !== "string" || !correo.trim()) {
    return res.status(400).json({ error: "Se requiere el correo electrónico de la cuenta pendiente." });
  }

  if (typeof password !== "string" || password.length === 0) {
    return res.status(400).json({
      error: "Por seguridad, introduce tu contraseña original para solicitar un nuevo código OTP.",
      code: "PASSWORD_REQUIRED_FOR_RESEND"
    });
  }

  const loginPasswordCheck = validateLoginPassword(password);
  if (!loginPasswordCheck.ok) {
    return res.status(400).json({ error: loginPasswordCheck.error });
  }

  const cleanEmail = correo.trim().toLowerCase();

  let pool;
  try {
    pool = getPool();
  } catch (err: any) {
    console.error("[NODO Auth] Error obteniendo pool de base de datos:", err?.message || err);
    return res.status(503).json({ error: "Servicio de base de datos no disponible." });
  }

  let client: any = null;
  let txActive = false;
  try {
    client = await pool.connect();
  } catch (connErr: any) {
    console.error("[NODO Auth] Error conectando a PostgreSQL:", connErr?.message || connErr);
    return res.status(503).json({ error: "No se pudo conectar a la base de datos de Neon." });
  }

  try {
    await client.query("BEGIN;");
    txActive = true;

    await client.query("SELECT pg_advisory_xact_lock(hashtext($1));", [cleanEmail]);

    // 1. Bloquear usuario en PostgreSQL sin modificar datos personales ni contraseña
    const userRes = await client.query(
      `SELECT id, email, password_hash, verified, deleted_at
       FROM usuarios
       WHERE email = $1
       FOR UPDATE;`,
      [cleanEmail]
    );

    if (userRes.rows.length === 0) {
      await safeRollback(client);
      txActive = false;
      return res.status(404).json({ error: "Usuario no registrado." });
    }

    const user = userRes.rows[0];

    if (user.deleted_at) {
      await safeRollback(client);
      txActive = false;
      return res.status(400).json({ error: "Esta cuenta se encuentra inactiva." });
    }

    if (user.verified) {
      await safeRollback(client);
      txActive = false;
      return res.status(400).json({
        error: "Esta cuenta ya se encuentra verificada. Por favor inicia sesión.",
        code: "ACCOUNT_ALREADY_VERIFIED"
      });
    }

    if (!user.password_hash) {
      await safeRollback(client);
      txActive = false;
      return res.status(401).json({ error: "Esta cuenta requiere autenticación con su proveedor original." });
    }

    // 2. Validar la contraseña original mediante bcrypt antes de regenerar cualquier OTP
    const passwordMatch = await bcrypt.compare(loginPasswordCheck.value, user.password_hash);
    if (!passwordMatch) {
      await safeRollback(client);
      txActive = false;
      return res.status(401).json({
        error: "Contraseña incorrecta. No se generó ningún código OTP nuevo.",
        code: "INVALID_CREDENTIALS"
      });
    }

    // 3. Bloquear OTPs previos del usuario para validar cooldown, límite horario e invalidación controlada
    const otpsRes = await client.query(
      `SELECT id, creado_en, usado
       FROM otps_verificacion
       WHERE user_id = $1 AND proposito = 'registro_verificacion'
       ORDER BY creado_en DESC
       FOR UPDATE;`,
      [user.id]
    );

    const nowMs = Date.now();
    if (otpsRes.rows.length > 0) {
      const latestOtp = otpsRes.rows[0];
      const latestCreatedMs = new Date(latestOtp.creado_en).getTime();
      const elapsedSeconds = Math.floor((nowMs - latestCreatedMs) / 1000);
      if (elapsedSeconds < OTP_RESEND_COOLDOWN_SECONDS) {
        const retryAfterSeconds = Math.max(1, OTP_RESEND_COOLDOWN_SECONDS - elapsedSeconds);
        await safeRollback(client);
        txActive = false;
        return res.status(429).json({
          error: `Debes esperar ${retryAfterSeconds} segundos antes de solicitar un nuevo código OTP.`,
          code: "OTP_COOLDOWN_ACTIVE",
          retryAfterSeconds
        });
      }

      const oneHourAgoMs = nowMs - 60 * 60 * 1000;
      const otpsLastHour = otpsRes.rows.filter(
        (row: any) => new Date(row.creado_en).getTime() >= oneHourAgoMs
      ).length;

      if (otpsLastHour >= OTP_RESEND_MAX_PER_HOUR) {
        await safeRollback(client);
        txActive = false;
        return res.status(429).json({
          error: `Has alcanzado el límite máximo de ${OTP_RESEND_MAX_PER_HOUR} códigos OTP por hora. Inténtalo más tarde.`,
          code: "OTP_RATE_LIMIT_EXCEEDED"
        });
      }
    }

    // 4. Invalidar cualquier OTP activo previo para impedir múltiples códigos activos simultáneos
    await client.query(
      `UPDATE otps_verificacion
       SET usado = true
       WHERE user_id = $1 AND proposito = 'registro_verificacion' AND usado = false;`,
      [user.id]
    );

    // 5. Generar nuevo OTP criptográfico con vigencia de 15 minutos y máximo 5 intentos
    const saltRounds = 10;
    const code = crypto.randomInt(100000, 1000000).toString();
    const codeHash = await bcrypt.hash(code, saltRounds);
    const expiresAt = new Date(nowMs + 15 * 60 * 1000);

    await client.query(
      `INSERT INTO otps_verificacion (
        user_id, email, codigo_hash, proposito, intentos, max_intentos, expira_en, usado
      ) VALUES ($1, $2, $3, 'registro_verificacion', 0, 5, $4, false);`,
      [user.id, cleanEmail, codeHash, expiresAt]
    );

    await client.query("COMMIT;");
    txActive = false;

    console.log(`[NODO Auth] 🔁 OTP regenerado de forma segura (vigencia 15m, máx 5 intentos) para usuario ID: ${user.id}`);

    const responsePayload: Record<string, any> = {
      success: true,
      message: "Se ha emitido un nuevo código de verificación OTP válido por 15 minutos.",
      email: cleanEmail,
      cooldownSeconds: OTP_RESEND_COOLDOWN_SECONDS
    };
    if (ALLOW_DEV_OTP_PREVIEW) {
      responsePayload.code = code;
    }

    return res.json(responsePayload);
  } catch (error: any) {
    if (txActive) {
      await safeRollback(client);
      txActive = false;
    }
    console.error("[NODO Auth] Error en /api/auth/resend-otp:", error?.message || error);
    return res.status(500).json({ error: "Error interno al regenerar el código OTP." });
  } finally {
    if (client) {
      client.release();
      client = null;
    }
  }
});

// Helper de reconstrucción completa del perfil cognitivo desde perfiles_aprendizaje
function reconstructLearningStyleProfile(p: any) {
  if (!p) return null;

  const breakdown = Array.isArray(p.scores_breakdown)
    ? p.scores_breakdown
    : (typeof p.scores_breakdown === 'string' ? JSON.parse(p.scores_breakdown) : []);

  const recommendations = Array.isArray(p.recommendations)
    ? p.recommendations
    : (typeof p.recommendations === 'string' ? JSON.parse(p.recommendations) : []);

  const primaryObj = breakdown.find((s: any) => s.type === p.primary_style) || {
    type: p.primary_style,
    name: p.primary_style,
    shortName: p.primary_style,
    icon: '⚡',
    color: '#39a900',
    accentBg: 'bg-[#39a900]/10',
    accentBorder: 'border-[#39a900]',
    accentText: 'text-[#007832]',
    tagline: 'Estilo de aprendizaje detectado',
    description: '',
    studyTips: [],
    score: 100,
    percentage: Number(p.visual_percentage) || 50
  };

  const secondaryObj = breakdown.find((s: any) => s.type === p.secondary_style) || {
    type: p.secondary_style,
    name: p.secondary_style,
    shortName: p.secondary_style,
    icon: '🎨',
    color: '#00324d',
    accentBg: 'bg-[#00324d]/10',
    accentBorder: 'border-[#00324d]',
    accentText: 'text-[#00324d]',
    tagline: 'Estilo secundario complementario',
    description: '',
    studyTips: [],
    score: 80,
    percentage: Number(p.auditory_percentage) || 40
  };

  return {
    primaryStyle: primaryObj,
    secondaryStyle: secondaryObj,
    visualPercentage: Number(p.visual_percentage) || 0,
    auditoryPercentage: Number(p.auditory_percentage) || 0,
    isBimodal: Boolean(p.is_bimodal),
    bimodalTitle: p.bimodal_title || (p.is_bimodal ? 'Perfil Bimodal: Audiovisual (Visual + Auditivo)' : undefined),
    bimodalDescription: p.bimodal_description || undefined,
    breakdown,
    scoresBreakdown: breakdown,
    recommendations,
    completedAt: p.completed_at ? new Date(p.completed_at).toISOString() : new Date().toISOString()
  };
}

// Helper de reconstrucción del diagnóstico inicial desde diagnosticos_iniciales
function reconstructDiagnostic(d: any) {
  if (!d) return null;

  const answers = Array.isArray(d.answers)
    ? d.answers
    : (typeof d.answers === 'string' ? JSON.parse(d.answers) : []);

  const recommendedPlan = typeof d.recommended_plan === 'string'
    ? JSON.parse(d.recommended_plan)
    : d.recommended_plan;

  return {
    id: d.id,
    answers,
    experienceLevel: d.experience_level,
    studyHours: d.study_hours,
    recommendedPlan,
    createdAt: d.created_at ? new Date(d.created_at).toISOString() : new Date().toISOString()
  };
}

// Auth - Login (Validación relacional en Neon PostgreSQL con bcrypt y recuperación autoritativa de perfil y diagnóstico)
app.post("/api/auth/login", async (req, res) => {
  const { correo, password } = req.body;
  if (typeof correo !== "string" || !correo.trim()) {
    return res.status(400).json({ error: "Introduce correo y contraseña." });
  }

  const loginPasswordCheck = validateLoginPassword(password);
  if (!loginPasswordCheck.ok) {
    return res.status(400).json({ error: loginPasswordCheck.error });
  }

  const cleanEmail = correo.trim().toLowerCase();

  let pool;
  try {
    pool = getPool();
  } catch (err: any) {
    console.error("[NODO Auth] Error obteniendo pool de base de datos:", err?.message || err);
    return res.status(503).json({ error: "Servicio de base de datos no disponible." });
  }

  let client: any = null;
  try {
    client = await pool.connect();
  } catch (connErr: any) {
    console.error("[NODO Auth] Error conectando a PostgreSQL:", connErr?.message || connErr);
    return res.status(503).json({ error: "No se pudo conectar a la base de datos de Neon." });
  }

  try {
    // 1. Buscar usuario en PostgreSQL excluyendo borrados lógicos
    const userRes = await client.query(
      `SELECT
        id, username, email, password_hash, auth_provider, age,
        streak_days, total_xp, bits_balance, level, title, interests, verified, deleted_at
      FROM usuarios
      WHERE email = $1 AND deleted_at IS NULL;`,
      [cleanEmail]
    );

    if (userRes.rows.length === 0) {
      return res.status(404).json({ error: "Tu correo no está registrado o aún no has verificado." });
    }

    const user = userRes.rows[0];

    if (!user.password_hash) {
      return res.status(401).json({ error: "Esta cuenta requiere autenticación a través de su proveedor original." });
    }

    // 2. Comprobar contraseña con bcrypt.compare() ANTES de exponer estado de verificación pendiente
    const passwordMatch = await bcrypt.compare(loginPasswordCheck.value, user.password_hash);
    if (!passwordMatch) {
      return res.status(401).json({ error: "Contraseña incorrecta." });
    }

    // 3. Si la contraseña es válida pero la cuenta está pendiente de verificación OTP, habilitar recuperación controlada
    if (!user.verified) {
      const latestOtpRes = await client.query(
        `SELECT creado_en
         FROM otps_verificacion
         WHERE user_id = $1 AND proposito = 'registro_verificacion'
         ORDER BY creado_en DESC
         LIMIT 1;`,
        [user.id]
      );
      let cooldownRemainingSeconds = 0;
      if (latestOtpRes.rows.length > 0) {
        const elapsedSeconds = Math.floor((Date.now() - new Date(latestOtpRes.rows[0].creado_en).getTime()) / 1000);
        if (elapsedSeconds < OTP_RESEND_COOLDOWN_SECONDS) {
          cooldownRemainingSeconds = Math.max(1, OTP_RESEND_COOLDOWN_SECONDS - elapsedSeconds);
        }
      }

      return res.status(403).json({
        error: "Tu cuenta aún está pendiente de verificación OTP. Ingresa tu código o solicita uno nuevo.",
        code: "ACCOUNT_PENDING_VERIFICATION",
        pendingVerification: true,
        email: cleanEmail,
        cooldownRemainingSeconds
      });
    }

    // 3. Consultar datos autoritativos persistidos en Neon PostgreSQL
    const profileRes = await client.query(
      `SELECT primary_style, secondary_style, visual_percentage, auditory_percentage,
              is_bimodal, bimodal_title, bimodal_description, scores_breakdown, recommendations, completed_at
       FROM perfiles_aprendizaje
       WHERE user_id = $1;`,
      [user.id]
    );

    const diagRes = await client.query(
      `SELECT id, answers, experience_level, study_hours, recommended_plan, created_at
       FROM diagnosticos_iniciales
       WHERE user_id = $1
       ORDER BY created_at DESC
       LIMIT 1;`,
      [user.id]
    );

    const progRes = await client.query(
      `SELECT modulo_id, modality, completed, score, level, completed_at FROM progreso_modulos_usuario WHERE user_id = $1;`,
      [user.id]
    );

    const roadmapProgRes = await client.query(
      `SELECT modulo_id, node_id, completed, score, stars, attempts, last_attempt_at
       FROM progreso_usuario
       WHERE user_id = $1;`,
      [user.id]
    );

    const claimedRes = await client.query(
      `SELECT node_id FROM recompensas_reclamadas WHERE user_id = $1;`,
      [user.id]
    );

    const xpRes = await client.query(
      `SELECT date_slug, xp_amount FROM xp_diario WHERE user_id = $1;`,
      [user.id]
    );

    // Reconstruir perfil cognitivo autoritativo: si no existe en Neon, es estrictamente null (evita que USERS_DB resucite perfiles reiniciados)
    const learningStyleProfile = profileRes.rows.length > 0
      ? reconstructLearningStyleProfile(profileRes.rows[0])
      : null;

    // Reconstruir diagnóstico más reciente y plan recomendado estructurado en JSONB
    const latestDiag = diagRes.rows.length > 0
      ? reconstructDiagnostic(diagRes.rows[0])
      : null;
    const recommendedPlan = latestDiag ? latestDiag.recommendedPlan : null;

    // Reconstruir intereses desde la columna JSONB de usuarios
    let userInterests: string[] = [];
    if (Array.isArray(user.interests)) {
      userInterests = user.interests;
    } else if (typeof user.interests === 'string') {
      try {
        const parsed = JSON.parse(user.interests);
        if (Array.isArray(parsed)) userInterests = parsed;
      } catch {
        userInterests = [];
      }
    }

    // Reconstruir progreso independiente de módulos por modalidad ('offline' e 'ia')
    const progressMap = buildModuleProgressMap(progRes.rows);
    const { roadmapProgress, claimedNodes } = buildRoadmapState(roadmapProgRes.rows, claimedRes.rows);

    // Reconstruir XP diario
    const xpDaysMap: Record<string, number> = {};
    for (const row of xpRes.rows) {
      const slug = row.date_slug ? new Date(row.date_slug).toISOString().split('T')[0] : '';
      if (slug) xpDaysMap[slug] = row.xp_amount;
    }

    // Construir objeto payload respetando exactamente el contrato JSON que espera src/App.tsx
    const userPayload = {
      id: user.id,
      username: user.username,
      email: user.email,
      age: user.age,
      streakDays: user.streak_days,
      streak: user.streak_days,
      totalXP: user.total_xp,
      points: user.total_xp,
      tokens: user.bits_balance,
      level: user.level,
      title: user.title,
      interests: userInterests,
      recommendedPlan,
      learningStyleProfile,
      progress: progressMap,
      roadmapProgress,
      claimedNodes,
      xpDays: xpDaysMap
    };

    // Actualizar USERS_DB con los datos autoritativos de Neon para compatibilidad (sin almacenar contraseñas)
    USERS_DB[cleanEmail] = {
      ...userPayload,
      claimedRoadmapNodes: claimedNodes,
      verified: true
    };

    const sessionToken = createSessionToken(user.id, cleanEmail);

    console.log(`[NODO Auth] 🔑 Inicio de sesión exitoso desde PostgreSQL (ID: ${user.id}) [Perfil cognitivo: ${learningStyleProfile ? 'Activo' : 'Ninguno'}, Plan: ${recommendedPlan ? 'Presente' : 'Ninguno'}]`);

    return res.json({
      success: true,
      sessionToken,
      user: userPayload
    });
  } catch (error: any) {
    console.error("[NODO Auth] Error en /api/auth/login:", error?.message || error);
    return res.status(500).json({ error: "Error interno al iniciar sesión." });
  } finally {
    if (client) {
      client.release();
      client = null;
    }
  }
});

// Update or save learning style profile per user (Conectado a Neon PostgreSQL - perfiles_aprendizaje)
app.post("/api/usuario/estilo-aprendizaje", async (req, res) => {
  const { email, learningStyleProfile } = req.body;
  if (!email) {
    return res.status(400).json({ error: "Se requiere el correo del estudiante." });
  }

  const cleanEmail = (email || "").trim().toLowerCase();
  const ownership = verifyUserOwnership(req, cleanEmail);
  if (!ownership.ok) {
    return res.status(ownership.status).json({ error: ownership.error });
  }

  let pool;
  try {
    pool = getPool();
  } catch (err: any) {
    console.error("[NODO Perfil] Error obteniendo pool de base de datos:", err?.message || err);
    return res.status(503).json({ error: "Servicio de base de datos no configurado." });
  }

  let client;
  try {
    client = await pool.connect();
  } catch (connErr: any) {
    console.error("[NODO Perfil] Error conectando a PostgreSQL:", connErr?.message || connErr);
    return res.status(503).json({ error: "No se pudo conectar a la base de datos de Neon." });
  }

  try {
    // 1. Validar identidad del usuario activo en PostgreSQL
    const userRes = await client.query(
      `SELECT id, username, email, age, streak_days, total_xp, bits_balance, level, title, interests, verified
       FROM usuarios
       WHERE email = $1 AND deleted_at IS NULL;`,
      [cleanEmail]
    );

    if (userRes.rows.length === 0) {
      return res.status(404).json({ error: "Estudiante no registrado o inactivo." });
    }

    const user = userRes.rows[0];
    if (ownership.session.userId !== user.id) {
      return res.status(403).json({ error: "Acceso denegado: solo puedes modificar tu propio perfil de aprendizaje." });
    }

    // 2. Manejo de reinicio de perfil (learningStyleProfile === null)
    if (learningStyleProfile === null) {
      await client.query(
        `DELETE FROM perfiles_aprendizaje WHERE user_id = $1;`,
        [user.id]
      );

      // Sincronizar memoria para compatibilidad de etapas pendientes
      if (USERS_DB[cleanEmail]) {
        USERS_DB[cleanEmail].learningStyleProfile = null;
      }

      console.log(`[NODO Perfil] 🔄 Perfil de aprendizaje reiniciado en PostgreSQL para: ${cleanEmail}`);

      return res.json({
        success: true,
        message: "Perfil de aprendizaje reiniciado con éxito.",
        user: {
          id: user.id,
          username: user.username,
          email: user.email,
          learningStyleProfile: null
        }
      });
    }

    // 3. Validación de estructura del perfil recibido
    if (
      typeof learningStyleProfile !== 'object' ||
      !learningStyleProfile.primaryStyle ||
      !learningStyleProfile.secondaryStyle
    ) {
      return res.status(400).json({
        error: "Estructura del perfil de aprendizaje inválida o incompleta."
      });
    }

    // Lista de estilos permitidos según la restricción del esquema
    const ALLOWED_STYLES = ['practico', 'visual', 'auditivo', 'lectoescritor', 'logico', 'social'];

    const primaryStyleRaw = (learningStyleProfile.primaryStyle.type || '').toString().toLowerCase();
    const secondaryStyleRaw = (learningStyleProfile.secondaryStyle.type || '').toString().toLowerCase();

    const primaryStyle = ALLOWED_STYLES.includes(primaryStyleRaw) ? primaryStyleRaw : 'practico';
    const secondaryStyle = ALLOWED_STYLES.includes(secondaryStyleRaw) ? secondaryStyleRaw : 'visual';

    const breakdownList = Array.isArray(learningStyleProfile.breakdown) ? learningStyleProfile.breakdown : [];
    const visualEntry = breakdownList.find((b: any) => String(b?.type || '').toLowerCase() === 'visual');
    const auditoryEntry = breakdownList.find((b: any) => String(b?.type || '').toLowerCase() === 'auditivo');

    const visualPercentage = Number(
      visualEntry?.percentage ??
      (primaryStyle === 'visual' ? learningStyleProfile.primaryStyle?.percentage : undefined) ??
      (secondaryStyle === 'visual' ? learningStyleProfile.secondaryStyle?.percentage : undefined) ??
      0
    );

    const auditoryPercentage = Number(
      auditoryEntry?.percentage ??
      (primaryStyle === 'auditivo' ? learningStyleProfile.primaryStyle?.percentage : undefined) ??
      (secondaryStyle === 'auditivo' ? learningStyleProfile.secondaryStyle?.percentage : undefined) ??
      0
    );

    const isBimodal = Boolean(learningStyleProfile.isBimodal);
    const bimodalTitle = learningStyleProfile.bimodalTitle ? String(learningStyleProfile.bimodalTitle).slice(0, 255) : null;
    const bimodalDescription = learningStyleProfile.bimodalDescription ? String(learningStyleProfile.bimodalDescription) : null;

    const scoresBreakdown = JSON.stringify(
      Array.isArray(learningStyleProfile.breakdown) ? learningStyleProfile.breakdown : []
    );

    const recommendations = JSON.stringify(
      Array.isArray(learningStyleProfile.recommendations) ? learningStyleProfile.recommendations : []
    );

    const completedAt = learningStyleProfile.completedAt
      ? new Date(learningStyleProfile.completedAt)
      : new Date();

    // 4. Inserción o actualización idempotente (UPSERT) en perfiles_aprendizaje
    await client.query(
      `INSERT INTO perfiles_aprendizaje (
        user_id, primary_style, secondary_style,
        visual_percentage, auditory_percentage,
        is_bimodal, bimodal_title, bimodal_description,
        scores_breakdown, recommendations, completed_at
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
      ON CONFLICT (user_id) DO UPDATE SET
        primary_style = EXCLUDED.primary_style,
        secondary_style = EXCLUDED.secondary_style,
        visual_percentage = EXCLUDED.visual_percentage,
        auditory_percentage = EXCLUDED.auditory_percentage,
        is_bimodal = EXCLUDED.is_bimodal,
        bimodal_title = EXCLUDED.bimodal_title,
        bimodal_description = EXCLUDED.bimodal_description,
        scores_breakdown = EXCLUDED.scores_breakdown,
        recommendations = EXCLUDED.recommendations,
        completed_at = EXCLUDED.completed_at;`,
      [
        user.id,
        primaryStyle,
        secondaryStyle,
        visualPercentage,
        auditoryPercentage,
        isBimodal,
        bimodalTitle,
        bimodalDescription,
        scoresBreakdown,
        recommendations,
        completedAt
      ]
    );

    // 5. Sincronización con USERS_DB para etapas pendientes
    if (!USERS_DB[cleanEmail]) {
      USERS_DB[cleanEmail] = {
        id: user.id,
        username: user.username,
        email: cleanEmail,
        age: user.age,
        streakDays: user.streak_days,
        totalXP: user.total_xp,
        tokens: user.bits_balance,
        level: user.level,
        title: user.title,
        interests: user.interests || [],
        verified: user.verified,
        progress: {}
      };
    }
    USERS_DB[cleanEmail].learningStyleProfile = learningStyleProfile;

    console.log(`[NODO Perfil] 🧠 Perfil cognitivo guardado/actualizado exitosamente en Neon para: ${user.username} (${cleanEmail}) [${primaryStyle} / ${secondaryStyle}, Bimodal: ${isBimodal}]`);

    return res.json({
      success: true,
      message: "Perfil de aprendizaje guardado exitosamente en Neon PostgreSQL.",
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        learningStyleProfile
      }
    });
  } catch (error: any) {
    console.error("[NODO Perfil] Error en /api/usuario/estilo-aprendizaje:", error?.message || error);
    return res.status(500).json({ error: "Error interno al guardar el perfil de aprendizaje." });
  } finally {
    client.release();
  }
});

// Recuperar perfil cognitivo de aprendizaje desde Neon PostgreSQL (perfiles_aprendizaje)
app.get("/api/usuario/estilo-aprendizaje/:email", async (req, res) => {
  const { email } = req.params;
  if (!email) {
    return res.status(400).json({ error: "Se requiere el correo del estudiante." });
  }

  const cleanEmail = email.trim().toLowerCase();
  const ownership = verifyUserOwnership(req, cleanEmail);
  if (!ownership.ok) {
    return res.status(ownership.status).json({ error: ownership.error });
  }

  let pool;
  try {
    pool = getPool();
  } catch (err: any) {
    console.error("[NODO Perfil] Error obteniendo pool de base de datos:", err?.message || err);
    return res.status(503).json({ error: "Servicio de base de datos no configurado." });
  }

  let client;
  try {
    client = await pool.connect();
  } catch (connErr: any) {
    console.error("[NODO Perfil] Error conectando a PostgreSQL:", connErr?.message || connErr);
    return res.status(503).json({ error: "No se pudo conectar a la base de datos de Neon." });
  }

  try {
    const userRes = await client.query(
      `SELECT id, username, email FROM usuarios WHERE email = $1 AND deleted_at IS NULL;`,
      [cleanEmail]
    );

    if (userRes.rows.length === 0) {
      return res.status(404).json({ error: "Estudiante no registrado o inactivo." });
    }

    const user = userRes.rows[0];
    if (ownership.session.userId !== user.id) {
      return res.status(403).json({ error: "Acceso denegado: solo puedes consultar tu propio perfil de aprendizaje." });
    }

    const profileRes = await client.query(
      `SELECT primary_style, secondary_style, visual_percentage, auditory_percentage,
              is_bimodal, bimodal_title, bimodal_description, scores_breakdown, recommendations, completed_at
       FROM perfiles_aprendizaje
       WHERE user_id = $1;`,
      [user.id]
    );

    const learningStyleProfile = profileRes.rows.length > 0
      ? reconstructLearningStyleProfile(profileRes.rows[0])
      : null;

    return res.json({
      success: true,
      userId: user.id,
      email: user.email,
      learningStyleProfile
    });
  } catch (error: any) {
    console.error("[NODO Perfil] Error en GET /api/usuario/estilo-aprendizaje:", error?.message || error);
    return res.status(500).json({ error: "Error interno al recuperar el perfil de aprendizaje." });
  } finally {
    client.release();
  }
});

// Bloqueo en memoria por estudiante para serializar peticiones simultáneas en /api/diagnostico/analizar
const diagnosticUserLocks = new Map<string, Promise<void>>();

async function withDiagnosticUserLock<T>(emailKey: string, task: () => Promise<T>): Promise<T> {
  const previousLock = diagnosticUserLocks.get(emailKey) || Promise.resolve();
  let releaseCurrent!: () => void;
  const currentLock = new Promise<void>((resolve) => {
    releaseCurrent = resolve;
  });
  const chainedLock = previousLock.then(() => currentLock);
  diagnosticUserLocks.set(emailKey, chainedLock);

  await previousLock;
  try {
    return await task();
  } finally {
    releaseCurrent();
    if (diagnosticUserLocks.get(emailKey) === chainedLock) {
      diagnosticUserLocks.delete(emailKey);
    }
  }
}

// AI Diagnostic Profile generator (Conectado a Neon PostgreSQL - diagnosticos_iniciales y usuarios.interests)
app.post("/api/diagnostico/analizar", async (req, res) => {
  const { email, respuestas } = req.body;
  if (!email || !respuestas || !Array.isArray(respuestas) || respuestas.length < 4) {
    return res.status(400).json({
      error: "Se requiere el correo del estudiante y las 4 respuestas del diagnóstico."
    });
  }

  const cleanEmail = (email || "").trim().toLowerCase();
  const ownership = verifyUserOwnership(req, cleanEmail);
  if (!ownership.ok) {
    return res.status(ownership.status).json({ error: ownership.error });
  }

  let pool;
  try {
    pool = getPool();
  } catch (err: any) {
    console.error("[NODO Diagnóstico] Error obteniendo pool de base de datos:", err?.message || err);
    return res.status(503).json({ error: "Servicio de base de datos no configurado." });
  }

  return withDiagnosticUserLock(cleanEmail, async () => {
    let client;
    try {
      client = await pool.connect();
    } catch (connErr: any) {
      console.error("[NODO Diagnóstico] Error conectando a PostgreSQL:", connErr?.message || connErr);
      return res.status(503).json({ error: "No se pudo conectar a la base de datos de Neon." });
    }

    try {
      // 1. Identificar usuario activo en la tabla usuarios de PostgreSQL
      const userRes = await client.query(
        `SELECT id, username, email, age, streak_days, total_xp, bits_balance, level, title, interests, verified
         FROM usuarios
         WHERE email = $1 AND deleted_at IS NULL;`,
        [cleanEmail]
      );

      if (userRes.rows.length === 0) {
        return res.status(404).json({ error: "Estudiante no registrado o inactivo." });
      }

      const user = userRes.rows[0];
      if (ownership.session.userId !== user.id) {
        return res.status(403).json({ error: "Acceso denegado: solo puedes registrar diagnósticos en tu propia cuenta." });
      }

      // 2. Consolidación de intereses sin duplicados
      const [q1, q2, q3, q4] = respuestas;
      const INTEREST_MAP: Record<string, string> = {
        A: "Lógica y Algoritmos",
        B: "Bases de Datos y SQL",
        C: "Python e IA",
        D: "Desarrollo Integral"
      };

      let currentInterests: string[] = [];
      if (Array.isArray(user.interests)) {
        currentInterests = user.interests;
      } else if (typeof user.interests === 'string') {
        try {
          const parsed = JSON.parse(user.interests);
          if (Array.isArray(parsed)) currentInterests = parsed;
        } catch {
          currentInterests = [];
        }
      }

      const newInterest = (INTEREST_MAP[q1] || (typeof q1 === 'string' ? q1.trim() : '')).trim();
      const updatedInterests = [...currentInterests];
      if (newInterest && !updatedInterests.includes(newInterest)) {
        updatedInterests.push(newInterest);
      }

      // 3. Verificar deduplicación antes de invocar Gemini (ventana de 15 segundos con respuestas idénticas)
      const recentCheck = await client.query(
        `SELECT id, answers, recommended_plan, created_at,
                (created_at >= NOW() - INTERVAL '15 seconds') AS is_recent
         FROM diagnosticos_iniciales
         WHERE user_id = $1
         ORDER BY created_at DESC
         LIMIT 1;`,
        [user.id]
      );

      if (recentCheck.rows.length > 0 && recentCheck.rows[0].is_recent) {
        const recentRow = recentCheck.rows[0];
        const recentAnswers = Array.isArray(recentRow.answers)
          ? recentRow.answers
          : (typeof recentRow.answers === 'string' ? JSON.parse(recentRow.answers) : []);

        if (JSON.stringify(recentAnswers) === JSON.stringify(respuestas)) {
          const existingPlan = typeof recentRow.recommended_plan === 'string'
            ? JSON.parse(recentRow.recommended_plan)
            : recentRow.recommended_plan;

          console.log(`[NODO Diagnóstico] 🛡️ Diagnóstico duplicado prevenido (ventana 15s) para ${cleanEmail} [ID existente: ${recentRow.id}]`);

          return res.json({
            success: true,
            deduplicated: true,
            message: "Diagnóstico ya procesado recientemente; se devolvió el registro existente.",
            perfil: existingPlan,
            diagnosticId: recentRow.id,
            interests: currentInterests.length > 0 ? currentInterests : updatedInterests
          });
        }
      }

      // 4. Extracción de reglas base de experiencia y tiempo de estudio
      let xpLevel = "Principiante absoluto";
      if (q2 === "B") xpLevel = "Intermedio Temprano";
      if (q2 === "C") xpLevel = "Intermedio Sólido";
      if (q2 === "D") xpLevel = "Nivel Avanzado";

      let studyHours = "1-2 horas a la semana";
      if (q4 === "B") studyHours = "3-5 horas semanales";
      if (q4 === "C") studyHours = "6-10 horas semanales";
      if (q4 === "D") studyHours = "Intensivo formativo";

      let dynamicPlan = {
        overview: `Perfil detectado como ${xpLevel} con disponibilidad de ${studyHours}.`,
        weeks: [
          { title: "Semana 1: Cimientos", target: "Completar Lógica de Programación", focus: "Dominar condicionales y ciclos interactivos." },
          { title: "Semana 2: Estructuras", target: "Algoritmos en Tiempo Real", focus: "Introducir colecciones y velocidad Big O." },
          { title: "Semana 3: Maestría", target: "Refuerzo avanzado", focus: "Prueba modular de programación orientada a objetos." }
        ]
      };

      // 5. Generación con Gemini si está configurado (con fallback estructurado)
      if (ai) {
        try {
          const prompt = `Analiza este perfil de estudiante de programación para la app Nodo:
          - Experiencia previa: ${xpLevel}
          - Estilo favorito de aprendizaje: ${q3}
          - Tiempo dedicado: ${studyHours}
          - Edad: ${user.age} años.

          Genera un plan de aprendizaje estructurado en JSON. Devuelve EXACTAMENTE este esquema JSON y nada de texto antes o de código markdown.
          Schema:
          {
            "overview": "Texto corto de resumen de consejos con actitud Duolingo animadora",
            "weeks": [
              { "title": "...", "target": "...", "focus": "..." }
            ]
          }`;

          const schema = {
            type: Type.OBJECT,
            properties: {
              overview: { type: Type.STRING },
              weeks: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    title: { type: Type.STRING },
                    target: { type: Type.STRING },
                    focus: { type: Type.STRING }
                  },
                  required: ["title", "target", "focus"]
                }
              }
            },
            required: ["overview", "weeks"]
          };

          const responseText = await callGeminiWithFallback(prompt, schema);
          if (responseText) {
            const clean = responseText.replace(/```json/gi, '').replace(/```/g, '').trim();
            const parsed = JSON.parse(clean);
            if (parsed.overview && Array.isArray(parsed.weeks)) {
              dynamicPlan = parsed;
            }
          }
        } catch (e) {
          console.error("⚠️ Error llamando a Gemini para diagnóstico:", e);
        }
      }

      // 6. Transacción atómica con advisory lock en PostgreSQL (previene duplicados incluso entre múltiples instancias)
      try {
        await client.query("BEGIN;");
        await client.query(`SELECT pg_advisory_xact_lock(hashtext($1::text));`, [user.id]);

        const txDupCheck = await client.query(
          `SELECT id, answers, recommended_plan,
                  (created_at >= NOW() - INTERVAL '15 seconds') AS is_recent
           FROM diagnosticos_iniciales
           WHERE user_id = $1
           ORDER BY created_at DESC
           LIMIT 1;`,
          [user.id]
        );

        if (txDupCheck.rows.length > 0 && txDupCheck.rows[0].is_recent) {
          const recentRow = txDupCheck.rows[0];
          const recentAnswers = Array.isArray(recentRow.answers)
            ? recentRow.answers
            : (typeof recentRow.answers === 'string' ? JSON.parse(recentRow.answers) : []);

          if (JSON.stringify(recentAnswers) === JSON.stringify(respuestas)) {
            await client.query("COMMIT;");
            const existingPlan = typeof recentRow.recommended_plan === 'string'
              ? JSON.parse(recentRow.recommended_plan)
              : recentRow.recommended_plan;

            return res.json({
              success: true,
              deduplicated: true,
              message: "Diagnóstico ya procesado recientemente; se devolvió el registro existente.",
              perfil: existingPlan,
              diagnosticId: recentRow.id,
              interests: currentInterests.length > 0 ? currentInterests : updatedInterests
            });
          }
        }

        const diagRes = await client.query(
          `INSERT INTO diagnosticos_iniciales (
            user_id,
            answers,
            experience_level,
            study_hours,
            recommended_plan,
            created_at
          ) VALUES ($1, $2::jsonb, $3, $4, $5::jsonb, NOW())
          RETURNING id, created_at;`,
          [
            user.id,
            JSON.stringify(respuestas),
            xpLevel,
            studyHours,
            JSON.stringify(dynamicPlan)
          ]
        );

        await client.query(
          `UPDATE usuarios
           SET interests = $1::jsonb
           WHERE id = $2;`,
          [
            JSON.stringify(updatedInterests),
            user.id
          ]
        );

        await client.query("COMMIT;");

        const insertedDiag = diagRes.rows[0];
        console.log(`[NODO Diagnóstico] 📋 Diagnóstico inicial registrado en Neon para: ${user.username} (${cleanEmail}) [ID: ${insertedDiag.id}]`);
        console.log(`[NODO Diagnóstico] 🎯 Intereses actualizados: ${JSON.stringify(updatedInterests)}`);

        // 7. Sincronización secundaria con USERS_DB para rutas pendientes en memoria
        if (!USERS_DB[cleanEmail]) {
          USERS_DB[cleanEmail] = {
            id: user.id,
            username: user.username,
            email: cleanEmail,
            age: user.age,
            streakDays: user.streak_days,
            totalXP: user.total_xp,
            tokens: user.bits_balance,
            level: user.level,
            title: user.title,
            interests: updatedInterests,
            verified: user.verified,
            progress: {}
          };
        }
        USERS_DB[cleanEmail].recommendedPlan = dynamicPlan;
        USERS_DB[cleanEmail].interests = updatedInterests;

        return res.json({
          success: true,
          message: "Diagnóstico inicial procesado y guardado exitosamente en Neon PostgreSQL.",
          perfil: dynamicPlan,
          diagnosticId: insertedDiag.id,
          interests: updatedInterests
        });
      } catch (txError: any) {
        await client.query("ROLLBACK;");
        console.error("[NODO Diagnóstico] Error en transacción de base de datos:", txError?.message || txError);
        return res.status(500).json({ error: "Error interno al persistir el diagnóstico en la base de datos." });
      }
    } catch (error: any) {
      console.error("[NODO Diagnóstico] Error general en /api/diagnostico/analizar:", error?.message || error);
      return res.status(500).json({ error: "Error interno al procesar el diagnóstico." });
    } finally {
      client.release();
    }
  });
});

// Recuperar el diagnóstico inicial activo más reciente desde Neon PostgreSQL (diagnosticos_iniciales)
app.get(["/api/usuario/diagnostico/:email", "/api/diagnostico/:email"], async (req, res) => {
  const { email } = req.params;
  if (!email) {
    return res.status(400).json({ error: "Se requiere el correo del estudiante." });
  }

  const cleanEmail = email.trim().toLowerCase();
  const ownership = verifyUserOwnership(req, cleanEmail);
  if (!ownership.ok) {
    return res.status(ownership.status).json({ error: ownership.error });
  }

  let pool;
  try {
    pool = getPool();
  } catch (err: any) {
    console.error("[NODO Diagnóstico] Error obteniendo pool de base de datos:", err?.message || err);
    return res.status(503).json({ error: "Servicio de base de datos no configurado." });
  }

  let client;
  try {
    client = await pool.connect();
  } catch (connErr: any) {
    console.error("[NODO Diagnóstico] Error conectando a PostgreSQL:", connErr?.message || connErr);
    return res.status(503).json({ error: "No se pudo conectar a la base de datos de Neon." });
  }

  try {
    const userRes = await client.query(
      `SELECT id, username, email FROM usuarios WHERE email = $1 AND deleted_at IS NULL;`,
      [cleanEmail]
    );

    if (userRes.rows.length === 0) {
      return res.status(404).json({ error: "Estudiante no registrado o inactivo." });
    }

    const user = userRes.rows[0];
    if (ownership.session.userId !== user.id) {
      return res.status(403).json({ error: "Acceso denegado: solo puedes consultar tu propio diagnóstico." });
    }

    // Recuperar el diagnóstico más reciente como activo sin eliminar el historial
    const diagRes = await client.query(
      `SELECT id, answers, experience_level, study_hours, recommended_plan, created_at
       FROM diagnosticos_iniciales
       WHERE user_id = $1
       ORDER BY created_at DESC
       LIMIT 1;`,
      [user.id]
    );

    const countRes = await client.query(
      `SELECT COUNT(*)::int AS total FROM diagnosticos_iniciales WHERE user_id = $1;`,
      [user.id]
    );

    const diagnostico = diagRes.rows.length > 0
      ? reconstructDiagnostic(diagRes.rows[0])
      : null;

    return res.json({
      success: true,
      userId: user.id,
      email: user.email,
      diagnostico,
      recommendedPlan: diagnostico ? diagnostico.recommendedPlan : null,
      totalEvaluaciones: countRes.rows[0]?.total || 0
    });
  } catch (error: any) {
    console.error("[NODO Diagnóstico] Error en GET /api/usuario/diagnostico:", error?.message || error);
    return res.status(500).json({ error: "Error interno al recuperar el diagnóstico." });
  } finally {
    client.release();
  }
});

// Helper de respaldo para resolver el perfil cognitivo desde el body, USERS_DB o Neon PostgreSQL
async function resolveLearningStyleProfile(email?: string, providedProfile?: any) {
  if (providedProfile) return providedProfile;
  const cleanEmail = (email || "").trim().toLowerCase();
  if (!cleanEmail) return null;

  if (USERS_DB[cleanEmail]?.learningStyleProfile) {
    return USERS_DB[cleanEmail].learningStyleProfile;
  }

  let client;
  try {
    const pool = getPool();
    client = await pool.connect();
    const res = await client.query(
      `SELECT pa.primary_style, pa.secondary_style, pa.visual_percentage, pa.auditory_percentage,
              pa.is_bimodal, pa.bimodal_title, pa.bimodal_description, pa.scores_breakdown,
              pa.recommendations, pa.completed_at
       FROM perfiles_aprendizaje pa
       INNER JOIN usuarios u ON u.id = pa.user_id
       WHERE u.email = $1 AND u.deleted_at IS NULL
       LIMIT 1;`,
      [cleanEmail]
    );
    if (res.rows.length > 0) {
      const reconstructed = reconstructLearningStyleProfile(res.rows[0]);
      if (USERS_DB[cleanEmail]) {
        USERS_DB[cleanEmail].learningStyleProfile = reconstructed;
      }
      return reconstructed;
    }
  } catch (err: any) {
    console.warn("[NODO Perfil] Aviso al consultar perfil cognitivo de respaldo en PostgreSQL:", err?.message || err);
  } finally {
    if (client) client.release();
  }

  return null;
}

// Custom generated lessons/questions with IA adapted to the user's learning style
app.post("/api/modulo/:moduloId/generar-preguntas-ia", async (req, res) => {
  const { moduloId } = req.params;
  const { email, learningStyleProfile } = req.body;

  if (email && typeof email === "string" && email.trim()) {
    const ownership = verifyUserOwnership(req, email);
    if (!ownership.ok) {
      return res.status(ownership.status).json({ error: ownership.error });
    }
  }

  // Resolve user profile and learning style (body -> USERS_DB -> PostgreSQL)
  const styleProfile = await resolveLearningStyleProfile(email, learningStyleProfile);
  const primaryType: string = styleProfile?.primaryStyle?.type || 'practico';
  const primaryName: string = styleProfile?.primaryStyle?.name || 'Práctico / Kinestésico';
  const primaryIcon: string = styleProfile?.primaryStyle?.icon || '⚡';
  const secondaryType: string = styleProfile?.secondaryStyle?.type || '';
  const secondaryName: string = styleProfile?.secondaryStyle?.name || 'Visual / Espacial';
  const primaryPercentage: number = styleProfile?.primaryStyle?.percentage || 85;
  const isBimodal: boolean = Boolean(
    styleProfile?.isBimodal || 
    (primaryType === 'visual' && secondaryType === 'auditivo') || 
    (primaryType === 'auditivo' && secondaryType === 'visual')
  );

  const isVisualActive = primaryType === 'visual' || secondaryType === 'visual' || isBimodal;
  const isAuditivoActive = primaryType === 'auditivo' || secondaryType === 'auditivo' || isBimodal;

  const moduloNombres: Record<string, string> = {
    logica: "Lógica de Programación y Pensamiento Computacional",
    algoritmos: "Algoritmos y Estructuras de Datos",
    python: "Fundamentos de Programación con Python y Sintaxis",
    javascript: "JavaScript Moderno y Desarrollo Web",
  };
  const temaModulo = moduloNombres[moduloId] || moduloId;

  // Helper to decorate fallback questions according to style
  const decorateFallbackForStyle = (questions: any[]) => {
    return questions.map((q, idx) => {
      const cloned = { ...q };

      // 1. VISUAL: Diagramas explicativos, mapas de flujo del código, colores semánticos
      if (isVisualActive) {
        cloned.visualDiagram = idx % 2 === 0 
          ? `[Entrada: Datos] ──► { Condición / Operación } ──► [Salida Evaluada]\n       │                           │\n       ▼                           ▼\n [Validador Óptico] ──────► [Retorno en Memoria]`
          : `┌────────────────────────────┐\n│ Memoria / Espacio Variable │ ──► [ Asignación de Estado ]\n└─────────────┬──────────────┘\n              ▼\n       [ Bucle Activo ] ──► ( Condición de Salida )`;
        
        cloned.codeFlowMap = [
          { step: 1, title: "Inicialización", desc: "Declaración y reserva de memoria para variables", highlightCode: "let acumulador = 0;", color: "#39a900" },
          { step: 2, title: "Evaluación Lógica", desc: "Comprobación del predicado booleano en bifurcación", highlightCode: "if (valor > 0)", color: "#00e5ff" },
          { step: 3, title: "Procesamiento", desc: "Ejecución de transformación y actualización de datos", highlightCode: "acumulador += valor;", color: "#fdc300" },
          { step: 4, title: "Emisión de Salida", desc: "Retorno del resultado hacia el llamador", highlightCode: "return acumulador;", color: "#f43f5e" }
        ];

        cloned.semanticHighlights = [
          { token: "let / const", label: "Espacio en memoria", color: "#00e5ff" },
          { token: "if / switch", label: "Decisión condicional", color: "#fdc300" },
          { token: "function", label: "Bloque ejecutable", color: "#39a900" },
          { token: "return", label: "Salida del flujo", color: "#f43f5e" }
        ];
      }
      
      // 2. AUDITIVO: Texto listo para reproducirse por voz con explicaciones habladas y efectos sonoros
      if (isAuditivoActive) {
        cloned.speechText = `Atención al reto: ${cloned.title}. ${cloned.description}. Para resolverlo, verbaliza mentalmente el flujo del programa paso a paso. Recuerda que la lógica se vuelve clara cuando la explicas en voz alta.`;
        cloned.audioTip = `🎧 Técnica del Patito de Goma: Narra en voz alta qué hace esta línea antes de confirmar.`;
      }

      // 3. LECTOESCRITURA: Especificaciones técnicas y glosario
      if (primaryType === 'lectoescritor') {
        cloned.docSnippet = `📚 Referencia Técnica: Especificación estándar de sintaxis y operadores de ${temaModulo} (ECMAScript 2026).`;
      }

      // 4. LÓGICO: Análisis paso a paso, detección de errores en lógica y retos estructurados
      else if (primaryType === 'logico') {
        cloned.logicPremise = `🧩 Deducción Lógica: Evalúa la tabla de verdad y el caso borde antes de confirmar.`;
        
        // Convert intermedio question into a step-by-step logic debug challenge
        if (idx === 3 || q.type === 'coding') {
          cloned.type = 'logic_analysis';
          const sampleLines = [
            "function verificarUmbral(valores, limite) {",
            "  let acumulado = 0;",
            "  for (let i = 0; i <= valores.length; i++) { // Bug: <= fuera de rango",
            "    acumulado += valores[i];",
            "  }",
            "  return acumulado >= limite;",
            "}"
          ];
          cloned.codeLines = sampleLines;
          cloned.bugLineNumber = 3;
          cloned.bugExplanation = "En la línea 3, la condición 'i <= valores.length' evalúa un índice inexistente (valores[valores.length] es undefined), produciendo NaN. Debe ser 'i < valores.length'.";
          cloned.variableTrace = [
            { step: 1, line: sampleLines[1], vars: { acumulado: "0", i: "undefined" }, note: "Se crea acumulado en memoria con valor 0." },
            { step: 2, line: sampleLines[2], vars: { acumulado: "0", i: "0" }, note: "Comienza iteración con i = 0." },
            { step: 3, line: sampleLines[3], vars: { acumulado: "valores[0]", i: "1" }, note: "Se suma el primer valor al acumulador." },
            { step: 4, line: sampleLines[2], vars: { acumulado: "total", i: "length" }, note: "Bucle evalúa el índice final fuera de los límites." }
          ];
        }
      }

      // 5. KINESTÉSICO / PRÁCTICO: Dinámicas interactivas de ordenar líneas desordenadas (Parsons) o arrastrar bloques
      else if (primaryType === 'practico') {
        if (idx === 1 || idx === 3) {
          cloned.type = 'parsons';
          const orderedBlocks = [
            { id: 'p1', text: 'function calcularTotal(items) {', indent: 0 },
            { id: 'p2', text: '  let suma = 0;', indent: 1 },
            { id: 'p3', text: '  for (let item of items) {', indent: 1 },
            { id: 'p4', text: '    suma += item.precio;', indent: 2 },
            { id: 'p5', text: '  }', indent: 1 },
            { id: 'p6', text: '  return suma;', indent: 1 },
            { id: 'p7', text: '}', indent: 0 }
          ];
          cloned.parsonsSolutionOrder = ['p1', 'p2', 'p3', 'p4', 'p5', 'p6', 'p7'];
          // Scramble initial blocks
          cloned.parsonsBlocks = [orderedBlocks[2], orderedBlocks[0], orderedBlocks[4], orderedBlocks[1], orderedBlocks[5], orderedBlocks[3], orderedBlocks[6]];
        }
      }

      // 6. SOCIAL / COLABORATIVO
      else if (primaryType === 'social') {
        cloned.pairProgrammingPrompt = `👥 Escenario de Equipo: Imagina que estás revisando el Pull Request de un colega.`;
      }

      return cloned;
    });
  };

  const defaultAdvice = `¡Hola! Como tu método preferido es ${primaryName} (${primaryPercentage}%), he adaptado este módulo de ${temaModulo} con retos interactivos pensados especialmente para la forma en que tu cerebro aprende mejor.`;

  if (!ai) {
    console.log(`⚠️ No hay Gemini disponible, retornando preguntas predefinidas adaptadas al estilo ${primaryName} para:`, moduloId);
    const baseQuestions = STATIC_FALLBACK_QUESTIONS[moduloId] || STATIC_FALLBACK_QUESTIONS["logica"];
    return res.json({
      preguntas: decorateFallbackForStyle(baseQuestions),
      generado_por_ia: false,
      profesorAdvice: defaultAdvice,
      estiloAdaptado: primaryName,
      estiloIcon: primaryIcon
    });
  }

  try {
    // Specific pedagogical instructions according to the diagnosed learning style
    let directivaPedagogica = "";
    if (isBimodal || (isVisualActive && isAuditivoActive)) {
      directivaPedagogica = `
*** ADAPTACIÓN PRIORITARIA: PERFIL BIMODAL AUDIOVISUAL (Visual + Auditivo) ***
- El estudiante posee un perfil multimodal altamente potente: asimila esquemas espaciales y refuerza mediante memoria sonora y verbal.
- Para CADA pregunta es OBLIGATORIO incluir AMBOS componentes:
  1. Componente Visual:
     - 'visualDiagram': esquema gráfico en ASCII/Unicode con cajas [ ] y flechas ──►.
     - 'codeFlowMap': array con 3 o 4 pasos con step, title, desc, highlightCode y color hex.
     - 'semanticHighlights': array de elementos con token, label y color.
  2. Componente Auditivo:
     - 'speechText': explicación conversacional fluida lista para síntesis de voz, verbalizando el flujo paso a paso con entonación pedagógica.
     - 'audioTip': técnica del patito de goma (Rubber Duck) para que el alumno razone en voz alta.
`;
    } else if (primaryType === "practico") {
      directivaPedagogica = `
*** ADAPTACIÓN PRIORITARIA PARA ESTILO: PRÁCTICO / KINESTÉSICO (Aprende haciendo y manipulando) ***
- El estudiante retiene el código cuando lo manipula directamente:
- Genera AL MENOS 1 O 2 RETOS DE TIPO 'parsons' (ejercicios Parsons donde se proveen líneas de código desordenadas en 'parsonsBlocks' y el orden correcto en 'parsonsSolutionOrder').
- Los demás retos deben ser de tipo 'coding' en vivo con 'initialCode' y 'testCases'.
- En 'explanation', incluye un consejo práctico de experimentación inmediata en el editor.
`;
    } else if (primaryType === "visual") {
      directivaPedagogica = `
*** ADAPTACIÓN PRIORITARIA PARA ESTILO: VISUAL / ESPACIAL (Aprende con esquemas y mapas) ***
- El estudiante comprende y recuerda mejor cuando puede 'ver' la estructura espacial de los datos.
- Para CADA pregunta, es OBLIGATORIO incluir:
  1. 'visualDiagram': esquema gráfico en ASCII/Unicode limpio con cajas [ ] y flechas ──►.
  2. 'codeFlowMap': array con 3 o 4 pasos visuales con campos: step (número), title, desc, highlightCode, y color (hexadecimal como '#39a900', '#00e5ff', '#fdc300', '#f43f5e').
  3. 'semanticHighlights': array de elementos con token, label y color.
`;
    } else if (primaryType === "auditivo") {
      directivaPedagogica = `
*** ADAPTACIÓN PRIORITARIA PARA ESTILO: AUDITIVO / AURAL (Aprende escuchando y verbalizando) ***
- El estudiante asimila la información cuando la escucha narrada con explicaciones habladas.
- En CADA pregunta es OBLIGATORIO incluir en el campo 'speechText' una explicación completa, conversacional y fluida lista para síntesis de voz (Web Speech API), detallando qué busca el reto y cómo razonarlo rítmicamente.
- Incluye en 'audioTip' una técnica del Patito de Goma (Rubber Ducking).
`;
    } else if (primaryType === "lectoescritor") {
      directivaPedagogica = `
*** ADAPTACIÓN PRIORITARIA PARA ESTILO: LECTOESCRITURA (Aprende con documentación estructurada) ***
- El estudiante prefiere interactuar con especificaciones técnicas detalladas, guías oficiales y resúmenes estructurados.
- En CADA pregunta, incluye en el campo 'docSnippet' una nota formal de referencia técnica explicando la sintaxis formal y tipos.
`;
    } else if (primaryType === "logico") {
      directivaPedagogica = `
*** ADAPTACIÓN PRIORITARIA PARA ESTILO: LÓGICO / ANALÍTICO (Aprende deduciendo premisas y algoritmos) ***
- El estudiante aprende analizando código paso a paso y detectando errores en la lógica.
- Genera AL MENOS 1 RETO DE TIPO 'logic_analysis' con:
  - 'codeLines': array de líneas de código (5 a 8 líneas).
  - 'bugLineNumber': número de línea (1-indexed) donde ocurre el error lógico.
  - 'bugExplanation': explicación detallada de por qué la lógica falla en esa línea.
  - 'variableTrace': array de pasos con step, line, vars (objeto clave:valor de variables en ese momento) y note explicativa.
- En las otras preguntas, incluye en 'logicPremise' un análisis formal de causa-efecto o complejidad Big-O.
`;
    } else if (primaryType === "social") {
      directivaPedagogica = `
*** ADAPTACIÓN PRIORITARIA PARA ESTILO: SOCIAL / COLABORATIVO (Aprende en equipo y debates) ***
- Formula los enunciados como situaciones reales de equipo o Code Review de Pull Requests.
- Incluye en 'pairProgrammingPrompt' una pregunta para debatir con otro colega.
`;
    }

    const prompt = `Actúa como el Profesor Inteligente de Nodo (plataforma educativa de programación).
Genera exactamente 5 desafíos interactivos para el módulo "${temaModulo}" (ID: ${moduloId}), ADAPTADOS PERSONALIZADAMENTE para el estudiante.

PERFIL COGNITIVO DEL ESTUDIANTE:
- Estilo Dominante de Aprendizaje: ${primaryName} (${primaryPercentage}%)
- Estilo Secundario: ${secondaryName}
${directivaPedagogica}

ESTRUCTURA GENERAL:
- 5 retos interactivos acordes con el perfil cognitivo indicado.
- En preguntas 'multiple_choice', 'correctOptionId' debe ser la letra ('A', 'B', 'C' o 'D').
- En 'parsons', incluye 'parsonsBlocks' y 'parsonsSolutionOrder'.
- En 'logic_analysis', incluye 'codeLines', 'bugLineNumber', 'bugExplanation' y 'variableTrace'.

MENSAJE DEL PROFESOR:
En el campo 'profesorAdvice', escribe un mensaje cálido y motivador en 1-2 oraciones del Profesor IA explicando cómo adaptó esta clase a su estilo ${primaryName}.
En el campo 'estiloAdaptado', escribe exactamente "${primaryName}".
En el campo 'estiloIcon', escribe "${primaryIcon}".

Devuelve EXACTAMENTE un JSON con la estructura solicitada.`;

    const schema = {
      type: Type.OBJECT,
      properties: {
        profesorAdvice: { type: Type.STRING },
        estiloAdaptado: { type: Type.STRING },
        estiloIcon: { type: Type.STRING },
        preguntas: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              id: { type: Type.STRING },
              type: { type: Type.STRING },
              difficulty: { type: Type.STRING },
              title: { type: Type.STRING },
              description: { type: Type.STRING },
              options: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    id: { type: Type.STRING },
                    text: { type: Type.STRING }
                  },
                  required: ["id", "text"]
                }
              },
              correctOptionId: { type: Type.STRING },
              initialCode: { type: Type.STRING },
              testCases: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    id: { type: Type.STRING },
                    input: { type: Type.STRING },
                    codeCheck: { type: Type.STRING },
                    expectedOutput: { type: Type.STRING }
                  },
                  required: ["id", "input", "codeCheck", "expectedOutput"]
                }
              },
              explanation: { type: Type.STRING },
              visualDiagram: { type: Type.STRING },
              speechText: { type: Type.STRING },
              codeFlowMap: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    step: { type: Type.INTEGER },
                    title: { type: Type.STRING },
                    desc: { type: Type.STRING },
                    highlightCode: { type: Type.STRING },
                    color: { type: Type.STRING }
                  }
                }
              },
              semanticHighlights: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    token: { type: Type.STRING },
                    label: { type: Type.STRING },
                    color: { type: Type.STRING }
                  }
                }
              },
              logicPremise: { type: Type.STRING },
              codeLines: {
                type: Type.ARRAY,
                items: { type: Type.STRING }
              },
              bugLineNumber: { type: Type.INTEGER },
              bugExplanation: { type: Type.STRING },
              variableTrace: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    step: { type: Type.INTEGER },
                    line: { type: Type.STRING },
                    vars: { type: Type.OBJECT },
                    note: { type: Type.STRING }
                  }
                }
              },
              parsonsBlocks: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    id: { type: Type.STRING },
                    text: { type: Type.STRING },
                    indent: { type: Type.INTEGER }
                  }
                }
              },
              parsonsSolutionOrder: {
                type: Type.ARRAY,
                items: { type: Type.STRING }
              },
              audioTip: { type: Type.STRING },
              docSnippet: { type: Type.STRING },
              pairProgrammingPrompt: { type: Type.STRING }
            },
            required: ["id", "type", "difficulty", "title", "description", "explanation"]
          }
        }
      },
      required: ["preguntas", "profesorAdvice", "estiloAdaptado"]
    };

    const output = await callGeminiWithFallback(prompt, schema);
    if (output) {
      const clean = output.replace(/```json/gi, '').replace(/```/g, '').trim();
      const parsed = JSON.parse(clean);
      if (parsed.preguntas && Array.isArray(parsed.preguntas) && parsed.preguntas.length > 0) {
        const normalized = parsed.preguntas.map((q: any) => {
          if (q.type === 'multiple_choice') {
            if (Array.isArray(q.options)) {
              const defaultLetters = ['A', 'B', 'C', 'D'];
              q.options = q.options.map((opt: any, idx: number) => {
                const optId = String(opt.id || defaultLetters[idx] || `OPT_${idx}`).trim().toUpperCase();
                return {
                  id: optId,
                  text: String(opt.text || '')
                };
              });
            }

            let resolvedCorrectId = String(q.correctOptionId || '').trim();
            const matchLetter = resolvedCorrectId.match(/^(?:opci[oó]n\s*)?([A-D])\b/i);
            if (matchLetter) {
              resolvedCorrectId = matchLetter[1].toUpperCase();
            } else if (Array.isArray(q.options)) {
              const byText = q.options.find((o: any) => o.text.trim().toLowerCase() === resolvedCorrectId.toLowerCase());
              if (byText) {
                resolvedCorrectId = byText.id;
              } else {
                const matchExpl = q.explanation?.match(/opci[oó]n\s+([A-D])/i) || q.explanation?.match(/\b([A-D])\b/);
                resolvedCorrectId = matchExpl ? matchExpl[1].toUpperCase() : q.options[0]?.id || 'A';
              }
            }
            q.correctOptionId = resolvedCorrectId;
          }
          return q;
        });

        return res.json({
          preguntas: normalized,
          generado_por_ia: true,
          profesorAdvice: parsed.profesorAdvice || defaultAdvice,
          estiloAdaptado: parsed.estiloAdaptado || primaryName,
          estiloIcon: parsed.estiloIcon || primaryIcon
        });
      }
    }
  } catch (err) {
    console.error("⚠️ Error generando contenido dinámico en base a Gemini y estilo:", err);
  }

  // Fallback adapted to the user's learning style
  const baseQuestions = STATIC_FALLBACK_QUESTIONS[moduloId] || STATIC_FALLBACK_QUESTIONS["logica"];
  res.json({
    preguntas: decorateFallbackForStyle(baseQuestions),
    generado_por_ia: false,
    profesorAdvice: defaultAdvice,
    estiloAdaptado: primaryName,
    estiloIcon: primaryIcon
  });
});

// GET Roadmap for a module (Duolingo Path System)
app.get("/api/modulo/:moduloId/roadmap", (req, res) => {
  const { moduloId } = req.params;
  const roadmapData = STATIC_ROADMAPS[moduloId] || STATIC_ROADMAPS["logica"];
  res.json(roadmapData);
});

// POST Roadmap with optional AI generation and learning style adaptations
app.post("/api/modulo/:moduloId/roadmap", async (req, res) => {
  const { moduloId } = req.params;
  const { email, generateWithAI, learningStyleProfile } = req.body;

  if (email && typeof email === "string" && email.trim()) {
    const ownership = verifyUserOwnership(req, email);
    if (!ownership.ok) {
      return res.status(ownership.status).json({ error: ownership.error });
    }
  }

  const baseRoadmap = STATIC_ROADMAPS[moduloId] || STATIC_ROADMAPS["logica"];
  const styleProfile = await resolveLearningStyleProfile(email, learningStyleProfile);
  const primaryName = styleProfile?.primaryStyle?.name || 'Práctico';

  if (!generateWithAI || !ai) {
    // Return standard offline / pre-built roadmap matching exact schema
    return res.json(baseRoadmap);
  }

  try {
    const prompt = `Actúa como el Diseñador Pedagógico y de Interfaces de Niveles Gamificados de Nodo (ADSO).
Genera la estructura de datos para el sendero de niveles estilo Duolingo ("Roadmap") del módulo "${moduloId}" (${baseRoadmap.moduleTitle}).

DIRECTIVAS DE TEMATIZACIÓN Y MASCOTA:
- Python: "Pythie la Serpiente", avatar "🐍", themeColor "#0284c7", accentColor "#fbbf24", pathColor "#38bdf8", mascotPlacement "left_side".
- JavaScript: "Voltio JS", avatar "⚡", themeColor "#FACC15", accentColor "#F59E0B", pathColor "#FDE047", mascotPlacement "right_side".
- Lógica: "Nodo Bot", avatar "🤖", themeColor "#2EE59D", accentColor "#007832", pathColor "#10B981", mascotPlacement "left_side".
- Bases de Datos: "Cylo DB", avatar "🗄️", themeColor "#7C3AED", accentColor "#C084FC", pathColor "#A855F7", mascotPlacement "right_side".
- Algoritmos: "Nodo Bot Sabio", avatar "🧠", themeColor "#8B5CF6", accentColor "#6366F1", pathColor "#A78BFA", mascotPlacement "left_side".

GEOMETRÍA DEL SENDERO:
- curveOffset estrictamente entre [-1, 0, 1] (-1: izquierda, 0: centro, 1: derecha).
- Secuencia continua oscilante (0 -> 1 -> 0 -> -1 -> 0) para trazado vectorial continuo sin quiebres.
- Tipos de nivel permitidos en 'type': "lesson", "chest", "boss".
- Para retos 'lesson', incluye preguntas adaptadas al estilo ${primaryName}.

Devuelve OBLIGATORIAMENTE un único objeto JSON que cumpla EXACTAMENTE este esquema:
{
  "moduleId": "${moduloId}",
  "moduleTitle": "${baseRoadmap.moduleTitle}",
  "unitTitle": "${baseRoadmap.unitTitle || 'Unidad 1'}",
  "themeMascot": {
    "name": "${baseRoadmap.themeMascot.name}",
    "avatar": "${baseRoadmap.themeMascot.avatar}",
    "themeColor": "${baseRoadmap.themeMascot.themeColor}",
    "accentColor": "${baseRoadmap.themeMascot.accentColor || '#fbbf24'}",
    "pathColor": "${baseRoadmap.themeMascot.pathColor || '#38bdf8'}",
    "dialogue": "Frase de diálogo cómico...",
    "speechAudio": "Texto listo para sintetizar por voz...",
    "mascotPlacement": "${baseRoadmap.themeMascot.mascotPlacement || 'left_side'}",
    "animationStates": {
      "idle": "float_gentle",
      "talking": "wiggle_wave",
      "celebrating": "bounce_stars"
    }
  },
  "levels": [
    {
      "id": "lvl_1",
      "title": "Nombre del nivel",
      "type": "lesson",
      "curveOffset": 0,
      "isLocked": false,
      "isCompleted": false,
      "rewardBits": 25,
      "rewardXP": 50,
      "question": {
        "id": "q1",
        "type": "coding",
        "difficulty": "basico",
        "title": "...",
        "description": "...",
        "initialCode": "...",
        "testCases": [{ "id": "tc1", "input": "()", "codeCheck": "...", "expectedOutput": "..." }],
        "explanation": "..."
      }
    }
  ]
}`;

    const textResponse = await callGeminiWithFallback(prompt);
    if (textResponse) {
      const cleanJson = textResponse.replace(/```json/gi, '').replace(/```/g, '').trim();
      const parsed = JSON.parse(cleanJson);
      if (parsed.moduleId && parsed.themeMascot && Array.isArray(parsed.levels)) {
        // Preservar identificadores oficiales, tipos, geometría y recompensas de los nodos del catálogo
        const normalizedLevels = (baseRoadmap.levels || []).map((baseLvl, idx) => {
          const aiLvl = parsed.levels[idx];
          if (!aiLvl) return baseLvl;
          const isChest = baseLvl.type === "chest" || baseLvl.nodeType === "chest_reward";
          return {
            ...baseLvl,
            title: typeof aiLvl.title === "string" && aiLvl.title.trim() ? aiLvl.title.trim() : baseLvl.title,
            question: isChest
              ? undefined
              : (aiLvl.question && typeof aiLvl.question === "object" ? aiLvl.question : baseLvl.question)
          };
        });
        parsed.moduleId = baseRoadmap.moduleId;
        parsed.levels = normalizedLevels;
        parsed.roadmap = {
          sectionTitle: parsed.unitTitle || baseRoadmap.unitTitle || 'Unidad de Aprendizaje',
          nodes: normalizedLevels
        };
        return res.json(parsed);
      }
    }
  } catch (err) {
    console.warn("⚠️ Error generando roadmap dinámico con IA, usando fallback predefinido:", err);
  }

  return res.json(baseRoadmap);
});

const VALID_MODULE_IDS = new Set(STATIC_MODULES.map((m) => m.id));
const VALID_MODALITIES = new Set<"offline" | "ia">(["offline", "ia"]);

function buildRoadmapState(
  progNodeRows: any[],
  claimRows: any[]
): {
  roadmapProgress: Record<string, {
    moduleId: string;
    nodeId: string;
    completed: boolean;
    score: number;
    stars: number;
    attempts: number;
    lastAttemptAt?: string;
  }>;
  claimedNodes: Record<string, boolean>;
} {
  const roadmapProgress: Record<string, any> = {};
  for (const row of progNodeRows) {
    roadmapProgress[row.node_id] = {
      moduleId: row.modulo_id,
      nodeId: row.node_id,
      completed: Boolean(row.completed),
      score: Number(row.score) || 0,
      stars: Number(row.stars) || 0,
      attempts: Number(row.attempts) || 1,
      lastAttemptAt: row.last_attempt_at ? new Date(row.last_attempt_at).toISOString() : undefined
    };
  }
  const claimedNodes: Record<string, boolean> = {};
  for (const row of claimRows) {
    if (row.node_id) {
      claimedNodes[row.node_id] = true;
    }
  }
  return { roadmapProgress, claimedNodes };
}

function normalizeRoadmapNodeType(
  rawType?: string,
  rawNodeType?: string
): "lesson" | "chest" | "boss" | "checkpoint" {
  const candidate = String(rawType || rawNodeType || "lesson").trim().toLowerCase();
  if (candidate === "chest" || candidate === "chest_reward") return "chest";
  if (candidate === "boss" || candidate === "boss_challenge") return "boss";
  if (candidate === "checkpoint") return "checkpoint";
  return "lesson";
}

// Garantiza de forma idempotente que los 25 nodos oficiales del sendero existan en nodos_sendero
async function ensureRoadmapNodesCatalog(client: any): Promise<void> {
  await ensureModulesCatalog(client);

  for (const modId of Object.keys(STATIC_ROADMAPS)) {
    const roadmap = STATIC_ROADMAPS[modId];
    const levels = Array.isArray(roadmap?.levels) ? roadmap.levels : [];
    for (let idx = 0; idx < levels.length; idx++) {
      const lvl = levels[idx];
      const normalizedType = normalizeRoadmapNodeType(lvl.type, lvl.nodeType);
      await client.query(
        `INSERT INTO nodos_sendero (
          id, modulo_id, title, node_type, curve_offset, order_index,
          reward_bits, reward_xp, question_data, checkpoint_requirement
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9::jsonb, $10)
        ON CONFLICT (id) DO NOTHING;`,
        [
          lvl.id,
          modId,
          lvl.title,
          normalizedType,
          Number.isFinite(lvl.curveOffset) ? lvl.curveOffset : 0,
          idx + 1,
          Number(lvl.rewardBits) || 0,
          Number(lvl.rewardXP) || 0,
          lvl.question ? JSON.stringify(lvl.question) : null,
          lvl.checkpointRequirement || null
        ]
      );
    }
  }
}

async function isRoadmapNodeUnlocked(
  client: any,
  userId: string,
  moduloId: string,
  orderIndex: number
): Promise<{ unlocked: boolean; missingPrevTitle?: string }> {
  // Los primeros 3 nodos de cada sendero (nivel 1, nivel 2 y cofre inicial) inician disponibles
  if (orderIndex <= 3) {
    return { unlocked: true };
  }
  const prevLessonRes = await client.query(
    `SELECT ns.id, ns.title, COALESCE(pu.completed, false) AS completed
     FROM nodos_sendero ns
     LEFT JOIN progreso_usuario pu
       ON pu.node_id = ns.id AND pu.user_id = $1
     WHERE ns.modulo_id = $2
       AND ns.order_index < $3
       AND ns.node_type <> 'chest'
     ORDER BY ns.order_index DESC
     LIMIT 1;`,
    [userId, moduloId, orderIndex]
  );
  if (prevLessonRes.rows.length === 0) {
    return { unlocked: true };
  }
  const prev = prevLessonRes.rows[0];
  if (!prev.completed) {
    return { unlocked: false, missingPrevTitle: prev.title };
  }
  return { unlocked: true };
}

// Reclamo atómico e idempotente de cofres del sendero (Neon PostgreSQL - recompensas_reclamadas)
app.post("/api/modulo/:moduloId/roadmap/claim-node", async (req, res) => {
  const cleanModuleId = String(req.params.moduloId || "").trim();
  const { email, nodeId } = req.body;

  if (!email || typeof email !== "string" || !nodeId || typeof nodeId !== "string") {
    return res.status(400).json({ error: "Se requiere el correo del estudiante y el identificador del cofre." });
  }

  if (!VALID_MODULE_IDS.has(cleanModuleId)) {
    return res.status(400).json({ error: "El módulo especificado no pertenece al catálogo oficial de NODO." });
  }

  const cleanEmail = email.trim().toLowerCase();
  const cleanNodeId = nodeId.trim();

  const ownership = verifyUserOwnership(req, cleanEmail);
  if (!ownership.ok) {
    return res.status(ownership.status).json({ error: ownership.error });
  }

  let pool;
  try {
    pool = getPool();
  } catch (err: any) {
    console.error("[NODO Sendero] Error obteniendo pool de base de datos:", err?.message || err);
    return res.status(503).json({ error: "Servicio de base de datos no disponible." });
  }

  let client;
  try {
    client = await pool.connect();
  } catch (connErr: any) {
    console.error("[NODO Sendero] Error conectando a PostgreSQL:", connErr?.message || connErr);
    return res.status(503).json({ error: "No se pudo conectar a la base de datos de Neon." });
  }

  try {
    await client.query("BEGIN;");

    // 1. Bloquear usuario y verificar identidad
    const userRes = await client.query(
      `SELECT
        id, username, email, age, streak_days,
        last_active_date::text AS last_active_date,
        total_xp, bits_balance, level, title, verified,
        CURRENT_DATE::text AS today_str,
        (CURRENT_DATE - INTERVAL '1 day')::date::text AS yesterday_str
      FROM usuarios
      WHERE email = $1 AND deleted_at IS NULL
      FOR UPDATE;`,
      [cleanEmail]
    );

    if (userRes.rows.length === 0) {
      await client.query("ROLLBACK;");
      return res.status(404).json({ error: "Estudiante no registrado o inactivo." });
    }

    const user = userRes.rows[0];
    if (ownership.session.userId !== user.id) {
      await client.query("ROLLBACK;");
      return res.status(403).json({ error: "Acceso denegado: solo puedes reclamar cofres en tu propia cuenta." });
    }

    // 2. Asegurar catálogo oficial de módulos y los 25 nodos del sendero
    await ensureRoadmapNodesCatalog(client);

    // 3. Consultar recompensas oficiales del nodo en PostgreSQL (nunca del cliente)
    const nodeRes = await client.query(
      `SELECT id, modulo_id, title, node_type, order_index, reward_bits, reward_xp
       FROM nodos_sendero
       WHERE id = $1 AND modulo_id = $2;`,
      [cleanNodeId, cleanModuleId]
    );

    if (nodeRes.rows.length === 0) {
      await client.query("ROLLBACK;");
      return res.status(404).json({ error: "El cofre solicitado no pertenece a este módulo en el catálogo oficial." });
    }

    const node = nodeRes.rows[0];
    if (node.node_type !== "chest") {
      await client.query("ROLLBACK;");
      return res.status(400).json({ error: "El nodo indicado no es un cofre de recompensa." });
    }

    const unlockCheck = await isRoadmapNodeUnlocked(client, user.id, cleanModuleId, Number(node.order_index));
    if (!unlockCheck.unlocked) {
      await client.query("ROLLBACK;");
      return res.status(403).json({
        error: `Debes completar primero "${unlockCheck.missingPrevTitle || 'el nivel anterior'}" antes de abrir este cofre.`
      });
    }

    const officialBits = Math.max(0, Number(node.reward_bits) || 0);
    const officialXP = Math.max(0, Number(node.reward_xp) || 0);

    // 4. Inserción atómica idempotente con UNIQUE(user_id, node_id)
    const claimInsertRes = await client.query(
      `INSERT INTO recompensas_reclamadas (user_id, node_id, reward_bits, reward_xp)
       VALUES ($1, $2, $3, $4)
       ON CONFLICT (user_id, node_id) DO NOTHING
       RETURNING id;`,
      [user.id, cleanNodeId, officialBits, officialXP]
    );

    if (claimInsertRes.rows.length === 0) {
      await client.query("ROLLBACK;");
      return res.status(409).json({
        error: "Este cofre de recompensa ya fue reclamado anteriormente.",
        alreadyClaimed: true,
        nodeId: cleanNodeId
      });
    }

    // 5. Calcular racha, XP, Bits, Nivel y Título autoritativos
    const todayStr = String(user.today_str).slice(0, 10);
    const yesterdayStr = String(user.yesterday_str).slice(0, 10);
    const lastActiveStr = user.last_active_date ? String(user.last_active_date).slice(0, 10) : null;

    let newStreakDays = Number(user.streak_days) || 1;
    if (lastActiveStr !== todayStr) {
      newStreakDays = lastActiveStr === yesterdayStr ? (Number(user.streak_days) || 0) + 1 : 1;
    }

    const previousLevel = Math.max(1, Number(user.level) || 1);
    const newTotalXP = (Number(user.total_xp) || 0) + officialXP;
    const newBitsBalance = (Number(user.bits_balance) || 0) + officialBits;

    let newLevel = previousLevel;
    while (newTotalXP >= newLevel * 150) {
      newLevel += 1;
    }

    const titles = [
      "Iniciado de Código 🐍",
      "Analista de Bucles ⚙️",
      "Sacerdote de Algoritmos 🧙‍♂️",
      "Comandante Recursivo 🚀",
      "Arquitecto Cuántico 🧠"
    ];
    const newTitle = titles[Math.min(newLevel - 1, titles.length - 1)];

    await client.query(
      `UPDATE usuarios
       SET total_xp = $1,
           bits_balance = $2,
           level = $3,
           title = $4,
           streak_days = $5,
           last_active_date = $6::date,
           updated_at = NOW()
       WHERE id = $7;`,
      [newTotalXP, newBitsBalance, newLevel, newTitle, newStreakDays, todayStr, user.id]
    );

    if (officialXP > 0) {
      await client.query(
        `INSERT INTO xp_diario (user_id, date_slug, xp_amount)
         VALUES ($1, $2::date, $3)
         ON CONFLICT (user_id, date_slug) DO UPDATE SET
           xp_amount = xp_diario.xp_amount + EXCLUDED.xp_amount;`,
        [user.id, todayStr, officialXP]
      );
    }

    const roadmapProgRes = await client.query(
      `SELECT modulo_id, node_id, completed, score, stars, attempts, last_attempt_at
       FROM progreso_usuario
       WHERE user_id = $1;`,
      [user.id]
    );

    const claimedRes = await client.query(
      `SELECT node_id FROM recompensas_reclamadas WHERE user_id = $1;`,
      [user.id]
    );

    const xpRes = await client.query(
      `SELECT date_slug, xp_amount FROM xp_diario WHERE user_id = $1;`,
      [user.id]
    );

    await client.query("COMMIT;");

    const { roadmapProgress, claimedNodes } = buildRoadmapState(roadmapProgRes.rows, claimedRes.rows);
    const xpDaysMap: Record<string, number> = {};
    for (const row of xpRes.rows) {
      const slug = row.date_slug ? new Date(row.date_slug).toISOString().split("T")[0] : "";
      if (slug) xpDaysMap[slug] = row.xp_amount;
    }

    if (USERS_DB[cleanEmail]) {
      USERS_DB[cleanEmail].streakDays = newStreakDays;
      USERS_DB[cleanEmail].streak = newStreakDays;
      USERS_DB[cleanEmail].totalXP = newTotalXP;
      USERS_DB[cleanEmail].points = newTotalXP;
      USERS_DB[cleanEmail].tokens = newBitsBalance;
      USERS_DB[cleanEmail].level = newLevel;
      USERS_DB[cleanEmail].title = newTitle;
      USERS_DB[cleanEmail].xpDays = xpDaysMap;
      USERS_DB[cleanEmail].roadmapProgress = roadmapProgress;
      USERS_DB[cleanEmail].claimedNodes = claimedNodes;
      USERS_DB[cleanEmail].claimedRoadmapNodes = claimedNodes;
    }

    console.log(`[NODO Sendero] 🎁 Cofre reclamado en Neon por ${cleanEmail}: ${cleanNodeId} (+${officialBits} Bits, +${officialXP} XP)`);

    return res.json({
      success: true,
      nodeId: cleanNodeId,
      rewardBits: officialBits,
      rewardXP: officialXP,
      user: {
        streakDays: newStreakDays,
        totalXP: newTotalXP,
        tokens: newBitsBalance,
        bitsBalance: newBitsBalance,
        level: newLevel,
        title: newTitle,
        levelUp: newLevel > previousLevel,
        xpDays: xpDaysMap,
        roadmapProgress,
        claimedNodes
      }
    });
  } catch (error: any) {
    try {
      await client.query("ROLLBACK;");
    } catch {}
    console.error("[NODO Sendero] Error en /claim-node:", error?.message || error);
    return res.status(500).json({ error: "Error interno al reclamar el cofre en PostgreSQL." });
  } finally {
    client.release();
  }
});

// Guardar avance individual de un nodo del sendero (lección o jefe) en progreso_usuario
app.post("/api/usuario/sendero/nodo/guardar", async (req, res) => {
  const { email, moduleId, nodeId, score, totalQuestions } = req.body;

  if (!email || typeof email !== "string" || !moduleId || typeof moduleId !== "string" || !nodeId || typeof nodeId !== "string") {
    return res.status(400).json({ error: "Se requiere el correo del estudiante, el módulo y el identificador del nodo." });
  }

  const cleanEmail = email.trim().toLowerCase();
  const cleanModuleId = moduleId.trim();
  const cleanNodeId = nodeId.trim();

  if (!VALID_MODULE_IDS.has(cleanModuleId)) {
    return res.status(400).json({ error: "El módulo especificado no pertenece al catálogo oficial de NODO." });
  }

  const ownership = verifyUserOwnership(req, cleanEmail);
  if (!ownership.ok) {
    return res.status(ownership.status).json({ error: ownership.error });
  }

  const numericTotal = Number(totalQuestions);
  const numericScore = Number(score);
  if (!Number.isFinite(numericTotal) || numericTotal <= 0) {
    return res.status(400).json({ error: "El total de preguntas debe ser mayor a cero." });
  }
  if (!Number.isFinite(numericScore) || numericScore < 0) {
    return res.status(400).json({ error: "La cantidad de aciertos no es válida." });
  }

  const clampedCorrect = Math.min(numericScore, numericTotal);
  const percentageScore = Math.max(0, Math.min(100, Math.round((clampedCorrect / numericTotal) * 100)));
  const passed = percentageScore >= 60;
  const attemptStars = percentageScore >= 90 ? 3 : percentageScore >= 70 ? 2 : percentageScore >= 60 ? 1 : 0;

  let pool;
  try {
    pool = getPool();
  } catch (err: any) {
    console.error("[NODO Sendero] Error obteniendo pool de base de datos:", err?.message || err);
    return res.status(503).json({ error: "Servicio de base de datos no disponible." });
  }

  let client;
  try {
    client = await pool.connect();
  } catch (connErr: any) {
    console.error("[NODO Sendero] Error conectando a PostgreSQL:", connErr?.message || connErr);
    return res.status(503).json({ error: "No se pudo conectar a la base de datos de Neon." });
  }

  try {
    await client.query("BEGIN;");

    // 1. Bloquear usuario y validar propiedad
    const userRes = await client.query(
      `SELECT
        id, username, email, age, streak_days,
        last_active_date::text AS last_active_date,
        total_xp, bits_balance, level, title, verified,
        CURRENT_DATE::text AS today_str,
        (CURRENT_DATE - INTERVAL '1 day')::date::text AS yesterday_str
      FROM usuarios
      WHERE email = $1 AND deleted_at IS NULL
      FOR UPDATE;`,
      [cleanEmail]
    );

    if (userRes.rows.length === 0) {
      await client.query("ROLLBACK;");
      return res.status(404).json({ error: "Estudiante no registrado o inactivo." });
    }

    const user = userRes.rows[0];
    if (ownership.session.userId !== user.id) {
      await client.query("ROLLBACK;");
      return res.status(403).json({ error: "Acceso denegado: solo puedes guardar avance en tu propia cuenta." });
    }

    // 2. Asegurar catálogo oficial de módulos y los 25 nodos del sendero
    await ensureRoadmapNodesCatalog(client);

    // 3. Verificar nodo oficial en nodos_sendero
    const nodeRes = await client.query(
      `SELECT id, modulo_id, title, node_type, order_index, reward_bits, reward_xp
       FROM nodos_sendero
       WHERE id = $1 AND modulo_id = $2;`,
      [cleanNodeId, cleanModuleId]
    );

    if (nodeRes.rows.length === 0) {
      await client.query("ROLLBACK;");
      return res.status(404).json({ error: "El nodo del sendero no existe en el catálogo oficial de este módulo." });
    }

    const node = nodeRes.rows[0];
    if (node.node_type === "chest") {
      await client.query("ROLLBACK;");
      return res.status(400).json({ error: "Los cofres de recompensa deben reclamarse desde su endpoint específico." });
    }

    // 4. Validar desbloqueo secuencial en el servidor
    const unlockCheck = await isRoadmapNodeUnlocked(client, user.id, cleanModuleId, Number(node.order_index));
    if (!unlockCheck.unlocked) {
      await client.query("ROLLBACK;");
      return res.status(403).json({
        error: `Debes completar primero "${unlockCheck.missingPrevTitle || 'el nivel anterior'}" para desbloquear este nodo.`
      });
    }

    // 5. Verificar si el nodo ya había sido completado previamente (evita farmear recompensas infinitas)
    const existingProgRes = await client.query(
      `SELECT completed, score, stars, attempts
       FROM progreso_usuario
       WHERE user_id = $1 AND node_id = $2
       FOR UPDATE;`,
      [user.id, cleanNodeId]
    );

    const previouslyCompleted = existingProgRes.rows.length > 0 && Boolean(existingProgRes.rows[0].completed);

    // Solo se otorgan las recompensas oficiales del nodo la primera vez que se aprueba
    const xpToAdd = passed && !previouslyCompleted ? Math.max(0, Number(node.reward_xp) || 0) : 0;
    const bitsToAdd = passed && !previouslyCompleted ? Math.max(0, Number(node.reward_bits) || 0) : 0;

    // 6. Guardar/actualizar progreso del nodo individual compartido entre Offline e IA
    await client.query(
      `INSERT INTO progreso_usuario (
        user_id, modulo_id, node_id, completed, score, stars, attempts, last_attempt_at
      ) VALUES (
        $1, $2, $3, $4::boolean, $5::integer, $6::integer, 1, NOW()
      )
      ON CONFLICT (user_id, node_id) DO UPDATE SET
        completed = progreso_usuario.completed OR EXCLUDED.completed,
        score = GREATEST(progreso_usuario.score, EXCLUDED.score),
        stars = GREATEST(progreso_usuario.stars, EXCLUDED.stars),
        attempts = progreso_usuario.attempts + 1,
        last_attempt_at = NOW();`,
      [user.id, cleanModuleId, cleanNodeId, passed, percentageScore, attemptStars]
    );

    // 7. Calcular racha y actualizar usuarios / xp_diario con valores autoritativos
    const todayStr = String(user.today_str).slice(0, 10);
    const yesterdayStr = String(user.yesterday_str).slice(0, 10);
    const lastActiveStr = user.last_active_date ? String(user.last_active_date).slice(0, 10) : null;

    let newStreakDays = Number(user.streak_days) || 1;
    if (passed && lastActiveStr !== todayStr) {
      newStreakDays = lastActiveStr === yesterdayStr ? (Number(user.streak_days) || 0) + 1 : 1;
    }

    const previousLevel = Math.max(1, Number(user.level) || 1);
    const newTotalXP = (Number(user.total_xp) || 0) + xpToAdd;
    const newBitsBalance = (Number(user.bits_balance) || 0) + bitsToAdd;

    let newLevel = previousLevel;
    while (newTotalXP >= newLevel * 150) {
      newLevel += 1;
    }

    const titles = [
      "Iniciado de Código 🐍",
      "Analista de Bucles ⚙️",
      "Sacerdote de Algoritmos 🧙‍♂️",
      "Comandante Recursivo 🚀",
      "Arquitecto Cuántico 🧠"
    ];
    const newTitle = titles[Math.min(newLevel - 1, titles.length - 1)];

    if (passed || xpToAdd > 0 || bitsToAdd > 0) {
      await client.query(
        `UPDATE usuarios
         SET total_xp = $1,
             bits_balance = $2,
             level = $3,
             title = $4,
             streak_days = $5,
             last_active_date = CASE WHEN $6::boolean THEN $7::date ELSE last_active_date END,
             updated_at = NOW()
         WHERE id = $8;`,
        [newTotalXP, newBitsBalance, newLevel, newTitle, newStreakDays, passed, todayStr, user.id]
      );
    }

    if (xpToAdd > 0) {
      await client.query(
        `INSERT INTO xp_diario (user_id, date_slug, xp_amount)
         VALUES ($1, $2::date, $3)
         ON CONFLICT (user_id, date_slug) DO UPDATE SET
           xp_amount = xp_diario.xp_amount + EXCLUDED.xp_amount;`,
        [user.id, todayStr, xpToAdd]
      );
    }

    const roadmapProgRes = await client.query(
      `SELECT modulo_id, node_id, completed, score, stars, attempts, last_attempt_at
       FROM progreso_usuario
       WHERE user_id = $1;`,
      [user.id]
    );

    const claimedRes = await client.query(
      `SELECT node_id FROM recompensas_reclamadas WHERE user_id = $1;`,
      [user.id]
    );

    const xpRes = await client.query(
      `SELECT date_slug, xp_amount FROM xp_diario WHERE user_id = $1;`,
      [user.id]
    );

    await client.query("COMMIT;");

    const { roadmapProgress, claimedNodes } = buildRoadmapState(roadmapProgRes.rows, claimedRes.rows);
    const xpDaysMap: Record<string, number> = {};
    for (const row of xpRes.rows) {
      const slug = row.date_slug ? new Date(row.date_slug).toISOString().split("T")[0] : "";
      if (slug) xpDaysMap[slug] = row.xp_amount;
    }

    if (USERS_DB[cleanEmail]) {
      USERS_DB[cleanEmail].streakDays = newStreakDays;
      USERS_DB[cleanEmail].streak = newStreakDays;
      USERS_DB[cleanEmail].totalXP = newTotalXP;
      USERS_DB[cleanEmail].points = newTotalXP;
      USERS_DB[cleanEmail].tokens = newBitsBalance;
      USERS_DB[cleanEmail].level = newLevel;
      USERS_DB[cleanEmail].title = newTitle;
      USERS_DB[cleanEmail].xpDays = xpDaysMap;
      USERS_DB[cleanEmail].roadmapProgress = roadmapProgress;
      USERS_DB[cleanEmail].claimedNodes = claimedNodes;
      USERS_DB[cleanEmail].claimedRoadmapNodes = claimedNodes;
    }

    console.log(`[NODO Sendero] ✅ Nodo ${cleanNodeId} (${cleanModuleId}) guardado en Neon para ${cleanEmail}: passed=${passed}, score=${percentageScore}%, stars=${attemptStars}, +${xpToAdd} XP, +${bitsToAdd} Bits`);

    return res.json({
      success: true,
      nodeId: cleanNodeId,
      moduleId: cleanModuleId,
      passed,
      nodeAlreadyCompleted: previouslyCompleted,
      score: percentageScore,
      stars: attemptStars,
      xpGained: xpToAdd,
      bitsGained: bitsToAdd,
      user: {
        streakDays: newStreakDays,
        totalXP: newTotalXP,
        tokens: newBitsBalance,
        bitsBalance: newBitsBalance,
        level: newLevel,
        title: newTitle,
        levelUp: newLevel > previousLevel,
        xpGained: xpToAdd,
        bitsGained: bitsToAdd,
        xpDays: xpDaysMap,
        roadmapProgress,
        claimedNodes
      }
    });
  } catch (error: any) {
    try {
      await client.query("ROLLBACK;");
    } catch {}
    console.error("[NODO Sendero] Error en transacción /api/usuario/sendero/nodo/guardar:", error?.message || error);
    return res.status(500).json({ error: "Error interno al guardar el progreso del nodo en PostgreSQL." });
  } finally {
    client.release();
  }
});

function buildModuleProgressMap(rows: any[]): Record<string, { offline?: any; ia?: any }> {
  const progressMap: Record<string, { offline?: any; ia?: any }> = {};
  for (const row of rows) {
    const modality: "offline" | "ia" = row.modality === "ia" ? "ia" : "offline";
    if (!progressMap[row.modulo_id]) {
      progressMap[row.modulo_id] = {};
    }
    progressMap[row.modulo_id][modality] = {
      moduleId: row.modulo_id,
      modality,
      completed: row.completed,
      score: row.score,
      level: row.level,
      completedAt: row.completed_at ? new Date(row.completed_at).toISOString().split("T")[0] : undefined
    };
  }
  return progressMap;
}

// Garantiza de forma idempotente que los módulos del catálogo oficial existan en PostgreSQL (sin sobrescribir existentes)
async function ensureModulesCatalog(client: any): Promise<void> {
  for (let i = 0; i < STATIC_MODULES.length; i++) {
    const mod = STATIC_MODULES[i];
    const roadmapMeta = STATIC_ROADMAPS[mod.id];
    const mascot = mod.themeMascot || roadmapMeta?.themeMascot || {
      name: "Nodo Bot",
      avatar: mod.emoji || "🤖",
      themeColor: "#39a900"
    };
    const unitTitle = roadmapMeta?.unitTitle || mod.roadmap?.sectionTitle || null;
    const themeColor = mascot.themeColor || "#39a900";
    const accentColor = mascot.accentColor || null;

    await client.query(
      `INSERT INTO modulos (
        id, title, description, unit_title, emoji,
        theme_color, accent_color, theme_mascot, orden, activo
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8::jsonb, $9, true)
      ON CONFLICT (id) DO NOTHING;`,
      [
        mod.id,
        mod.title,
        mod.description,
        unitTitle,
        mod.emoji,
        themeColor,
        accentColor,
        JSON.stringify(mascot),
        i + 1
      ]
    );
  }
}

// Submit lesson score, update streak, XP, Bits and module progress by modality in Neon PostgreSQL
app.post("/api/usuario/progreso/guardar", async (req, res) => {
  const { email, moduleId, modality, score, totalQuestions, xpCount, complete } = req.body;

  if (!email || typeof email !== "string" || !moduleId || typeof moduleId !== "string") {
    return res.status(400).json({ error: "Se requiere el correo del estudiante y el identificador del módulo." });
  }

  const cleanEmail = email.trim().toLowerCase();
  const cleanModuleId = moduleId.trim();

  if (!VALID_MODULE_IDS.has(cleanModuleId)) {
    return res.status(400).json({ error: "El módulo especificado no pertenece al catálogo oficial de NODO." });
  }

  const rawModality = typeof modality === "string" ? modality.trim().toLowerCase() : "offline";
  if (!VALID_MODALITIES.has(rawModality as "offline" | "ia")) {
    return res.status(400).json({ error: "La modalidad especificada no es válida. Debe ser 'offline' o 'ia'." });
  }
  const cleanModality = rawModality as "offline" | "ia";

  // Validar token Bearer y correspondencia con el estudiante autenticado
  const ownership = verifyUserOwnership(req, cleanEmail);
  if (!ownership.ok) {
    return res.status(ownership.status).json({ error: ownership.error });
  }

  const numericTotal = Number(totalQuestions);
  const numericScore = Number(score);
  const numericXP = Number(xpCount);

  if (!Number.isFinite(numericTotal) || numericTotal <= 0) {
    return res.status(400).json({ error: "El total de preguntas debe ser mayor a cero." });
  }
  if (!Number.isFinite(numericScore) || numericScore < 0) {
    return res.status(400).json({ error: "La cantidad de aciertos no es válida." });
  }
  if (!Number.isFinite(numericXP) || numericXP < 0) {
    return res.status(400).json({ error: "La cantidad de XP ganada no es válida." });
  }

  const clampedCorrect = Math.min(numericScore, numericTotal);
  const percentageScore = Math.max(0, Math.min(100, Math.round((clampedCorrect / numericTotal) * 100)));
  const isCompletedNow = Boolean(complete);
  const xpToAdd = Math.max(0, Math.round(numericXP));
  const bitsToAdd = Math.floor(xpToAdd / 2);

  let pool;
  try {
    pool = getPool();
  } catch (err: any) {
    console.error("[NODO Progreso] Error obteniendo pool de base de datos:", err?.message || err);
    return res.status(503).json({ error: "Servicio de base de datos no disponible." });
  }

  let client;
  try {
    client = await pool.connect();
  } catch (connErr: any) {
    console.error("[NODO Progreso] Error conectando a PostgreSQL:", connErr?.message || connErr);
    return res.status(503).json({ error: "No se pudo conectar a la base de datos de Neon." });
  }

  try {
    await client.query("BEGIN;");

    // 1. Bloquear y recuperar datos actuales del estudiante en PostgreSQL
    const userRes = await client.query(
      `SELECT
        id, username, email, age, streak_days,
        last_active_date::text AS last_active_date,
        total_xp, bits_balance, level, title, interests, verified,
        CURRENT_DATE::text AS today_str,
        (CURRENT_DATE - INTERVAL '1 day')::date::text AS yesterday_str
      FROM usuarios
      WHERE email = $1 AND deleted_at IS NULL
      FOR UPDATE;`,
      [cleanEmail]
    );

    if (userRes.rows.length === 0) {
      await client.query("ROLLBACK;");
      return res.status(404).json({ error: "Estudiante no registrado o inactivo." });
    }

    const user = userRes.rows[0];
    if (ownership.session.userId !== user.id) {
      await client.query("ROLLBACK;");
      return res.status(403).json({ error: "Acceso denegado: solo puedes guardar progreso en tu propia cuenta." });
    }

    // 2. Asegurar de forma idempotente el catálogo de módulos (cumple FK de progreso_modulos_usuario)
    await ensureModulesCatalog(client);

    // 3. Calcular racha diaria usando la fecha del servidor PostgreSQL
    const todayStr = String(user.today_str).slice(0, 10);
    const yesterdayStr = String(user.yesterday_str).slice(0, 10);
    const lastActiveStr = user.last_active_date ? String(user.last_active_date).slice(0, 10) : null;

    let newStreakDays = Number(user.streak_days) || 1;
    if (lastActiveStr !== todayStr) {
      if (lastActiveStr === yesterdayStr) {
        newStreakDays = (Number(user.streak_days) || 0) + 1;
      } else {
        newStreakDays = 1;
      }
    }

    // 4. Calcular nuevo XP, Bits, Nivel (soporta múltiples subidas de nivel) y Título
    const previousLevel = Math.max(1, Number(user.level) || 1);
    const newTotalXP = (Number(user.total_xp) || 0) + xpToAdd;
    const newBitsBalance = (Number(user.bits_balance) || 0) + bitsToAdd;

    let newLevel = previousLevel;
    while (newTotalXP >= newLevel * 150) {
      newLevel += 1;
    }

    const titles = [
      "Iniciado de Código 🐍",
      "Analista de Bucles ⚙️",
      "Sacerdote de Algoritmos 🧙‍♂️",
      "Comandante Recursivo 🚀",
      "Arquitecto Cuántico 🧠"
    ];
    const newTitle = titles[Math.min(newLevel - 1, titles.length - 1)];

    // 5. Actualizar estadísticas globales del estudiante en usuarios
    await client.query(
      `UPDATE usuarios
       SET total_xp = $1,
           bits_balance = $2,
           level = $3,
           title = $4,
           streak_days = $5,
           last_active_date = $6::date,
           updated_at = NOW()
       WHERE id = $7;`,
      [newTotalXP, newBitsBalance, newLevel, newTitle, newStreakDays, todayStr, user.id]
    );

    // 6. Acumular experiencia diaria en xp_diario
    await client.query(
      `INSERT INTO xp_diario (user_id, date_slug, xp_amount)
       VALUES ($1, $2::date, $3)
       ON CONFLICT (user_id, date_slug) DO UPDATE SET
         xp_amount = xp_diario.xp_amount + EXCLUDED.xp_amount;`,
      [user.id, todayStr, xpToAdd]
    );

    // 7. Guardar progreso independiente por modalidad ('offline' o 'ia')
    await client.query(
      `INSERT INTO progreso_modulos_usuario (
        user_id, modulo_id, modality, completed, score, level, completed_at, updated_at
      ) VALUES (
        $1,
        $2,
        $3,
        $4::boolean,
        $5::integer,
        CASE
          WHEN $5::integer >= 80 THEN 'Avanzado'
          WHEN $5::integer >= 50 THEN 'Intermedio'
          ELSE 'Principiante'
        END,
        CASE WHEN $4::boolean THEN $6::date ELSE NULL END,
        NOW()
      )
      ON CONFLICT (user_id, modulo_id, modality) DO UPDATE SET
        completed = progreso_modulos_usuario.completed OR EXCLUDED.completed,
        score = GREATEST(progreso_modulos_usuario.score, EXCLUDED.score),
        level = CASE
          WHEN GREATEST(progreso_modulos_usuario.score, EXCLUDED.score) >= 80 THEN 'Avanzado'
          WHEN GREATEST(progreso_modulos_usuario.score, EXCLUDED.score) >= 50 THEN 'Intermedio'
          ELSE 'Principiante'
        END,
        completed_at = CASE
          WHEN (progreso_modulos_usuario.completed OR EXCLUDED.completed)
          THEN COALESCE(progreso_modulos_usuario.completed_at, EXCLUDED.completed_at, $6::date)
          ELSE NULL
        END,
        updated_at = NOW();`,
      [user.id, cleanModuleId, cleanModality, isCompletedNow, percentageScore, todayStr]
    );

    // 8. Reconstruir mapa completo autoritativo de progreso por modalidad y XP diario desde PostgreSQL
    const progRes = await client.query(
      `SELECT modulo_id, modality, completed, score, level, completed_at
       FROM progreso_modulos_usuario
       WHERE user_id = $1;`,
      [user.id]
    );

    const xpRes = await client.query(
      `SELECT date_slug, xp_amount
       FROM xp_diario
       WHERE user_id = $1;`,
      [user.id]
    );

    await client.query("COMMIT;");

    const progressMap = buildModuleProgressMap(progRes.rows);

    const xpDaysMap: Record<string, number> = {};
    for (const row of xpRes.rows) {
      const slug = row.date_slug ? new Date(row.date_slug).toISOString().split("T")[0] : "";
      if (slug) xpDaysMap[slug] = row.xp_amount;
    }

    // 9. Sincronización secundaria con USERS_DB para rutas pendientes en memoria
    if (!USERS_DB[cleanEmail]) {
      USERS_DB[cleanEmail] = {
        id: user.id,
        username: user.username,
        email: cleanEmail,
        age: user.age,
        interests: user.interests || [],
        verified: user.verified
      };
    }
    USERS_DB[cleanEmail].streakDays = newStreakDays;
    USERS_DB[cleanEmail].streak = newStreakDays;
    USERS_DB[cleanEmail].lastCompletedDate = todayStr;
    USERS_DB[cleanEmail].totalXP = newTotalXP;
    USERS_DB[cleanEmail].points = newTotalXP;
    USERS_DB[cleanEmail].tokens = newBitsBalance;
    USERS_DB[cleanEmail].bits = newBitsBalance;
    USERS_DB[cleanEmail].level = newLevel;
    USERS_DB[cleanEmail].title = newTitle;
    USERS_DB[cleanEmail].progress = progressMap;
    USERS_DB[cleanEmail].xpDays = xpDaysMap;

    console.log(`[NODO Progreso] 💾 Progreso guardado en Neon para ${cleanEmail} [Módulo: ${cleanModuleId} (${cleanModality}), Score: ${percentageScore}%, XP: +${xpToAdd}, Bits: +${bitsToAdd}]`);

    return res.json({
      success: true,
      user: {
        streakDays: newStreakDays,
        totalXP: newTotalXP,
        tokens: newBitsBalance,
        bitsBalance: newBitsBalance,
        level: newLevel,
        title: newTitle,
        progress: progressMap,
        xpDays: xpDaysMap,
        levelUp: newLevel > previousLevel,
        xpGained: xpToAdd,
        bitsGained: bitsToAdd,
        modality: cleanModality
      }
    });
  } catch (error: any) {
    try {
      await client.query("ROLLBACK;");
    } catch {}
    console.error("[NODO Progreso] Error en transacción /api/usuario/progreso/guardar:", error?.message || error);
    return res.status(500).json({ error: "Error interno al guardar el progreso del módulo en PostgreSQL." });
  } finally {
    client.release();
  }
});

// Recuperar perfil y progreso completo del usuario desde Neon PostgreSQL (o memoria si DB offline)
app.get(["/api/usuario/progreso/:email", "/api/usuario/perfil/:email"], async (req, res) => {
  const { email } = req.params;
  if (!email) {
    return res.status(400).json({ error: "Se requiere el correo del estudiante." });
  }

  const cleanEmail = email.trim().toLowerCase();
  const ownership = verifyUserOwnership(req, cleanEmail);
  if (!ownership.ok) {
    return res.status(ownership.status).json({ error: ownership.error });
  }

  let pool;
  try {
    pool = getPool();
  } catch (err) {
    // Si la BD no está configurada, recurrir al respaldo en memoria
    const memUser = USERS_DB[cleanEmail];
    if (!memUser) return res.status(404).json({ error: "Usuario no encontrado" });
    return res.json({
      username: memUser.username,
      email: memUser.email,
      age: memUser.age,
      streakDays: memUser.streakDays,
      totalXP: memUser.totalXP,
      level: memUser.level,
      title: memUser.title,
      interests: memUser.interests || [],
      xpDays: memUser.xpDays || {},
      recommendedPlan: memUser.recommendedPlan || null,
      learningStyleProfile: memUser.learningStyleProfile || null,
      progress: memUser.progress || {},
      roadmapProgress: memUser.roadmapProgress || {},
      claimedNodes: memUser.claimedNodes || memUser.claimedRoadmapNodes || {}
    });
  }

  let client;
  try {
    client = await pool.connect();
  } catch (connErr) {
    const memUser = USERS_DB[cleanEmail];
    if (!memUser) return res.status(404).json({ error: "Usuario no encontrado" });
    return res.json({
      username: memUser.username,
      email: memUser.email,
      age: memUser.age,
      streakDays: memUser.streakDays,
      totalXP: memUser.totalXP,
      level: memUser.level,
      title: memUser.title,
      interests: memUser.interests || [],
      xpDays: memUser.xpDays || {},
      recommendedPlan: memUser.recommendedPlan || null,
      learningStyleProfile: memUser.learningStyleProfile || null,
      progress: memUser.progress || {},
      roadmapProgress: memUser.roadmapProgress || {},
      claimedNodes: memUser.claimedNodes || memUser.claimedRoadmapNodes || {}
    });
  }

  try {
    const userRes = await client.query(
      `SELECT id, username, email, age, streak_days, total_xp, bits_balance, level, title, interests, verified
       FROM usuarios
       WHERE email = $1 AND deleted_at IS NULL;`,
      [cleanEmail]
    );

    if (userRes.rows.length === 0) {
      return res.status(404).json({ error: "Usuario no encontrado" });
    }

    const user = userRes.rows[0];
    if (ownership.session.userId !== user.id) {
      return res.status(403).json({ error: "Acceso denegado: solo puedes consultar tu propia información." });
    }

    const profileRes = await client.query(
      `SELECT primary_style, secondary_style, visual_percentage, auditory_percentage,
              is_bimodal, bimodal_title, bimodal_description, scores_breakdown, recommendations, completed_at
       FROM perfiles_aprendizaje
       WHERE user_id = $1;`,
      [user.id]
    );

    const diagRes = await client.query(
      `SELECT id, answers, experience_level, study_hours, recommended_plan, created_at
       FROM diagnosticos_iniciales
       WHERE user_id = $1
       ORDER BY created_at DESC
       LIMIT 1;`,
      [user.id]
    );

    const progRes = await client.query(
      `SELECT modulo_id, modality, completed, score, level, completed_at FROM progreso_modulos_usuario WHERE user_id = $1;`,
      [user.id]
    );

    const roadmapProgRes = await client.query(
      `SELECT modulo_id, node_id, completed, score, stars, attempts, last_attempt_at
       FROM progreso_usuario
       WHERE user_id = $1;`,
      [user.id]
    );

    const claimedRes = await client.query(
      `SELECT node_id FROM recompensas_reclamadas WHERE user_id = $1;`,
      [user.id]
    );

    const xpRes = await client.query(
      `SELECT date_slug, xp_amount FROM xp_diario WHERE user_id = $1;`,
      [user.id]
    );

    const learningStyleProfile = profileRes.rows.length > 0
      ? reconstructLearningStyleProfile(profileRes.rows[0])
      : null;

    const latestDiag = diagRes.rows.length > 0
      ? reconstructDiagnostic(diagRes.rows[0])
      : null;
    const recommendedPlan = latestDiag ? latestDiag.recommendedPlan : null;

    let userInterests: string[] = [];
    if (Array.isArray(user.interests)) {
      userInterests = user.interests;
    } else if (typeof user.interests === 'string') {
      try {
        const parsed = JSON.parse(user.interests);
        if (Array.isArray(parsed)) userInterests = parsed;
      } catch {
        userInterests = [];
      }
    }

    const progressMap = buildModuleProgressMap(progRes.rows);
    const { roadmapProgress, claimedNodes } = buildRoadmapState(roadmapProgRes.rows, claimedRes.rows);

    const xpDaysMap: Record<string, number> = {};
    for (const row of xpRes.rows) {
      const slug = row.date_slug ? new Date(row.date_slug).toISOString().split('T')[0] : '';
      if (slug) xpDaysMap[slug] = row.xp_amount;
    }

    const responsePayload = {
      id: user.id,
      username: user.username,
      email: user.email,
      age: user.age,
      streakDays: user.streak_days,
      streak: user.streak_days,
      totalXP: user.total_xp,
      points: user.total_xp,
      tokens: user.bits_balance,
      level: user.level,
      title: user.title,
      interests: userInterests,
      xpDays: xpDaysMap,
      recommendedPlan,
      learningStyleProfile,
      progress: progressMap,
      roadmapProgress,
      claimedNodes
    };

    // Sincronizar memoria
    if (USERS_DB[cleanEmail]) {
      Object.assign(USERS_DB[cleanEmail], responsePayload, {
        claimedRoadmapNodes: claimedNodes
      });
    }

    return res.json(responsePayload);
  } catch (error: any) {
    console.error("[NODO Progreso] Error en GET /api/usuario/progreso:", error?.message || error);
    return res.status(500).json({ error: "Error interno al recuperar el perfil del estudiante." });
  } finally {
    client.release();
  }
});

// ==================== INTERACTIVE AI TUTOR ENDPOINT ====================
app.post("/api/tutor/chat", async (req, res) => {
  const { 
    message, 
    mode = 'chat', 
    question, 
    currentCode, 
    moduleName, 
    learningStyleProfile, 
    history = [] 
  } = req.body;

  const qTitle = question?.title || "Desafío de Código";
  const qDesc = question?.description || "Ejercicio interactivo";
  const qType = question?.type || "multiple_choice";
  const qDifficulty = question?.difficulty || "intermedio";
  const styleName = learningStyleProfile?.primaryStyle?.name || "Práctico";
  const userText = (message || "").trim();

  // Pedagogical system instruction for Nodo Bot
  const systemInstruction = `Eres "Nodo Bot", el adorable y experto Tutor IA de Programación de la plataforma Nodo (representado como un tierno robot verde menta con pantallas de corchetes {} y [] en sus orejas y una tableta holográfica de código).
Tu propósito es enseñar con máxima claridad, precisión técnica y entusiasmo pedagógico a estudiantes de programación en español.

DIRECTRICES SUPREMAS DE ASISTENCIA Y PEDAGOGÍA SOCRÁTICA:
- Actúa con empatía, calidez y método socrático: NUNCA des el código resuelto de inmediato. Diagnostica el error, ofrece pistas graduales o analogías para que el estudiante complete el nodo por sí mismo.
1. SI EL ESTUDIANTE HACE UNA PREGUNTA LIBRE DE PROGRAMACIÓN (ej: "¿Qué es un array?", "¿Para qué sirve async/await?", "¿Por qué mi código da undefined?", "¿Qué diferencia hay entre let y const?"):
   - RESPONDE DIRECTA, PRECISA Y PRIORITARIAMENTE A LO QUE TE PREGUNTÓ.
   - Explica el concepto técnico con palabras fáciles de entender y analogías claras.
   - Proporciona un ejemplo de código breve, limpio y comentado en JavaScript o Python.
   - NO cambies de tema ni hables únicamente del ejercicio si el alumno preguntó sobre otro tema de programación.
2. SI EL ESTUDIANTE PIDE QUE LE EXPLIQUES EL EJERCICIO ACTUAL ("${qTitle}"):
   - Desglosa con amabilidad qué pide el reto: "${qDesc}".
   - Explica la lógica detrás del problema paso a paso.
   - NO regales la respuesta exacta de inmediato; guía al estudiante con pistas graduales para que razone la solución.
3. SI EL ESTUDIANTE MUESTRA CÓDIGO O TIENE ERRORES:
   - Diagnostica el error con empatía. Señala dónde está la inconsistencia lógica sin frustrarlo y sugiere la corrección.
4. FORMATO:
   - Usa formato Markdown impecable con negritas para ideas clave y bloques \`\`\`javascript o \`\`\`python con sintaxis limpia.
   - Sé conciso, didáctico y motivador.`;

  // Build the prompt prioritizing the student's exact query
  let promptText = "";

  if (history && Array.isArray(history) && history.length > 0) {
    promptText += "--- HISTORIAL RECIENTE DEL DIÁLOGO ---\n";
    const recent = history.slice(-6);
    recent.forEach((msg: any) => {
      promptText += `${msg.role === 'user' ? 'Alumno' : 'Nodo Bot'}: ${msg.content}\n`;
    });
    promptText += "--------------------------------------\n\n";
  }

  // Educational Exercise Context
  promptText += `CONTEXTO DEL RETO ACTUAL EN PANTALLA:
- Reto: "${qTitle}" (${qDifficulty})
- Tipo: ${qType}
- Enunciado: "${qDesc}"
${question?.options ? `- Opciones: ${question.options.map((o: any) => `${o.id}: ${o.text}`).join(' | ')}` : ''}
${question?.initialCode ? `- Código inicial:\n${question.initialCode}` : ''}
${currentCode ? `- Código que el alumno ha escrito:\n${currentCode}` : ''}
${question?.explanation ? `- Fundamento pedagógico: ${question.explanation}` : ''}
- Estilo del estudiante: ${styleName}\n\n`;

  if (mode === 'explain') {
    promptText += `MENSAJE DEL ALUMNO: "Hola Nodo Bot, por favor explícame en qué consiste este ejercicio '${qTitle}', qué conceptos necesito y cómo debo razonarlo paso a paso."`;
  } else if (mode === 'hint') {
    promptText += `MENSAJE DEL ALUMNO: "Hola Nodo Bot, ¿me das una pista estratégica para resolver '${qTitle}' sin darme la solución exacta?"`;
  } else {
    promptText += `PREGUNTA ESPECÍFICA DEL ALUMNO A RESPONDER OBLIGATORIAMENTE:
"${userText || '¿Puedes ayudarme a entender la lógica de este reto?'}"

Instrucción de respuesta: Responde directa y detalladamente a esta pregunta concreta del alumno.`;
  }

  // Attempt live Gemini invocation
  let aiReply: string | null = null;
  if (ai) {
    try {
      aiReply = await callGeminiText(promptText, systemInstruction);
    } catch (err: any) {
      console.warn("[Gemini Tutor] Fallo de llamada a Gemini:", err.message);
    }
  }

  // Context-aware Smart Fallback Engine (Semantic Matching for 20+ core programming topics)
  if (!aiReply) {
    const qLower = userText.toLowerCase();

    // 1. Explicit exercise explanation or hint
    if (mode === 'explain' || qLower.includes('explica este') || qLower.includes('este reto') || qLower.includes('este ejercicio') || qLower.includes('en que consiste') || qLower.includes('no entiendo este')) {
      aiReply = `¡Hola! Soy tu **Tutor Nodo Bot** 🤖 y vamos a desglosar el reto **"${qTitle}"** juntos.

🎯 **¿Cuál es el objetivo?**
${qDesc}

🔍 **Conceptos clave en juego:**
- ${qType === 'coding' ? 'Se trata de un reto de escritura de código. Debes asegurarte de retornar el resultado correcto usando `return`.' : 'Es una pregunta conceptual. Lee con calma cada opción y descarta las que violen la sintaxis o la lógica.'}
- **Pista técnica:** ${question?.explanation ? question.explanation.slice(0, 160) + '...' : 'Presta mucha atención al tipo de dato que se espera (booleano, número o texto).'}

💡 **Pasos recomendados para resolverlo:**
1. Lee las entradas que recibe tu función o la condición que evalúa la pregunta.
2. Sigue el flujo mentalmente paso a paso.
3. Si tienes dudas con la sintaxis exacta, ¡pregúntame cualquier concepto aquí abajo!`;
    } else if (mode === 'hint' || qLower.includes('dame una pista') || qLower.includes('pista')) {
      const hint = question?.audioTip || question?.logicPremise || question?.docSnippet || (question?.explanation ? question.explanation.slice(0, 120) + '...' : 'Verifica con cuidado los operadores de comparación y qué valor retorna tu algoritmo.');
      aiReply = `💡 **Pista estratégica de Nodo Bot:**

${hint}

Observa qué pasa con un caso de prueba sencillo. ¿Quieres que revisemos juntos la estructura o la sintaxis?`;
    } 
    // 2. Arrays / Listas / Métodos
    else if (qLower.includes('array') || qLower.includes('arreglo') || qLower.includes('lista') || qLower.includes('push') || qLower.includes('pop') || qLower.includes('map') || qLower.includes('filter') || qLower.includes('reduce')) {
      aiReply = `📚 **Arrays (Arreglos) en Programación:**

Un **array** es una lista ordenada de elementos que se accede mediante índices numéricos (empezando en 0).

\`\`\`javascript
const frutas = ["Manzana", "Pera", "Mango"];
console.log(frutas[0]); // "Manzana"

// Métodos más usados:
frutas.push("Uva");     // Agrega al final
frutas.pop();           // Quita el último
console.log(frutas.length); // 3 (cantidad de elementos)

// Transformar elementos con map:
const numeros = [1, 2, 3];
const dobles = numeros.map(n => n * 2); // [2, 4, 6]
\`\`\`

¿Tienes alguna duda sobre cómo recorrerlo o buscar elementos?`;
    }
    // 3. Variables, let, const, var
    else if (qLower.includes('variable') || qLower.includes('let') || qLower.includes('const') || qLower.includes('var') || qLower.includes('scope')) {
      aiReply = `📦 **Variables en JavaScript Moderno:**

Una variable es un contenedor en memoria para almacenar datos.

\`\`\`javascript
// 1. const: Para valores que NO van a ser reasignados (Regla de oro: úsala por defecto)
const maxIntentos = 3;

// 2. let: Para variables que cambiarán con el tiempo (como contadores en bucles)
let puntaje = 0;
puntaje += 10; // Válido

// 3. var: Antigua y propensa a errores por su alcance (scope) global/función. ¡Evítala!
\`\`\`

💡 **Consejo clave:** Usa siempre \`const\`. Si el valor realmente necesita cambiar, usa \`let\`.`;
    }
    // 4. Bucles y ciclos: for, while, do-while
    else if (qLower.includes('bucle') || qLower.includes('loop') || qLower.includes('for') || qLower.includes('while') || qLower.includes('ciclo')) {
      aiReply = `🔄 **Bucles y Ciclos de Repetición:**

Los bucles permiten ejecutar un bloque de código varias veces de forma automática:

\`\`\`javascript
// Bucle FOR: Cuando sabes cuántas veces iterar
for (let i = 0; i < 5; i++) {
  console.log("Iteración: " + i);
}

// Bucle WHILE: Mientras una condición sea verdadera
let energia = 3;
while (energia > 0) {
  console.log("Jugando...");
  energia--;
}
\`\`\`

⚠️ **Cuidado con los bucles infinitos:** Si la condición nunca se vuelve \`false\`, el programa se colgará.`;
    }
    // 5. Funciones, callbacks, return
    else if (qLower.includes('funcion') || qLower.includes('function') || qLower.includes('return') || qLower.includes('callback') || qLower.includes('flecha') || qLower.includes('parametro')) {
      aiReply = `⚙️ **Funciones y Valores de Retorno:**

Una función es un bloque de código reutilizable que procesa datos de entrada y devuelve un resultado con \`return\`:

\`\`\`javascript
// 1. Función tradicional
function calcularArea(base, altura) {
  return (base * altura) / 2;
}

// 2. Función Flecha (Arrow Function moderna)
const esMayorDeEdad = (edad) => edad >= 18;

// Invocación:
const area = calcularArea(10, 5); // 25
console.log(esMayorDeEdad(20));    // true
\`\`\`

💡 **¿Qué hace 'return'?** Detiene la ejecución de la función y entrega el valor al lugar donde fue llamada. Si no pones \`return\`, la función devuelve \`undefined\`.`;
    }
    // 6. Condicionales: if, else, switch, ternario
    else if (qLower.includes('condicional') || qLower.includes('if') || qLower.includes('else') || qLower.includes('ternario') || qLower.includes('switch')) {
      aiReply = `🔀 **Estructuras Condicionales:**

Permiten que tu programa tome decisiones según si una condición es verdadera (\`true\`) o falsa (\`false\`):

\`\`\`javascript
const nota = 85;

if (nota >= 90) {
  console.log("Excelente");
} else if (nota >= 70) {
  console.log("Aprobado");
} else {
  console.log("Necesitas repasar");
}

// Operador Ternario (versión corta en una sola línea):
const estado = (nota >= 70) ? "Aprobado" : "Reprobado";
\`\`\``;
    }
    // 7. Comparadores: == vs ===, operadores lógicos
    else if (qLower.includes('===') || qLower.includes('==') || qLower.includes('comparador') || qLower.includes('igualdad') || qLower.includes('diferencia entre ==')) {
      aiReply = `⚖️ **Diferencia crucial entre '==' y '===':**

- **\`==\` (Igualdad débil con coerción):** Compara el valor pero convierte los tipos si son distintos.
  - \`5 == "5"\` ➔ \`true\` (convierte el texto en número).
- **\`===\` (Igualdad estricta):** Compara TANTO el valor como el tipo de dato.
  - \`5 === "5"\` ➔ \`false\` (uno es \`number\` y el otro es \`string\`).

💡 **Buena práctica profesional:** Usa siempre **\`===\`** y **\`!==\`** para evitar errores inesperados de coerción.`;
    }
    // 8. Tipos de datos, undefined, null, NaN
    else if (qLower.includes('undefined') || qLower.includes('null') || qLower.includes('nan') || qLower.includes('tipo') || qLower.includes('typeof')) {
      aiReply = `🔍 **Valores Especiales en JavaScript:**

- **\`undefined\`:** Una variable ha sido declarada pero no tiene ningún valor asignado, o una función no tiene \`return\`.
- **\`null\`:** Ausencia intencional de valor (el programador explícitamente dice "aquí no hay nada").
- **\`NaN\` (Not a Number):** Resultado de una operación matemática inválida (ej: \`"hola" * 2\`).

\`\`\`javascript
let x;
console.log(x); // undefined

let usuario = null; // No hay usuario activo actualmente
console.log(isNaN("cinco" * 2)); // true
\`\`\``;
    }
    // 9. Promesas, async, await, asincronía
    else if (qLower.includes('promesa') || qLower.includes('promise') || qLower.includes('async') || qLower.includes('await') || qLower.includes('asincron')) {
      aiReply = `⏳ **Asincronía y Async / Await:**

En JavaScript, tareas lentas como consultar un servidor o una base de datos se hacen de forma asíncrona para no congelar la pantalla:

\`\`\`javascript
async function obtenerDatos() {
  try {
    const respuesta = await fetch('/api/usuario/progreso');
    const datos = await respuesta.json();
    console.log("Datos cargados:", datos);
  } catch (error) {
    console.error("Hubo un error al conectar:", error);
  }
}
\`\`\`

- **\`async\`**: Declara que la función devuelve una promesa.
- **\`await\`**: Pausa la ejecución dentro de la función hasta que la promesa se resuelva.`;
    }
    // 10. Objetos, diccionarios, JSON
    else if (qLower.includes('objeto') || qLower.includes('object') || qLower.includes('json') || qLower.includes('clave') || qLower.includes('propiedad')) {
      aiReply = `🗂️ **Objetos y Diccionarios:**

Un objeto agrupa datos en pares de **clave: valor**:

\`\`\`javascript
const desarrollador = {
  nombre: "Carlos",
  edad: 22,
  lenguajes: ["JavaScript", "Python"],
  activo: true
};

// Acceder a sus propiedades:
console.log(desarrollador.nombre); // "Carlos"
console.log(desarrollador["edad"]); // 22
\`\`\``;
    }
    // 11. Errores y debugging
    else if (qLower.includes('error') || qLower.includes('bug') || qLower.includes('falla') || qLower.includes('debug') || qLower.includes('consola')) {
      aiReply = `🛠️ **Cómo diagnosticar y solucionar errores:**

1. **Lee el mensaje de error:** La consola te dice el archivo y la línea exacta del fallo.
2. **TypeError: Cannot read property...:** Intentaste acceder a una propiedad de algo que es \`undefined\` o \`null\`.
3. **ReferenceError:** Usaste una variable que no existe o está mal escrita.
4. **SyntaxError:** Te faltó un paréntesis \`)\`, llave \`}\` o punto y coma.

Usa \`console.log("Valor:", miVariable)\` para inspeccionar tus datos paso a paso.`;
    }
    // 12. Smart contextual programming answer
    else {
      aiReply = `🤖 **Respuesta del Tutor Nodo Bot sobre "${userText}":**

En programación, cada concepto se construye sobre reglas lógicas claras.

Si estás analizando cómo aplicar esto en tu código:
\`\`\`javascript
// Ejemplo conceptual ilustrativo:
function resolver(dato) {
  // 1. Validar la entrada
  if (!dato) return false;
  
  // 2. Aplicar la lógica
  return dato.toString().trim();
}
\`\`\`

💡 **Consejo pedagógico:**
Dime con qué fragmento específico de código o línea tienes dudas y lo resolveremos paso a paso juntos.`;
    }
  }

  // Suggest dynamic followup prompts based on user query
  let suggestions = [
    "💡 Dame una pista orientativa",
    "🧩 Explicar este ejercicio paso a paso",
    "⚠️ ¿Qué error común debo evitar aquí?",
    "🚀 Dame un ejemplo de la vida real"
  ];

  if (userText.toLowerCase().includes('array')) {
    suggestions = [
      "¿Cómo recorro un array con forEach?",
      "¿Cuál es la diferencia entre map y filter?",
      "¿Cómo agrego elementos a un array?",
      "💡 Pista para el reto actual"
    ];
  } else if (userText.toLowerCase().includes('bucle') || userText.toLowerCase().includes('for')) {
    suggestions = [
      "¿Cómo evito un bucle infinito?",
      "¿Cuál es la diferencia entre for y while?",
      "¿Para qué sirve 'break' y 'continue'?",
      "💡 Pista para el reto actual"
    ];
  }

  res.json({
    success: true,
    reply: aiReply,
    suggestions
  });
});

// ==================== VITE DEVELOPMENT SERVING ====================
async function startServer() {
  if (PORT === 3000 && process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else if (process.env.NODE_ENV === "production") {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`🚀 NODO Backend Express activo en http://localhost:${PORT}`);
  });
}

startServer();
