import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Volume2, VolumeX, Sparkles, MessageSquare, Lightbulb, Star } from 'lucide-react';
import { ThemeMascot } from '../types';
import { audioFx } from '../utils/audioEffects';

interface ThemeMascotCompanionProps {
  mascot: ThemeMascot;
  moduleId: string;
  animationState?: 'idle' | 'talking' | 'celebrating';
  onAskTip?: () => void;
  className?: string;
  isMobileCompact?: boolean;
}

export default function ThemeMascotCompanion({
  mascot,
  moduleId,
  animationState = 'idle',
  onAskTip,
  className = '',
  isMobileCompact = false
}: ThemeMascotCompanionProps) {
  const [showBubble, setShowBubble] = useState(true);
  const [isSpeakingLocal, setIsSpeakingLocal] = useState(false);
  const [currentAnim, setCurrentAnim] = useState<'idle' | 'talking' | 'celebrating'>(animationState);

  // Sync external animation state if provided
  React.useEffect(() => {
    if (animationState) {
      setCurrentAnim(animationState);
    }
  }, [animationState]);

  const speechText = mascot.speechAudio || mascot.dialogue || mascot.greeting || "¡Vamos a aprender código juntos!";

  const handleMascotClick = () => {
    audioFx.play('click');
    setShowBubble(true);
    setCurrentAnim('talking');

    if ('speechSynthesis' in window) {
      setIsSpeakingLocal(true);
      audioFx.speak(
        speechText,
        () => {
          setIsSpeakingLocal(false);
          setCurrentAnim('idle');
        },
        () => {
          setIsSpeakingLocal(true);
        }
      );
    } else {
      setTimeout(() => setCurrentAnim('idle'), 1500);
    }
  };

  const handleStopSpeaking = (e: React.MouseEvent) => {
    e.stopPropagation();
    audioFx.stopSpeaking();
    setIsSpeakingLocal(false);
    setCurrentAnim('idle');
  };

  // SVG Graphics for each specialized themed character
  const renderMascotGraphic = () => {
    if (moduleId === 'python') {
      // PYTHIE LA SERPIENTE: Culebrita robótica interactiva cian / azul oscuro (#0284C7, #00324D)
      return (
        <div className="relative w-full h-full flex items-center justify-center">
          {/* Cyber Neon Aura */}
          <div className="absolute inset-0 rounded-full bg-cyan-500/25 blur-lg scale-110 pointer-events-none" />

          <svg viewBox="0 0 110 110" className="w-full h-full drop-shadow-lg">
            <defs>
              <linearGradient id="pythieGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#38BDF8" />
                <stop offset="60%" stopColor="#0284C7" />
                <stop offset="100%" stopColor="#00324D" />
              </linearGradient>
              <linearGradient id="goldTechGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#FDE047" />
                <stop offset="100%" stopColor="#F59E0B" />
              </linearGradient>
            </defs>

            {/* Slithering serpentine body */}
            <path
              d="M 22 75 C 10 58, 26 36, 52 36 C 76 36, 92 52, 80 74 C 70 88, 42 90, 32 78 C 24 68, 30 52, 48 52 C 60 52, 68 60, 64 70"
              fill="none"
              stroke="url(#pythieGradient)"
              strokeWidth="12"
              strokeLinecap="round"
            />

            {/* Golden cyber ribs / tech plates */}
            <path
              d="M 36 44 C 46 40, 62 44, 70 54"
              fill="none"
              stroke="url(#goldTechGrad)"
              strokeWidth="4"
              strokeLinecap="round"
              strokeDasharray="5 4"
            />

            {/* Robotic Snake Head */}
            <ellipse cx="72" cy="40" rx="16" ry="12" fill="#0284C7" stroke="#38BDF8" strokeWidth="2.5" />
            <path d="M 60 38 Q 72 32 84 38" fill="none" stroke="#00324D" strokeWidth="2" />

            {/* Tech Visor / Crown */}
            <rect x="66" y="30" width="14" height="4.5" rx="2" fill="url(#goldTechGrad)" />

            {/* Digital Neon Eyes with blinking state */}
            <circle cx="68" cy="38" r="3.5" fill="#2EE59D" />
            <circle cx="78" cy="38" r="3.5" fill="#2EE59D" />
            <circle cx="69" cy="37" r="1.2" fill="#FFFFFF" />
            <circle cx="79" cy="37" r="1.2" fill="#FFFFFF" />

            {/* Forked robotic cyber tongue */}
            <motion.path
              d="M 87 40 L 94 40 L 98 36 M 94 40 L 98 44"
              fill="none"
              stroke="#F43F5E"
              strokeWidth="2.2"
              strokeLinecap="round"
              animate={{ x: currentAnim === 'talking' ? [0, 4, 0] : [0, 2, 0] }}
              transition={{ duration: 0.6, repeat: Infinity }}
            />

            {/* Mini tech antenna */}
            <line x1="72" y1="28" x2="72" y2="20" stroke="#38BDF8" strokeWidth="2" />
            <circle cx="72" cy="19" r="3" fill="#FACC15" className="animate-ping" style={{ transformOrigin: '72px 19px' }} />
            <circle cx="72" cy="19" r="3" fill="#FACC15" />
          </svg>
        </div>
      );
    }

    if (moduleId === 'javascript') {
      // VOLTIO JS: Chispa eléctrica viviente con acentos dorados (#FACC15, #F59E0B)
      return (
        <div className="relative w-full h-full flex items-center justify-center">
          <div className="absolute inset-0 rounded-full bg-amber-400/35 blur-xl scale-125 pointer-events-none" />

          <svg viewBox="0 0 110 110" className="w-full h-full drop-shadow-lg">
            <defs>
              <linearGradient id="voltioGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#FEF08A" />
                <stop offset="40%" stopColor="#FACC15" />
                <stop offset="100%" stopColor="#F59E0B" />
              </linearGradient>
            </defs>

            {/* Pulsing energy rings */}
            <circle cx="55" cy="55" r="38" fill="none" stroke="#FDE047" strokeWidth="1.5" strokeDasharray="6 4" opacity="0.6" className="animate-spin" style={{ animationDuration: '8s', transformOrigin: '55px 55px' }} />

            {/* Star spark body */}
            <path
              d="M 55 12 L 66 38 L 94 42 L 72 60 L 80 88 L 55 72 L 30 88 L 38 60 L 16 42 L 44 38 Z"
              fill="url(#voltioGrad)"
              stroke="#D97706"
              strokeWidth="2.5"
            />

            {/* Cute Expressive Face */}
            <circle cx="47" cy="52" r="4" fill="#0F172A" />
            <circle cx="63" cy="52" r="4" fill="#0F172A" />
            <circle cx="48.5" cy="50.5" r="1.5" fill="#FFFFFF" />
            <circle cx="64.5" cy="50.5" r="1.5" fill="#FFFFFF" />

            {/* Cheerful mouth */}
            <path d="M 50 62 Q 55 68 60 62" fill="none" stroke="#0F172A" strokeWidth="2.2" strokeLinecap="round" />

            {/* Side electric lightning arcs */}
            <path d="M 20 28 L 26 34 L 22 38" stroke="#FDE047" strokeWidth="2.5" fill="none" strokeLinecap="round" />
            <path d="M 90 28 L 84 34 L 88 38" stroke="#FDE047" strokeWidth="2.5" fill="none" strokeLinecap="round" />
          </svg>
        </div>
      );
    }

    if (moduleId === 'basesdatos') {
      // CYLO DB: Servidor relacional animado violeta (#7C3AED, #C084FC)
      return (
        <div className="relative w-full h-full flex items-center justify-center">
          <div className="absolute inset-0 rounded-2xl bg-purple-500/25 blur-lg pointer-events-none" />

          <svg viewBox="0 0 110 110" className="w-full h-full drop-shadow-lg">
            <defs>
              <linearGradient id="cyloGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#A855F7" />
                <stop offset="50%" stopColor="#7C3AED" />
                <stop offset="100%" stopColor="#581C87" />
              </linearGradient>
            </defs>

            {/* Cylinder 1 (Top) */}
            <ellipse cx="55" cy="26" rx="30" ry="10" fill="#A855F7" stroke="#C084FC" strokeWidth="2" />
            <path d="M 25 26 v 14 c 0 6 13 10 30 10 s 30 -4 30 -10 v -14" fill="url(#cyloGrad)" stroke="#C084FC" strokeWidth="2" />

            {/* Cylinder 2 (Middle - Character face) */}
            <path d="M 25 44 v 16 c 0 6 13 10 30 10 s 30 -4 30 -10 v -16" fill="#6B21A8" stroke="#C084FC" strokeWidth="2" />

            {/* Cylinder 3 (Bottom) */}
            <path d="M 25 64 v 16 c 0 6 13 10 30 10 s 30 -4 30 -10 v -16" fill="#581C87" stroke="#C084FC" strokeWidth="2" />

            {/* Activity LEDs */}
            <circle cx="34" cy="51" r="2.8" fill="#2EE59D" className="animate-pulse" />
            <circle cx="42" cy="51" r="2.4" fill="#38BDF8" />
            <circle cx="34" cy="71" r="2.4" fill="#FACC15" />
            <circle cx="42" cy="71" r="2.4" fill="#2EE59D" />

            {/* Cute Eyes in middle cylinder */}
            <circle cx="58" cy="52" r="3.8" fill="#FFFFFF" />
            <circle cx="70" cy="52" r="3.8" fill="#FFFFFF" />
            <circle cx="59.5" cy="51" r="1.6" fill="#7C3AED" />
            <circle cx="71.5" cy="51" r="1.6" fill="#7C3AED" />
            <path d="M 60 58 Q 64 62 68 58" fill="none" stroke="#FFFFFF" strokeWidth="2" strokeLinecap="round" />

            {/* Floating holographic query tag */}
            <rect x="58" y="70" width="22" height="7" rx="3" fill="#00324D" stroke="#38BDF8" strokeWidth="1" />
            <text x="61" y="75" fill="#38BDF8" fontSize="5" fontWeight="900" fontFamily="monospace">SQL OK</text>
          </svg>
        </div>
      );
    }

    // Default: NODO BOT (Lógica & Algoritmos) - Robot tutor oficial verde menta (#2EE59D, #007832)
    return (
      <div className="relative w-full h-full flex items-center justify-center">
        <div className="absolute inset-0 rounded-full bg-emerald-400/30 blur-lg scale-110 pointer-events-none" />

        <svg viewBox="0 0 110 110" className="w-full h-full drop-shadow-lg">
          {/* Robot Head Body */}
          <rect x="28" y="30" width="54" height="46" rx="16" fill="#00283D" stroke="#2EE59D" strokeWidth="3" />
          
          {/* Screen Visor */}
          <rect x="35" y="38" width="40" height="26" rx="9" fill="#021824" stroke="#2EE59D" strokeWidth="1.5" />
          
          {/* Glowing Eyes: Code Brackets */}
          <text x="40" y="56" fill="#2EE59D" fontSize="16" fontWeight="900" fontFamily="monospace">{"{"}</text>
          <text x="60" y="56" fill="#2EE59D" fontSize="16" fontWeight="900" fontFamily="monospace">{"}"}</text>
          
          {/* Antenna */}
          <line x1="55" y1="30" x2="55" y2="16" stroke="#2EE59D" strokeWidth="3" strokeLinecap="round" />
          <circle cx="55" cy="14" r="4" fill="#39A900" stroke="#FFFFFF" strokeWidth="1.5" className="animate-pulse" />
          
          {/* Ear headphones */}
          <rect x="22" y="44" width="6" height="18" rx="3" fill="#007832" />
          <rect x="82" y="44" width="6" height="18" rx="3" fill="#007832" />
          
          {/* Chest holographic tablet corner */}
          <path d="M 40 76 L 70 76 L 74 90 L 36 90 Z" fill="#021824" stroke="#2EE59D" strokeWidth="1.5" />
          <line x1="42" y1="83" x2="68" y2="83" stroke="#2EE59D" strokeWidth="1.5" strokeDasharray="3 2" />
        </svg>
      </div>
    );
  };

  // Determine dynamic motion variants according to animationState
  const getMotionAnimation = () => {
    if (currentAnim === 'celebrating') {
      return {
        y: [0, -22, 0, -12, 0],
        rotate: [0, -8, 8, -4, 4, 0],
        scale: [1, 1.15, 0.95, 1.05, 1],
        transition: { duration: 1.2, repeat: Infinity, ease: "easeInOut" as const }
      };
    }
    if (currentAnim === 'talking') {
      return {
        y: [0, -4, 4, -2, 2, 0],
        rotate: [0, -4, 4, -2, 2, 0],
        scale: [1, 1.06, 1],
        transition: { duration: 0.8, repeat: Infinity, ease: "easeInOut" as const }
      };
    }
    // Idle float gentle
    return {
      y: [0, -8, 0],
      rotate: [0, 2, -2, 0],
      transition: { duration: 3.2, repeat: Infinity, ease: "easeInOut" as const }
    };
  };

  // MOBILE COMPACT FORMAT: Compact circular badge on side
  if (isMobileCompact) {
    return (
      <div className={`relative ${className}`}>
        <motion.button
          type="button"
          onClick={handleMascotClick}
          animate={getMotionAnimation()}
          className="w-16 h-16 rounded-full p-1 bg-gradient-to-tr from-[#00283D] to-[#043D4D] border-2 shadow-xl flex items-center justify-center cursor-pointer active:scale-95 relative"
          style={{ borderColor: mascot.themeColor || '#2EE59D' }}
          title={mascot.name}
        >
          {renderMascotGraphic()}
          <span 
            className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full text-xs flex items-center justify-center shadow-md border border-white/20"
            style={{ backgroundColor: mascot.themeColor || '#2EE59D', color: '#00283D' }}
          >
            {mascot.avatar}
          </span>
        </motion.button>

        {/* Mobile floating speech bubble */}
        <AnimatePresence>
          {showBubble && (
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="absolute bottom-20 right-0 w-64 p-3 bg-white dark:bg-[#0F172A] border-2 border-slate-200 dark:border-slate-700 rounded-2xl shadow-2xl z-50 text-left"
            >
              <div className="flex items-center justify-between gap-1 mb-1 border-b border-slate-100 dark:border-slate-800 pb-1">
                <span className="font-black text-xs text-[#00324D] dark:text-white flex items-center gap-1">
                  <span>{mascot.avatar}</span>
                  <span>{mascot.name}</span>
                </span>
                <button
                  type="button"
                  onClick={(e) => { e.stopPropagation(); setShowBubble(false); }}
                  className="text-slate-400 hover:text-slate-600 text-xs px-1 cursor-pointer"
                >
                  ✕
                </button>
              </div>
              <p className="text-xs text-slate-700 dark:text-slate-200 font-medium leading-snug">
                "{mascot.dialogue || mascot.greeting}"
              </p>
              <div className="mt-2 flex items-center justify-between">
                <button
                  type="button"
                  onClick={handleMascotClick}
                  className="text-[10px] font-black uppercase text-cyan-600 dark:text-cyan-400 flex items-center gap-1 cursor-pointer"
                >
                  <Volume2 className="w-3 h-3" />
                  <span>Escuchar</span>
                </button>
                {onAskTip && (
                  <button
                    type="button"
                    onClick={(e) => { e.stopPropagation(); onAskTip(); }}
                    className="text-[10px] font-black uppercase text-amber-500 flex items-center gap-1 cursor-pointer"
                  >
                    <Lightbulb className="w-3 h-3" />
                    <span>Pista</span>
                  </button>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    );
  }

  // DESKTOP / TABLET LATERAL FORMAT: Organic Character beside the path
  const isLeftSide = mascot.mascotPlacement !== 'right_side';

  return (
    <div className={`relative flex flex-col items-center select-none ${className}`}>
      {/* Floating Stars for celebrating */}
      {currentAnim === 'celebrating' && (
        <div className="absolute -top-6 inset-x-0 flex justify-center gap-3 pointer-events-none">
          <motion.div animate={{ y: [-5, -20], opacity: [1, 0], scale: [0.5, 1.3] }} transition={{ duration: 1, repeat: Infinity }}>
            <Star className="w-5 h-5 text-amber-400 fill-amber-400" />
          </motion.div>
          <motion.div animate={{ y: [-5, -24], opacity: [1, 0], scale: [0.5, 1.4] }} transition={{ duration: 1.2, repeat: Infinity, delay: 0.3 }}>
            <Sparkles className="w-6 h-6 text-cyan-400" />
          </motion.div>
        </div>
      )}

      {/* Comic Speech Bubble */}
      <AnimatePresence>
        {showBubble && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="mb-3 max-w-[240px] sm:max-w-[270px] bg-white dark:bg-[#0F172A] border-3 rounded-2xl p-3.5 shadow-xl text-left relative"
            style={{ borderColor: mascot.themeColor || '#2EE59D' }}
          >
            {/* Comic Speech Bubble Tail pointing down to mascot */}
            <div 
              className="absolute -bottom-2.5 left-1/2 -translate-x-1/2 w-4 h-4 bg-white dark:bg-[#0F172A] border-b-3 border-r-3 transform rotate-45"
              style={{ borderColor: mascot.themeColor || '#2EE59D' }}
            />

            {/* Bubble Header */}
            <div className="flex items-center justify-between gap-1.5 mb-1.5 border-b border-slate-100 dark:border-slate-800 pb-1.5">
              <span className="font-black text-xs text-[#00324D] dark:text-white flex items-center gap-1.5">
                <span className="text-base">{mascot.avatar}</span>
                <span>{mascot.name}</span>
              </span>
              <div className="flex items-center gap-1">
                {isSpeakingLocal ? (
                  <button
                    type="button"
                    onClick={handleStopSpeaking}
                    className="p-1 rounded-md bg-red-100 dark:bg-red-900/40 text-red-600 dark:text-red-300 hover:scale-105 cursor-pointer"
                    title="Detener voz"
                  >
                    <VolumeX className="w-3.5 h-3.5" />
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={handleMascotClick}
                    className="p-1 rounded-md bg-cyan-100 dark:bg-cyan-900/40 text-cyan-700 dark:text-cyan-300 hover:scale-105 cursor-pointer"
                    title="Reproducir consejo hablado"
                  >
                    <Volume2 className="w-3.5 h-3.5" />
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => setShowBubble(false)}
                  className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 text-xs px-1 cursor-pointer"
                  title="Ocultar globo"
                >
                  ✕
                </button>
              </div>
            </div>

            {/* Dialogue Text in Comic Style */}
            <p className="text-xs text-slate-700 dark:text-slate-200 font-medium leading-relaxed italic">
              "{mascot.dialogue || mascot.greeting}"
            </p>

            {/* Action buttons inside bubble */}
            <div className="mt-2.5 pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-[10px] font-black uppercase tracking-wider">
              {onAskTip && (
                <button
                  type="button"
                  onClick={onAskTip}
                  className="flex items-center gap-1 text-amber-500 hover:text-amber-600 dark:text-amber-400 cursor-pointer"
                >
                  <Lightbulb className="w-3 h-3" />
                  <span>Pedir Pista</span>
                </button>
              )}
              <button
                type="button"
                onClick={handleMascotClick}
                className="flex items-center gap-1 text-cyan-600 hover:text-cyan-700 dark:text-cyan-400 cursor-pointer ml-auto"
              >
                <Sparkles className="w-3 h-3" />
                <span>Interactuar</span>
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Mascot Animated Character Body */}
      <motion.button
        type="button"
        onClick={handleMascotClick}
        animate={getMotionAnimation()}
        className="w-28 h-28 sm:w-32 sm:h-32 rounded-3xl p-2.5 bg-gradient-to-tr from-[#00283D] via-[#052B3D] to-[#043D4D] border-3 shadow-2xl hover:scale-105 active:scale-95 cursor-pointer flex items-center justify-center shrink-0 relative group"
        style={{ borderColor: mascot.themeColor || '#2EE59D' }}
        title={`Habla con ${mascot.name} (${currentAnim})`}
      >
        {renderMascotGraphic()}

        {/* Floating pill badge */}
        <span 
          className="absolute -bottom-2.5 px-3 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider text-[#00283D] shadow-md flex items-center gap-1 border border-white/20"
          style={{ backgroundColor: mascot.themeColor || '#2EE59D' }}
        >
          <span>{mascot.avatar}</span>
          <span>{mascot.name.split(' ')[0]}</span>
        </span>
      </motion.button>
    </div>
  );
}
