import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, 
  Send, 
  Sparkles, 
  Volume2, 
  VolumeX, 
  RotateCcw, 
  Lightbulb, 
  Code2, 
  Copy, 
  Check, 
  ChevronDown, 
  ChevronUp, 
  BookOpen,
  MessageSquare,
  Flame,
  HelpCircle
} from 'lucide-react';
import { Question, LearningStyleResult } from '../types';
import NodoTutorAvatar, { TutorEmotion } from './NodoTutorAvatar';
import NodoLogo from './NodoLogo';

export interface ChatMessage {
  id: string;
  sender: 'tutor' | 'user';
  text: string;
  timestamp: Date;
  isInitialExplanation?: boolean;
}

interface TutorDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  question: Question | null;
  questionIndex: number;
  totalQuestions: number;
  moduleTitle?: string;
  currentCode?: string;
  learningStyleProfile?: LearningStyleResult | null;
}

export default function TutorDrawer({
  isOpen,
  onClose,
  question,
  questionIndex,
  totalQuestions,
  moduleTitle = "Fundamentos de Programación",
  currentCode = "",
  learningStyleProfile
}: TutorDrawerProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [tutorEmotion, setTutorEmotion] = useState<TutorEmotion>('happy');
  const [isSpeakingMessageId, setIsSpeakingMessageId] = useState<string | null>(null);
  const [showQuestionCard, setShowQuestionCard] = useState(true);
  const [copiedCodeId, setCopiedCodeId] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'chat' | 'reto'>('chat');

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const lastQuestionIdRef = useRef<string | null>(null);

  // Auto-scroll chat to bottom
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isOpen) {
      scrollToBottom();
      setTimeout(() => inputRef.current?.focus(), 250);
    }
  }, [messages, isOpen]);

  // When drawer opens or question changes, generate initial pedagogical explanation
  useEffect(() => {
    if (!isOpen || !question) return;

    if (lastQuestionIdRef.current !== question.id) {
      lastQuestionIdRef.current = question.id;

      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
        setIsSpeakingMessageId(null);
      }

      fetchInitialExplanation(question);
    }
  }, [isOpen, question?.id]);

  // Cleanup speech synthesis on close
  useEffect(() => {
    if (!isOpen && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      setIsSpeakingMessageId(null);
    }
  }, [isOpen]);

  const fetchInitialExplanation = async (q: Question) => {
    setIsLoading(true);
    setTutorEmotion('thinking');

    // Welcoming greeting
    const welcomeMsg = `¡Hola! Soy **Nodo Bot** 🤖, tu tutor personal de programación.
    
Veo que estás en el reto **"${q.title}"** (Ejercicio ${questionIndex + 1} de ${totalQuestions}). Estoy analizando el ejercicio para guiarte en la lógica sin arruinarte la diversión de resolverlo...`;

    setMessages([
      {
        id: `welcome-${q.id}`,
        sender: 'tutor',
        text: welcomeMsg,
        timestamp: new Date(),
        isInitialExplanation: true
      }
    ]);

    try {
      const res = await fetch('/api/tutor/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          mode: 'explain',
          question: q,
          currentCode,
          moduleName: moduleTitle,
          learningStyleProfile,
          history: []
        })
      });

      const data = await res.json();
      if (data.reply) {
        setMessages([
          {
            id: `explanation-${q.id}-${Date.now()}`,
            sender: 'tutor',
            text: data.reply,
            timestamp: new Date(),
            isInitialExplanation: true
          }
        ]);
        setTutorEmotion('happy');
      }
    } catch (err) {
      setMessages([
        {
          id: `fallback-${q.id}`,
          sender: 'tutor',
          text: `🎯 **Objetivo de "${q.title}":**\n${q.description}\n\n💡 **Pista clave:** ${q.explanation || 'Observa con cuidado las variables y los valores esperados.'}\n\nPregúntame cualquier duda que tengas sobre la sintaxis o conceptos de programación.`,
          timestamp: new Date(),
          isInitialExplanation: true
        }
      ]);
      setTutorEmotion('happy');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSendMessage = async (customText?: string, customMode: 'chat' | 'hint' | 'explain' = 'chat') => {
    const text = (customText ?? inputValue).trim();
    if (!text && customMode === 'chat') return;
    if (isLoading) return;

    const userMsgText = text || (customMode === 'hint' ? '¿Me das una pista para este ejercicio?' : 'Explícame este ejercicio paso a paso');

    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text: userMsgText,
      timestamp: new Date()
    };

    const newMessages = [...messages, userMsg];
    setMessages(newMessages);
    setInputValue('');
    setIsLoading(true);
    setTutorEmotion('thinking');

    try {
      const history = newMessages.slice(-6).map(m => ({
        role: m.sender === 'user' ? 'user' : 'model',
        content: m.text
      }));

      const res = await fetch('/api/tutor/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: userMsgText,
          mode: customMode,
          question,
          currentCode,
          moduleName: moduleTitle,
          learningStyleProfile,
          history
        })
      });

      const data = await res.json();
      const reply = data.reply || '¡Aquí estoy para ayudarte! ¿En qué concepto te gustaría profundizar?';

      setMessages(prev => [
        ...prev,
        {
          id: `tutor-${Date.now()}`,
          sender: 'tutor',
          text: reply,
          timestamp: new Date()
        }
      ]);
      setTutorEmotion('happy');
    } catch (error) {
      setMessages(prev => [
        ...prev,
        {
          id: `tutor-error-${Date.now()}`,
          sender: 'tutor',
          text: 'Tuve una pequeña interferencia en mi procesador, pero estoy listo. ¿Podrías reformular tu pregunta o quieres que revisemos el reto actual?',
          timestamp: new Date()
        }
      ]);
      setTutorEmotion('happy');
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const toggleSpeech = (msgId: string, text: string) => {
    if (!('speechSynthesis' in window)) return;

    if (isSpeakingMessageId === msgId) {
      window.speechSynthesis.cancel();
      setIsSpeakingMessageId(null);
      return;
    }

    window.speechSynthesis.cancel();
    const cleanSpeech = text
      .replace(/```[\s\S]*?```/g, 'bloque de código omitido')
      .replace(/`([^`]+)`/g, '$1')
      .replace(/[*#_~]/g, '')
      .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1');

    const utterance = new SpeechSynthesisUtterance(cleanSpeech);
    utterance.lang = 'es-ES';
    utterance.rate = 1.0;
    utterance.onend = () => setIsSpeakingMessageId(null);
    utterance.onerror = () => setIsSpeakingMessageId(null);

    setIsSpeakingMessageId(msgId);
    window.speechSynthesis.speak(utterance);
  };

  const handleCopyCode = (code: string, id: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCodeId(id);
    setTimeout(() => setCopiedCodeId(null), 2000);
  };

  const handleResetChat = () => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      setIsSpeakingMessageId(null);
    }
    if (question) {
      fetchInitialExplanation(question);
    }
  };

  // Render markdown with code formatting
  const renderMessageContent = (content: string, msgId: string, isUser: boolean = false) => {
    const parts = content.split(/(```[\s\S]*?```)/g);

    return parts.map((part, pIdx) => {
      if (part.startsWith('```') && part.endsWith('```')) {
        const lines = part.slice(3, -3).trim().split('\n');
        let language = 'código';
        let codeBody = part.slice(3, -3).trim();

        if (lines[0] && /^[a-zA-Z0-9_-]+$/.test(lines[0].trim())) {
          language = lines[0].trim();
          codeBody = lines.slice(1).join('\n');
        }

        const snippetId = `${msgId}-code-${pIdx}`;
        const isCopied = copiedCodeId === snippetId;

        return (
          <div key={pIdx} className="my-3 rounded-2xl overflow-hidden border border-slate-700/80 bg-[#001724] shadow-md">
            <div className="flex items-center justify-between px-3.5 py-2 bg-[#000e17] border-b border-slate-800 text-[11px] font-mono text-slate-300">
              <span className="font-extrabold text-[#2EE59D] uppercase tracking-wider flex items-center gap-1.5">
                <Code2 className="w-3.5 h-3.5 text-[#00E5FF]" />
                {language}
              </span>
              <button 
                onClick={() => handleCopyCode(codeBody, snippetId)}
                className="flex items-center gap-1.5 text-slate-300 hover:text-white transition px-2 py-0.5 rounded-lg bg-white/10 hover:bg-white/20 text-[11px] font-bold cursor-pointer"
                title="Copiar código"
              >
                {isCopied ? <Check className="w-3.5 h-3.5 text-[#2EE59D]" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{isCopied ? '¡Copiado!' : 'Copiar'}</span>
              </button>
            </div>
            <pre className="p-3.5 text-xs font-mono text-[#2EE59D] overflow-x-auto leading-relaxed whitespace-pre font-semibold selection:bg-emerald-800">
              <code>{codeBody}</code>
            </pre>
          </div>
        );
      }

      const formattedLines = part.split('\n').map((line, lIdx) => {
        const isBullet = line.trim().startsWith('- ') || line.trim().startsWith('* ');
        const isNumber = /^\d+\.\s+/.test(line.trim());
        const cleanLine = isBullet ? line.trim().replace(/^[-*]\s+/, '') : isNumber ? line.trim().replace(/^\d+\.\s+/, '') : line;

        const tokens = cleanLine.split(/(`[^`]+`|\*\*[^*]+\*\*)/g);

        const renderedTokens = tokens.map((token, tIdx) => {
          if (token.startsWith('`') && token.endsWith('`')) {
            return (
              <code 
                key={tIdx} 
                className={
                  isUser 
                    ? "bg-white/20 text-[#2EE59D] border border-white/20 px-1.5 py-0.5 rounded-md text-[12px] font-mono font-bold mx-0.5" 
                    : "bg-emerald-50 dark:bg-emerald-950/80 text-[#007832] dark:text-[#2EE59D] border border-emerald-200 dark:border-emerald-800 px-1.5 py-0.5 rounded-md text-[12px] font-mono font-bold mx-0.5"
                }
              >
                {token.slice(1, -1)}
              </code>
            );
          }
          if (token.startsWith('**') && token.endsWith('**')) {
            return (
              <strong key={tIdx} className={isUser ? "font-black text-white" : "font-black text-[#00283d] dark:text-white"}>
                {token.slice(2, -2)}
              </strong>
            );
          }
          return token;
        });

        if (isBullet) {
          return (
            <div key={lIdx} className="flex items-start gap-2 my-1 pl-1">
              <span className={isUser ? "text-[#2EE59D] font-black text-sm select-none shrink-0" : "text-[#007832] dark:text-[#2EE59D] font-black text-sm select-none shrink-0"}>•</span>
              <div className={`flex-1 leading-relaxed font-medium ${isUser ? 'text-white' : 'text-[#00283d] dark:text-slate-100'}`}>{renderedTokens}</div>
            </div>
          );
        }

        if (isNumber) {
          const matchNum = line.trim().match(/^(\d+)\./);
          return (
            <div key={lIdx} className="flex items-start gap-2 my-1 pl-1">
              <span className={`text-xs font-black px-1.5 py-0.5 rounded-md shrink-0 ${isUser ? 'bg-white/20 text-white' : 'text-white bg-[#00283d] dark:bg-[#2EE59D] dark:text-[#00283d]'}`}>
                {matchNum ? matchNum[1] : '•'}
              </span>
              <div className={`flex-1 leading-relaxed font-medium ${isUser ? 'text-white' : 'text-[#00283d] dark:text-slate-100'}`}>{renderedTokens}</div>
            </div>
          );
        }

        return (
          <p key={lIdx} className={line.trim() === '' ? 'h-2' : `my-1.5 leading-relaxed font-medium ${isUser ? 'text-white font-semibold' : 'text-[#00283d] dark:text-slate-100'}`}>
            {renderedTokens}
          </p>
        );
      });

      return <div key={pIdx}>{formattedLines}</div>;
    });
  };

  const quickPrompts = [
    { label: '💡 Pista estratégica', mode: 'hint' as const, text: 'Dame una pista orientativa para resolver este ejercicio sin darme la solución exacta.' },
    { label: '🧩 Explicar ejercicio', mode: 'explain' as const, text: 'Explícame en qué consiste este ejercicio y cómo pensarlo paso a paso.' },
    { label: '🔍 ¿Cómo funciona la sintaxis?', mode: 'chat' as const, text: '¿Cuál es la sintaxis correcta que se espera en este ejercicio?' },
    { label: '⚠️ Errores comunes', mode: 'chat' as const, text: '¿Qué errores comunes debo evitar en este reto de programación?' },
    { label: '🚀 Ejemplo práctico', mode: 'chat' as const, text: '¿Puedes darme una analogía de la vida real para entender mejor este concepto?' },
  ];

  return (
    <>
      {/* Backdrop */}
      {isOpen && (
        <div 
          onClick={onClose}
          className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs z-40 transition-opacity animate-in fade-in duration-200"
          aria-hidden="true"
        />
      )}

      {/* Main Drawer occupying LEFT SIDE of screen */}
      <aside 
        className={`fixed top-0 left-0 bottom-0 z-50 w-full sm:w-[470px] md:w-[500px] lg:w-[530px] bg-[#F8FAFC] dark:bg-[#0B131E] border-r-2 border-slate-200 dark:border-slate-800 shadow-2xl flex flex-col transition-transform duration-300 ease-out ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* HEADER: Nodo Bot Avatar & Official Logo */}
        <header className="bg-[#0b1622] text-white px-4 py-3.5 border-b-2 border-[#021824] flex items-center justify-between shrink-0 shadow-sm">
          <div className="flex items-center gap-3">
            {/* The Adorable 3D Tutor Avatar Mascot */}
            <div className="relative w-12 h-12 rounded-2xl bg-gradient-to-tr from-[#021824] via-[#052b3d] to-[#043d4d] border-2 border-[#2EE59D]/40 p-0.5 flex items-center justify-center shadow-inner group">
              <NodoTutorAvatar
                size="sm"
                emotion={isLoading ? 'thinking' : tutorEmotion}
                showHoloTablet={true}
                showFloatingParticles={false}
                isAnimated={true}
                isResponding={isLoading}
              />
              <span className={`absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full border-2 border-[#0b1622] ${isLoading ? 'bg-amber-400 animate-ping' : 'bg-[#2EE59D] animate-pulse'}`} />
            </div>

            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-black text-base tracking-tight text-white flex items-center gap-1.5">
                  Nodo Bot
                  <span className="text-[10px] bg-[#2EE59D]/20 text-[#2EE59D] border border-[#2EE59D]/40 px-2 py-0.5 rounded-full font-black uppercase tracking-wider">
                    Tutor IA
                  </span>
                </h3>
              </div>
              <p className="text-slate-300 text-xs font-semibold flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-[#2EE59D]" />
                En línea · Pregúntame sobre el reto o cualquier duda de código
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1">
            <button 
              onClick={handleResetChat}
              className="p-2 text-slate-300 hover:text-white hover:bg-white/10 rounded-xl transition cursor-pointer"
              title="Reiniciar chat con el tutor"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
            <button 
              onClick={onClose}
              className="p-2 text-slate-300 hover:text-white hover:bg-white/10 rounded-xl transition cursor-pointer"
              title="Cerrar panel de tutor"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </header>

        {/* Challenge Summary Banner */}
        {question && (
          <div className="bg-white dark:bg-[#131F2E] border-b border-slate-200 dark:border-slate-800 px-4 py-2.5 shrink-0 transition">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 min-w-0">
                <span className="bg-emerald-100 dark:bg-emerald-950/60 text-[#007832] dark:text-[#2EE59D] border border-emerald-300 dark:border-emerald-800 font-black text-[10px] px-2 py-0.5 rounded-md uppercase tracking-wider shrink-0 flex items-center gap-1">
                  <Lightbulb className="w-3 h-3 text-amber-500" />
                  Reto {questionIndex + 1}/{totalQuestions}
                </span>
                <span className="font-bold text-xs text-[#00283d] dark:text-slate-200 truncate">
                  {question.title}
                </span>
              </div>

              <div className="flex items-center gap-1.5 shrink-0">
                <button 
                  onClick={() => handleSendMessage(undefined, 'explain')}
                  className="text-[11px] font-black text-[#007832] dark:text-[#2EE59D] hover:text-emerald-700 bg-emerald-50 dark:bg-emerald-950/40 hover:bg-emerald-100 dark:hover:bg-emerald-950/80 px-2.5 py-1 rounded-xl border border-emerald-200 dark:border-emerald-800 transition flex items-center gap-1 cursor-pointer"
                >
                  <BookOpen className="w-3 h-3" />
                  Explicar
                </button>
                <button 
                  onClick={() => setShowQuestionCard(!showQuestionCard)}
                  className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-md cursor-pointer"
                  title={showQuestionCard ? "Ocultar enunciado" : "Ver enunciado"}
                >
                  {showQuestionCard ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {showQuestionCard && (
              <div className="mt-2 pt-2 border-t border-slate-100 dark:border-slate-800 text-xs text-slate-600 dark:text-slate-300 leading-relaxed bg-[#F8FAFC] dark:bg-[#0B131E] p-3 rounded-2xl border border-slate-200 dark:border-slate-800">
                <p className="font-semibold text-[#00283d] dark:text-slate-100 mb-1.5">{question.description}</p>
                {question.initialCode && (
                  <div className="font-mono text-[11px] bg-[#001724] text-[#2EE59D] p-2.5 rounded-xl border border-slate-700 overflow-x-auto max-h-24">
                    {question.initialCode}
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {/* CHAT MESSAGES STREAM */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.map((msg) => {
            const isTutor = msg.sender === 'tutor';
            const isSpeaking = isSpeakingMessageId === msg.id;

            return (
              <motion.div 
                key={msg.id} 
                initial={{ opacity: 0, y: 12, scale: 0.98 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                transition={{ duration: 0.25 }}
                className={`flex gap-3 ${isTutor ? 'items-start' : 'items-start flex-row-reverse'}`}
              >
                {/* Avatar Icon with Framer Motion Entrance */}
                {isTutor ? (
                  <motion.div 
                    initial={{ scale: 0, rotate: -20, opacity: 0 }}
                    animate={{ scale: 1, rotate: 0, opacity: 1 }}
                    transition={{ type: "spring", stiffness: 360, damping: 20 }}
                    className="w-9 h-9 rounded-2xl bg-gradient-to-tr from-[#021824] via-[#052b3d] to-[#043d4d] border border-emerald-400/40 p-0.5 flex items-center justify-center shrink-0 shadow-sm"
                  >
                    <NodoTutorAvatar
                      size="xs"
                      emotion={isSpeaking ? 'explaining' : 'happy'}
                      showHoloTablet={false}
                      isResponding={isSpeaking}
                    />
                  </motion.div>
                ) : (
                  <div className="w-9 h-9 rounded-2xl bg-[#00283d] text-[#2EE59D] font-black text-xs flex items-center justify-center shrink-0 shadow-sm border border-slate-300 dark:border-slate-700">
                    Tú
                  </div>
                )}

                {/* Bubble Container */}
                <div 
                  className={`max-w-[85%] sm:max-w-[88%] rounded-3xl p-4 shadow-xs text-xs sm:text-sm leading-relaxed ${
                    isTutor 
                      ? 'bg-white dark:bg-[#131F2E] text-slate-800 dark:text-slate-100 border-2 border-slate-200/90 dark:border-slate-800 rounded-tl-sm' 
                      : 'bg-gradient-to-br from-[#00324D] to-[#014264] dark:from-[#00476e] dark:to-[#002e48] text-white rounded-tr-sm shadow-md border-2 border-emerald-400/40'
                  }`}
                >
                  {isTutor ? (
                    <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-100 dark:border-slate-800 text-[10px] text-slate-400 font-bold uppercase tracking-wider">
                      <span className="text-[#007832] dark:text-[#2EE59D] flex items-center gap-1 font-black">
                        <span className="w-1.5 h-1.5 rounded-full bg-[#2EE59D] inline-block"></span>
                        Nodo Bot · Tutor
                      </span>
                      <button 
                        onClick={() => toggleSpeech(msg.id, msg.text)}
                        className={`flex items-center gap-1 px-2 py-0.5 rounded-lg transition font-black text-[10px] cursor-pointer ${
                          isSpeaking 
                            ? 'bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300' 
                            : 'hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500 dark:text-slate-400'
                        }`}
                        title={isSpeaking ? "Silenciar" : "Escuchar en voz alta"}
                      >
                        {isSpeaking ? (
                          <>
                            <VolumeX className="w-3.5 h-3.5 text-amber-600 animate-pulse" />
                            <span>Silenciar</span>
                          </>
                        ) : (
                          <>
                            <Volume2 className="w-3.5 h-3.5 text-[#007832] dark:text-[#2EE59D]" />
                            <span>Escuchar</span>
                          </>
                        )}
                      </button>
                    </div>
                  ) : (
                    <div className="flex items-center justify-between pb-1.5 mb-2 border-b border-white/20 text-[10px] font-bold uppercase tracking-wider">
                      <span className="text-[#2EE59D] flex items-center gap-1 font-black">
                        <span>💬</span> Tu pregunta
                      </span>
                    </div>
                  )}

                  {/* Message content */}
                  <div>
                    {renderMessageContent(msg.text, msg.id, !isTutor)}
                  </div>

                  <div className={`mt-2 text-[10px] flex items-center justify-end font-medium ${isTutor ? 'text-slate-400 dark:text-slate-500' : 'text-emerald-200/80'}`}>
                    {new Intl.DateTimeFormat('es-CO', { hour: '2-digit', minute: '2-digit' }).format(msg.timestamp)}
                  </div>
                </div>
              </motion.div>
            );
          })}

          {/* Loading Indicator with Animated Robot Thinking State */}
          {isLoading && (
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex gap-3 items-start"
            >
              <div className="w-9 h-9 rounded-2xl bg-[#021824] border border-cyan-400/50 p-0.5 flex items-center justify-center shrink-0">
                <NodoTutorAvatar size="xs" emotion="thinking" showHoloTablet={false} />
              </div>
              <div className="bg-white dark:bg-[#131F2E] border-2 border-emerald-300 dark:border-emerald-800 rounded-3xl rounded-tl-sm p-4 shadow-sm max-w-[85%] flex items-center gap-3">
                <div className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-[#2EE59D] animate-bounce" style={{ animationDelay: '0ms' }} />
                  <span className="w-2.5 h-2.5 rounded-full bg-[#00E5FF] animate-bounce" style={{ animationDelay: '150ms' }} />
                  <span className="w-2.5 h-2.5 rounded-full bg-[#007832] animate-bounce" style={{ animationDelay: '300ms' }} />
                </div>
                <span className="text-xs text-[#00283d] dark:text-slate-200 font-bold">
                  Nodo Bot está analizando tu consulta...
                </span>
              </div>
            </motion.div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* QUICK SUGGESTIONS PILLS */}
        <div className="bg-slate-50 dark:bg-[#0E1724] border-t border-slate-200 dark:border-slate-800 px-3 py-2 shrink-0">
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
            {quickPrompts.map((p, idx) => (
              <button
                key={idx}
                disabled={isLoading}
                onClick={() => handleSendMessage(p.text, p.mode)}
                className="shrink-0 bg-white dark:bg-[#131F2E] hover:bg-emerald-50 dark:hover:bg-[#1A2A3E] hover:border-[#2EE59D] hover:text-[#007832] dark:hover:text-[#2EE59D] text-[#00283d] dark:text-slate-200 font-black text-[11px] px-3 py-1.5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xs transition disabled:opacity-50 cursor-pointer"
              >
                {p.label}
              </button>
            ))}
          </div>
        </div>

        {/* BOTTOM INPUT BAR */}
        <footer className="bg-white dark:bg-[#131F2E] border-t-2 border-slate-200 dark:border-slate-800 p-3 sm:p-4 shrink-0 shadow-lg">
          <form 
            onSubmit={(e) => { e.preventDefault(); handleSendMessage(); }}
            className="flex items-center gap-2"
          >
            <div className="relative flex-1">
              <input
                ref={inputRef}
                type="text"
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Pregúntale a Nodo Bot sobre este reto, errores o cualquier tema de código..."
                disabled={isLoading}
                className="w-full bg-[#F4F6F9] dark:bg-[#0B131E] border-2 border-slate-200 dark:border-slate-700 focus:border-[#2EE59D] focus:bg-white dark:focus:bg-[#0B131E] rounded-2xl px-4 py-3 text-xs sm:text-sm text-[#00283d] dark:text-white placeholder-slate-400 font-semibold outline-hidden transition shadow-inner"
              />
            </div>

            <button
              type="submit"
              disabled={isLoading || !inputValue.trim()}
              className="bg-[#2EE59D] hover:bg-[#20ce8a] active:translate-y-0.5 text-[#00283d] font-black p-3 sm:px-5 sm:py-3 rounded-2xl shadow-sm transition flex items-center justify-center gap-2 disabled:opacity-40 disabled:pointer-events-none shrink-0 cursor-pointer border-b-2 border-emerald-600"
              title="Enviar pregunta"
            >
              <Send className="w-4 h-4" />
              <span className="hidden sm:inline text-xs uppercase tracking-wider font-black">Preguntar</span>
            </button>
          </form>

          <div className="mt-2 flex items-center justify-between text-[10px] text-slate-400 dark:text-slate-500 font-medium px-1">
            <span>💡 Pregunta libre: ¡respondo cualquier duda de programación!</span>
            <span className="font-bold text-[#007832] dark:text-[#2EE59D]">Nodo Bot v2.0</span>
          </div>
        </footer>
      </aside>
    </>
  );
}
