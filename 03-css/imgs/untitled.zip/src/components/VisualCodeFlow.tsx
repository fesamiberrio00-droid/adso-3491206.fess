import React from 'react';
import { motion } from 'motion/react';
import { GitCommit, ArrowRight, Layers, Sparkles } from 'lucide-react';

interface FlowStep {
  step: number;
  title: string;
  desc: string;
  highlightCode?: string;
  color: string;
}

interface SemanticHighlight {
  token: string;
  label: string;
  color: string;
}

interface VisualCodeFlowProps {
  visualDiagram?: string;
  flowSteps?: FlowStep[];
  semanticHighlights?: SemanticHighlight[];
}

export default function VisualCodeFlow({
  visualDiagram,
  flowSteps = [],
  semanticHighlights = []
}: VisualCodeFlowProps) {
  if (!visualDiagram && flowSteps.length === 0 && semanticHighlights.length === 0) {
    return null;
  }

  return (
    <div className="space-y-3.5 my-4">
      {/* Code Flow Map with Semantic Color Badges */}
      {flowSteps.length > 0 && (
        <div className="p-4 rounded-2xl bg-gradient-to-br from-[#001724] via-[#002235] to-[#012b40] border-2 border-cyan-500/30 text-white shadow-md">
          <div className="flex items-center justify-between pb-2.5 mb-3 border-b border-cyan-500/20 text-xs">
            <span className="font-black uppercase tracking-wider text-cyan-400 flex items-center gap-1.5">
              <Layers className="w-4 h-4 text-cyan-400 animate-pulse" />
              Mapa de Flujo Visual del Código (Paso a Paso)
            </span>
            <span className="text-[10px] text-cyan-200/70 bg-cyan-950/80 px-2 py-0.5 rounded-full border border-cyan-800">
              {flowSteps.length} Nodos de Ejecución
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
            {flowSteps.map((fs, idx) => (
              <motion.div
                key={fs.step || idx}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.08 }}
                className="relative p-3 rounded-xl bg-[#00121d]/90 border border-slate-700/80 hover:border-cyan-400/60 transition group flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <span 
                      className="text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full text-white"
                      style={{ backgroundColor: fs.color || '#00e5ff' }}
                    >
                      Paso {fs.step || idx + 1}
                    </span>
                    {idx < flowSteps.length - 1 && (
                      <ArrowRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-cyan-400 hidden lg:block" />
                    )}
                  </div>

                  <h5 className="font-bold text-xs text-white mb-1">{fs.title}</h5>
                  <p className="text-[11px] text-slate-300 leading-snug">{fs.desc}</p>
                </div>

                {fs.highlightCode && (
                  <div className="mt-2 pt-1.5 border-t border-slate-800 font-mono text-[10px] text-emerald-400 bg-black/40 px-2 py-1 rounded">
                    <code>{fs.highlightCode}</code>
                  </div>
                )}
              </motion.div>
            ))}
          </div>
        </div>
      )}

      {/* Semantic Highlighting Legend */}
      {semanticHighlights.length > 0 && (
        <div className="p-3 bg-[#021b29] border border-cyan-900/50 rounded-xl flex items-center gap-3 flex-wrap text-xs">
          <span className="text-[10px] font-black uppercase tracking-wider text-cyan-300 flex items-center gap-1">
            <Sparkles className="w-3 h-3 text-cyan-400" />
            Guía de Colores Semánticos:
          </span>
          <div className="flex items-center gap-2 flex-wrap">
            {semanticHighlights.map((sh, idx) => (
              <span
                key={idx}
                className="px-2 py-0.5 rounded-md font-mono text-[11px] font-bold border"
                style={{
                  backgroundColor: `${sh.color}15`,
                  color: sh.color,
                  borderColor: `${sh.color}40`
                }}
              >
                <code>{sh.token}</code>: <span className="font-sans font-medium text-slate-300">{sh.label}</span>
              </span>
            ))}
          </div>
        </div>
      )}

      {/* ASCII / Graphical Visual Diagram */}
      {visualDiagram && (
        <div className="p-4 rounded-2xl bg-[#00121d] text-cyan-300 font-mono text-xs border border-cyan-800/60 shadow-inner overflow-x-auto">
          <div className="flex items-center justify-between text-[10px] font-sans font-black uppercase tracking-wider text-cyan-200 mb-2 border-b border-cyan-900/80 pb-1.5">
            <span className="flex items-center gap-1.5 text-cyan-400">
              📐 DIAGRAMA ÓPTICO Y RELACIONES ESPACIALES
            </span>
            <span className="text-slate-400">Modelo Cognitivo Visual</span>
          </div>
          <pre className="whitespace-pre leading-relaxed select-none text-[#2EE59D]">{visualDiagram}</pre>
        </div>
      )}
    </div>
  );
}
