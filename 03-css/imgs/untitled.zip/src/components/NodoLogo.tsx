import React from 'react';

interface NodoLogoProps {
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  theme?: 'dark' | 'light' | 'auto';
  showTagline?: boolean;
  iconOnly?: boolean;
  className?: string;
}

export default function NodoLogo({
  size = 'md',
  theme = 'light',
  showTagline = true,
  iconOnly = false,
  className = ''
}: NodoLogoProps) {
  // Dimensions map
  const sizeMap = {
    xs: { icon: 24, text: 'text-sm', tag: 'text-[9px]', gap: 'gap-2' },
    sm: { icon: 32, text: 'text-lg', tag: 'text-[10px]', gap: 'gap-2.5' },
    md: { icon: 42, text: 'text-2xl', tag: 'text-xs', gap: 'gap-3' },
    lg: { icon: 54, text: 'text-3xl', tag: 'text-sm', gap: 'gap-3.5' },
    xl: { icon: 72, text: 'text-4xl', tag: 'text-base', gap: 'gap-4' },
  };

  const currentSize = sizeMap[size];
  const isDark = theme === 'dark';

  return (
    <div className={`flex items-center ${currentSize.gap} select-none ${className}`}>
      {/* Iconic Connected 'N' Node Mark from user logo */}
      <svg
        width={currentSize.icon}
        height={currentSize.icon}
        viewBox="0 0 100 100"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="shrink-0 transition-transform duration-300 hover:scale-105"
      >
        <defs>
          {/* Gradient for left column (mint green) */}
          <linearGradient id="nodoGradLeft" x1="20" y1="20" x2="20" y2="80" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#2EE59D" />
            <stop offset="100%" stopColor="#14D89A" />
          </linearGradient>

          {/* Gradient for diagonal connector (mint to cyan) */}
          <linearGradient id="nodoGradDiag" x1="20" y1="20" x2="80" y2="80" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#2EE59D" />
            <stop offset="50%" stopColor="#14E2B8" />
            <stop offset="100%" stopColor="#00C9FF" />
          </linearGradient>

          {/* Gradient for right column (cyan to electric blue) */}
          <linearGradient id="nodoGradRight" x1="80" y1="20" x2="80" y2="80" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#00E5FF" />
            <stop offset="100%" stopColor="#00B4FF" />
          </linearGradient>

          {/* Subtle glow filter */}
          <filter id="nodoGlow" x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="3" result="blur" />
            <feComposite in="SourceGraphic" in2="blur" operator="over" />
          </filter>
        </defs>

        {/* CONNECTING BARS (thick rounded pipes connecting nodes) */}
        {/* Left vertical bar */}
        <line
          x1="24"
          y1="24"
          x2="24"
          y2="76"
          stroke="url(#nodoGradLeft)"
          strokeWidth="11"
          strokeLinecap="round"
        />

        {/* Diagonal bar */}
        <line
          x1="24"
          y1="24"
          x2="76"
          y2="76"
          stroke="url(#nodoGradDiag)"
          strokeWidth="11"
          strokeLinecap="round"
        />

        {/* Right vertical bar */}
        <line
          x1="76"
          y1="24"
          x2="76"
          y2="76"
          stroke="url(#nodoGradRight)"
          strokeWidth="11"
          strokeLinecap="round"
        />

        {/* 5 GLOWING NODES (circles with soft 3D highlights) */}
        {/* 1. Top-Left Node */}
        <circle cx="24" cy="24" r="14" fill="#2EE59D" />
        <circle cx="21" cy="21" r="5" fill="#ffffff" fillOpacity="0.5" />

        {/* 2. Bottom-Left Node */}
        <circle cx="24" cy="76" r="14" fill="#2EE59D" />
        <circle cx="21" cy="73" r="5" fill="#ffffff" fillOpacity="0.5" />

        {/* 3. Center Diagonal Node */}
        <circle cx="50" cy="50" r="14.5" fill="#14E2B8" filter="url(#nodoGlow)" />
        <circle cx="47" cy="47" r="5" fill="#ffffff" fillOpacity="0.55" />

        {/* 4. Top-Right Node */}
        <circle cx="76" cy="24" r="14" fill="#00E5FF" />
        <circle cx="73" cy="21" r="5" fill="#ffffff" fillOpacity="0.5" />

        {/* 5. Bottom-Right Node */}
        <circle cx="76" cy="76" r="14" fill="#00B4FF" />
        <circle cx="73" cy="73" r="5" fill="#ffffff" fillOpacity="0.5" />
      </svg>

      {/* Typography: "NODO" + "Aprende a programar" */}
      {!iconOnly && (
        <div className="flex flex-col leading-none">
          <div className={`font-black tracking-tight flex items-center ${currentSize.text}`}>
            {/* Letters "NOD" */}
            <span className={isDark ? 'text-white' : 'text-[#00283d]'}>
              NOD
            </span>

            {/* Special Orbital 'O' */}
            <span className="relative inline-flex items-center justify-center text-[#2EE59D] ml-0.5">
              <svg 
                viewBox="0 0 40 40" 
                className="w-[1em] h-[1em] inline-block align-middle"
                fill="none" 
                xmlns="http://www.w3.org/2000/svg"
              >
                {/* Main letter O circle */}
                <circle 
                  cx="20" 
                  cy="20" 
                  r="13" 
                  stroke="#2EE59D" 
                  strokeWidth="5.5" 
                />

                {/* Satellite 1: Top-Right orbit line & node */}
                <line 
                  x1="29" 
                  y1="11" 
                  x2="35" 
                  y2="5" 
                  stroke="#2EE59D" 
                  strokeWidth="2.5" 
                  strokeLinecap="round" 
                />
                <circle cx="36" cy="4" r="3" fill="#2EE59D" />

                {/* Satellite 2: Bottom-Left orbit line & node */}
                <line 
                  x1="11" 
                  y1="29" 
                  x2="5" 
                  y2="35" 
                  stroke="#2EE59D" 
                  strokeWidth="2.5" 
                  strokeLinecap="round" 
                />
                <circle cx="4" cy="36" r="3" fill="#2EE59D" />
              </svg>
            </span>
          </div>

          {/* Subtitle / Tagline from official logo */}
          {showTagline && (
            <span 
              className={`font-semibold tracking-wide mt-1 ${currentSize.tag} ${
                isDark ? 'text-slate-300' : 'text-slate-500'
              }`}
            >
              Aprende a programar
            </span>
          )}
        </div>
      )}
    </div>
  );
}
