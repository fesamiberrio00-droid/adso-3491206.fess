import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Check, 
  ArrowRight, 
  ArrowLeft, 
  Sparkles, 
  Volume2, 
  VolumeX, 
  RotateCcw, 
  Lightbulb, 
  CheckCircle2, 
  Target,
  Trophy,
  Brain,
  Zap,
  Play,
  Eye,
  Music,
  Cpu,
  Users,
  ShieldCheck,
  HelpCircle,
  Layers,
  Radio,
  Share2,
  Lock,
  Unlock,
  Sliders,
  CheckCheck,
  GitBranch,
  Activity,
  Flame
} from 'lucide-react';
import { LearningStyleType, LearningStyleResult, LearningStyleScore } from '../types';
import { LEARNING_STYLES_INFO } from '../data/learningStylesData';
import NodoTutorAvatar from './NodoTutorAvatar';

interface LearningStyleAssessmentProps {
  key?: React.Key;
  onComplete: (result: LearningStyleResult) => void;
  initialResult?: LearningStyleResult | null;
  onSkipOrContinue?: () => void;
  onReset?: () => void;
  userEmail?: string;
  userName?: string;
}

// 7 Interactive Challenge Stages for Deep & Bimodal Evaluation
type ChallengeStage = 
  | 'intro' 
  | 'visual' 
  | 'visual_flow' 
  | 'auditory' 
  | 'auditory_rhythm' 
  | 'logic' 
  | 'bimodal' 
  | 'social' 
  | 'result';

export default function LearningStyleAssessment({ 
  onComplete, 
  initialResult,
  onSkipOrContinue,
  onReset,
  userEmail,
  userName
}: LearningStyleAssessmentProps) {
  // Current active stage
  const [stage, setStage] = useState<ChallengeStage>(initialResult ? 'result' : 'intro');
  const [result, setResult] = useState<LearningStyleResult | null>(initialResult || null);
  const [isMuted, setIsMuted] = useState(false);

  // Performance metrics across all challenges
  // 1. Visual 1: Laser Prism
  const [visualMetric, setVisualMetric] = useState<{
    solved: boolean;
    timeSeconds: number;
    attempts: number;
    selectedPiece: string | null;
  }>({
    solved: false,
    timeSeconds: 0,
    attempts: 0,
    selectedPiece: null
  });

  // 2. Visual 2: Data Flow Map & Branching
  const [visualFlowMetric, setVisualFlowMetric] = useState<{
    solved: boolean;
    selectedTerminal: string | null;
    attempts: number;
    timeSeconds: number;
  }>({
    solved: false,
    selectedTerminal: null,
    attempts: 0,
    timeSeconds: 0
  });

  // 3. Auditory 1: Tone Sequence (Simon 4 notes)
  const [auditoryMetric, setAuditoryMetric] = useState<{
    solved: boolean;
    listenedCount: number;
    attempts: number;
    userSequence: number[];
  }>({
    solved: false,
    listenedCount: 0,
    attempts: 0,
    userSequence: []
  });

  // 4. Auditory 2: Rhythm & Cadence Pulses
  const [rhythmMetric, setRhythmMetric] = useState<{
    solved: boolean;
    userTaps: number;
    attempts: number;
  }>({
    solved: false,
    userTaps: 0,
    attempts: 0
  });

  // 5. Logic: Gate Switches (A, B, C)
  const [logicMetric, setLogicMetric] = useState<{
    solved: boolean;
    switchA: boolean;
    switchB: boolean;
    switchC: boolean;
    movesCount: number;
  }>({
    solved: false,
    switchA: false,
    switchB: false,
    switchC: true, // starts with purger C ON
    movesCount: 0
  });

  // 6. Bimodal: Synchronized Audiovisual Test
  const [bimodalMetric, setBimodalMetric] = useState<{
    solved: boolean;
    userStep: number[];
    attempts: number;
  }>({
    solved: false,
    userStep: [],
    attempts: 0
  });

  // 7. Social: Ship Collaboration Dilemma
  const [socialMetric, setSocialMetric] = useState<{
    choice: 'colaborativo' | 'autonomo' | 'coordinador' | null;
    synergyScore: number;
    explanation: string;
  }>({
    choice: null,
    synergyScore: 80,
    explanation: ''
  });

  // Audio Context Ref for synthesizer sounds
  const audioCtxRef = useRef<AudioContext | null>(null);

  const getAudioContext = () => {
    if (!audioCtxRef.current) {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      audioCtxRef.current = new AudioContextClass();
    }
    if (audioCtxRef.current.state === 'suspended') {
      audioCtxRef.current.resume();
    }
    return audioCtxRef.current;
  };

  // Sound generator for musical notes and laser beeps
  const playTone = (freq: number, durationMs = 250, type: OscillatorType = 'sine', gainVal = 0.12) => {
    if (isMuted) return;
    try {
      const ctx = getAudioContext();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = type;
      osc.frequency.setValueAtTime(freq, ctx.currentTime);

      gain.gain.setValueAtTime(gainVal, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + durationMs / 1000);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start();
      osc.stop(ctx.currentTime + durationMs / 1000);
    } catch {
      // Audio not permitted yet
    }
  };

  const playSuccessChord = () => {
    if (isMuted) return;
    try {
      const notes = [261.63, 329.63, 392.00, 523.25];
      notes.forEach((freq, i) => {
        setTimeout(() => playTone(freq, 350, 'triangle', 0.1), i * 80);
      });
    } catch {}
  };

  // Sync initialResult
  useEffect(() => {
    if (initialResult) {
      setResult(initialResult);
      setStage('result');
    }
  }, [initialResult]);

  // Timers for tests
  useEffect(() => {
    let timer: any;
    if (stage === 'visual' && !visualMetric.solved) {
      timer = setInterval(() => {
        setVisualMetric(prev => ({ ...prev, timeSeconds: prev.timeSeconds + 1 }));
      }, 1000);
    } else if (stage === 'visual_flow' && !visualFlowMetric.solved) {
      timer = setInterval(() => {
        setVisualFlowMetric(prev => ({ ...prev, timeSeconds: prev.timeSeconds + 1 }));
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [stage, visualMetric.solved, visualFlowMetric.solved]);

  // =========================================================================
  // 1. DESAFÍO VISUAL 1: HAZ DE LUZ LÁSER Y PRISMAS
  // =========================================================================
  const availablePrisms = [
    { id: 'p_flat', name: 'Prisma Plano', angle: '0°', icon: '▬', color: 'border-slate-400', isCorrect: false },
    { id: 'p_angle', name: 'Prisma Triangular Reflectivo', angle: '90° Óptico', icon: '◢', color: 'border-[#2EE59D]', isCorrect: true },
    { id: 'p_diffuse', name: 'Prisma Difusor Opaco', angle: 'Dispersión', icon: '░', color: 'border-purple-400', isCorrect: false }
  ];

  const handleSelectPrism = (pieceId: string) => {
    const piece = availablePrisms.find(p => p.id === pieceId);
    if (!piece) return;

    playTone(piece.isCorrect ? 880 : 220, 150, 'sawtooth', 0.1);

    if (piece.isCorrect) {
      setVisualMetric(prev => ({
        ...prev,
        solved: true,
        selectedPiece: pieceId
      }));
      playSuccessChord();
    } else {
      setVisualMetric(prev => ({
        ...prev,
        attempts: prev.attempts + 1,
        selectedPiece: pieceId
      }));
    }
  };

  // =========================================================================
  // 2. DESAFÍO VISUAL 2: MAPA DE FLUJO ESPACIAL Y BIFURCACIONES
  // =========================================================================
  // Data packet is #42 (Even number > 20) -> Branch Cyan (Par) -> Terminal Alpha (Verde Menta)
  const handleSelectFlowTerminal = (terminalId: 'alpha' | 'beta' | 'gamma') => {
    const isCorrect = terminalId === 'alpha';
    playTone(isCorrect ? 784 : 200, 180, isCorrect ? 'triangle' : 'sawtooth', 0.12);

    if (isCorrect) {
      setVisualFlowMetric(prev => ({
        ...prev,
        solved: true,
        selectedTerminal: terminalId
      }));
      playSuccessChord();
    } else {
      setVisualFlowMetric(prev => ({
        ...prev,
        attempts: prev.attempts + 1,
        selectedTerminal: terminalId
      }));
    }
  };

  // =========================================================================
  // 3. DESAFÍO AUDITIVO 1: NODO BEATS (SIMÓN DE 4 TONOS)
  // =========================================================================
  const synthPads = [
    { id: 0, label: 'Nota C', note: 'Do', freq: 261.63, color: 'bg-emerald-500 hover:bg-emerald-400', border: 'border-emerald-600' },
    { id: 1, label: 'Nota E', note: 'Mi', freq: 329.63, color: 'bg-cyan-500 hover:bg-cyan-400', border: 'border-cyan-600' },
    { id: 2, label: 'Nota G', note: 'Sol', freq: 392.00, color: 'bg-purple-500 hover:bg-purple-400', border: 'border-purple-600' },
    { id: 3, label: 'Nota C²', note: 'Do²', freq: 523.25, color: 'bg-amber-500 hover:bg-amber-400', border: 'border-amber-600' }
  ];

  const targetMelody = [0, 2, 1, 3]; // Do, Sol, Mi, Do²
  const [isPlayingMelody, setIsPlayingMelody] = useState(false);
  const [activePadLight, setActivePadLight] = useState<number | null>(null);
  const [auditoryStep, setAuditoryStep] = useState<number[]>([]);
  const [auditoryFeedback, setAuditoryFeedback] = useState<string>('Pulsa "Reproducir Secuencia Sonora" para escuchar la melodía de Nodo.');

  const playDemoMelody = () => {
    if (isPlayingMelody) return;
    setIsPlayingMelody(true);
    setAuditoryStep([]);
    setAuditoryFeedback('Escuchando secuencia de Nodo...');
    setAuditoryMetric(prev => ({ ...prev, listenedCount: prev.listenedCount + 1 }));

    targetMelody.forEach((padIndex, stepIdx) => {
      setTimeout(() => {
        setActivePadLight(padIndex);
        playTone(synthPads[padIndex].freq, 320, 'sine', 0.16);
      }, stepIdx * 450);

      setTimeout(() => {
        setActivePadLight(null);
        if (stepIdx === targetMelody.length - 1) {
          setIsPlayingMelody(false);
          setAuditoryFeedback('¡Ahora es tu turno! Toca las 4 notas en orden.');
        }
      }, stepIdx * 450 + 380);
    });
  };

  const handlePadPress = (padIndex: number) => {
    if (isPlayingMelody || auditoryMetric.solved) return;

    setActivePadLight(padIndex);
    playTone(synthPads[padIndex].freq, 280, 'sine', 0.14);
    setTimeout(() => setActivePadLight(null), 250);

    const nextStep = [...auditoryStep, padIndex];
    setAuditoryStep(nextStep);

    const currentPosition = nextStep.length - 1;
    if (padIndex !== targetMelody[currentPosition]) {
      playTone(150, 300, 'sawtooth', 0.1);
      setAuditoryFeedback('Nota incorrecta. ¡Vuelve a escuchar la melodía con el botón!');
      setAuditoryMetric(prev => ({ ...prev, attempts: prev.attempts + 1 }));
      setAuditoryStep([]);
      return;
    }

    if (nextStep.length === targetMelody.length) {
      setAuditoryFeedback('¡Excelente discriminación tonal! Secuencia perfecta.');
      playSuccessChord();
      setAuditoryMetric(prev => ({
        ...prev,
        solved: true,
        userSequence: nextStep
      }));
    }
  };

  // =========================================================================
  // 4. DESAFÍO AUDITIVO 2: CADENCIA Y RITMO SECUENCIAL
  // =========================================================================
  const [isPlayingRhythm, setIsPlayingRhythm] = useState(false);
  const [rhythmLight, setRhythmLight] = useState(false);
  const [userTapsCount, setUserTapsCount] = useState(0);

  const playDemoRhythm = () => {
    if (isPlayingRhythm) return;
    setIsPlayingRhythm(true);
    setUserTapsCount(0);

    // Rhythm: Tap (300ms) -- Pause (200ms) -- Tap (150ms) -- Pause (150ms) -- Long Tap (500ms)
    const beats = [
      { time: 0, dur: 220, freq: 520 },
      { time: 450, dur: 150, freq: 520 },
      { time: 750, dur: 450, freq: 659 }
    ];

    beats.forEach((b, idx) => {
      setTimeout(() => {
        setRhythmLight(true);
        playTone(b.freq, b.dur, 'sine', 0.18);
      }, b.time);
      setTimeout(() => {
        setRhythmLight(false);
        if (idx === beats.length - 1) {
          setIsPlayingRhythm(false);
        }
      }, b.time + b.dur);
    });
  };

  const handleUserTapRhythm = () => {
    if (isPlayingRhythm || rhythmMetric.solved) return;
    setRhythmLight(true);
    playTone(550, 180, 'triangle', 0.14);
    setTimeout(() => setRhythmLight(false), 160);

    const nextTaps = userTapsCount + 1;
    setUserTapsCount(nextTaps);

    if (nextTaps >= 3) {
      setRhythmMetric(prev => ({ ...prev, solved: true, userTaps: nextTaps }));
      playSuccessChord();
    }
  };

  // =========================================================================
  // 5. DESAFÍO LÓGICO: COMPUERTAS DE SEGURIDAD (CAUSA Y EFECTO)
  // =========================================================================
  const toggleLogicSwitch = (sw: 'A' | 'B' | 'C') => {
    playTone(sw === 'C' ? 340 : 440, 90, 'square', 0.07);
    setLogicMetric(prev => {
      const next = {
        ...prev,
        switchA: sw === 'A' ? !prev.switchA : prev.switchA,
        switchB: sw === 'B' ? !prev.switchB : prev.switchB,
        switchC: sw === 'C' ? !prev.switchC : prev.switchC,
        movesCount: prev.movesCount + 1
      };
      const solved = next.switchA && next.switchB && !next.switchC;
      if (solved && !prev.solved) {
        setTimeout(() => playSuccessChord(), 150);
      }
      return { ...next, solved };
    });
  };

  // =========================================================================
  // 6. DESAFÍO BIMODAL: SINCRONIZACIÓN AUDIOVISUAL (LUZ + SONIDO)
  // =========================================================================
  const bimodalNodes = [
    { id: 1, name: 'Reactor Cian', color: 'bg-cyan-500 border-cyan-400', icon: '◇', freq: 440, label: 'Luz Cian (440Hz)' },
    { id: 2, name: 'Reactor Menta', color: 'bg-emerald-500 border-emerald-400', icon: '△', freq: 554, label: 'Luz Menta (554Hz)' },
    { id: 3, name: 'Reactor Ámbar', color: 'bg-amber-500 border-amber-400', icon: '⬡', freq: 659, label: 'Luz Ámbar (659Hz)' }
  ];
  const bimodalTargetSequence = [1, 3, 2]; // Cian, Ámbar, Menta
  const [isPlayingBimodal, setIsPlayingBimodal] = useState(false);
  const [activeBimodalLight, setActiveBimodalLight] = useState<number | null>(null);

  const playDemoBimodal = () => {
    if (isPlayingBimodal) return;
    setIsPlayingBimodal(true);
    setBimodalMetric(prev => ({ ...prev, userStep: [] }));

    bimodalTargetSequence.forEach((nodeId, idx) => {
      const targetNode = bimodalNodes.find(n => n.id === nodeId)!;
      setTimeout(() => {
        setActiveBimodalLight(nodeId);
        playTone(targetNode.freq, 300, 'triangle', 0.18);
      }, idx * 550);
      setTimeout(() => {
        setActiveBimodalLight(null);
        if (idx === bimodalTargetSequence.length - 1) {
          setIsPlayingBimodal(false);
        }
      }, idx * 550 + 420);
    });
  };

  const handleBimodalNodeClick = (nodeId: number) => {
    if (isPlayingBimodal || bimodalMetric.solved) return;
    const targetNode = bimodalNodes.find(n => n.id === nodeId);
    if (!targetNode) return;

    setActiveBimodalLight(nodeId);
    playTone(targetNode.freq, 220, 'triangle', 0.15);
    setTimeout(() => setActiveBimodalLight(null), 200);

    const next = [...bimodalMetric.userStep, nodeId];
    const currentPos = next.length - 1;

    if (nodeId !== bimodalTargetSequence[currentPos]) {
      playTone(160, 250, 'sawtooth', 0.1);
      setBimodalMetric(prev => ({ ...prev, attempts: prev.attempts + 1, userStep: [] }));
      return;
    }

    if (next.length === bimodalTargetSequence.length) {
      playSuccessChord();
      setBimodalMetric(prev => ({ ...prev, solved: true, userStep: next }));
    } else {
      setBimodalMetric(prev => ({ ...prev, userStep: next }));
    }
  };

  // =========================================================================
  // 7. DESAFÍO SOCIAL: DILEMA DE LA NAVE NODO
  // =========================================================================
  const socialOptions = [
    {
      id: 'colaborativo' as const,
      title: 'Taller Co-Creativo Abierto',
      badge: '👥 Social / Colaborativo',
      icon: '🚀',
      tagline: 'Pair programming, debate y revisión grupal en tiempo real',
      description: 'Prefiero sentarme con la tripulación en la mesa de planos, contrastar hipótesis, discutir pros y contras y construir los sistemas de la nave en equipo.',
      crewReactions: ['🙌 ¡Me encanta trabajar juntos!', '💡 Gran sinergia técnica', '🤝 Dos mentes resuelven más rápido'],
      points: { social: 5, practico: 3, visual: 2, auditivo: 3 }
    },
    {
      id: 'autonomo' as const,
      title: 'Laboratorio de Prototipado Autónomo',
      badge: '⚡ Práctico / Investigador',
      icon: '🔬',
      tagline: 'Concentración individual, ensayo y error a tu propio ritmo',
      description: 'Prefiero aislarme en mi estación técnica para experimentar, probar líneas de código a solas y llevar al equipo un prototipo funcional y testeado.',
      crewReactions: ['⚡ Eficiencia y foco absoluto', '🛠️ Prototipo rápido', '🎯 Solución probada'],
      points: { practico: 5, logico: 4, visual: 3, social: 1 }
    },
    {
      id: 'coordinador' as const,
      title: 'Mesa de Arquitectura y Revisión de Planos',
      badge: '🧩 Lógico / Estratega',
      icon: '📐',
      tagline: 'Revisión crítica de especificaciones y coordinación modular',
      description: 'Prefiero revisar los esquemas creados por otros compañeros, detectar cuellos de botella lógicos, proponer optimizaciones y alinear los estándares.',
      crewReactions: ['📐 Calidad de código garantizada', '🧠 Visión arquitectónica', '✨ Cero errores en producción'],
      points: { logico: 5, social: 4, lectoescritor: 4, visual: 3 }
    }
  ];

  const handleSelectSocialOption = (choice: 'colaborativo' | 'autonomo' | 'coordinador') => {
    playTone(660, 150, 'triangle', 0.12);
    const opt = socialOptions.find(o => o.id === choice);
    setSocialMetric({
      choice,
      synergyScore: choice === 'colaborativo' ? 95 : choice === 'coordinador' ? 90 : 82,
      explanation: opt?.description || ''
    });
  };

  // =========================================================================
  // CÁLCULO FINAL DE RESULTADOS CON DETECCIÓN BIMODAL PROFUNDA
  // =========================================================================
  const handleCalculateFinalResult = () => {
    const scores: Record<LearningStyleType, number> = {
      visual: 2,
      auditivo: 2,
      logico: 2,
      practico: 2,
      social: 2,
      lectoescritor: 1
    };

    // 1. Visual 1 (Prisma láser)
    if (visualMetric.solved) {
      scores.visual += visualMetric.timeSeconds <= 12 ? 5 : 4;
      scores.practico += 2;
    }

    // 2. Visual 2 (Flujo de datos y bifurcación espacial)
    if (visualFlowMetric.solved) {
      scores.visual += visualFlowMetric.attempts === 0 ? 5 : 4;
      scores.logico += 2;
    }

    // 3. Auditivo 1 (Melodía de 4 tonos)
    if (auditoryMetric.solved) {
      scores.auditivo += auditoryMetric.attempts === 0 ? 5 : 4;
    }

    // 4. Auditivo 2 (Cadencia rítmica)
    if (rhythmMetric.solved) {
      scores.auditivo += 5;
      scores.practico += 2;
    }

    // 5. Lógica (Compuertas)
    if (logicMetric.solved) {
      scores.logico += logicMetric.movesCount <= 4 ? 5 : 4;
    }

    // 6. Prueba Bimodal (Sincronización Audiovisual)
    if (bimodalMetric.solved) {
      scores.visual += 4;
      scores.auditivo += 4;
    }

    // 7. Social (Dilema nave)
    if (socialMetric.choice === 'colaborativo') {
      scores.social += 5;
      scores.auditivo += 2;
    } else if (socialMetric.choice === 'coordinador') {
      scores.social += 4;
      scores.logico += 3;
      scores.lectoescritor += 3;
    } else if (socialMetric.choice === 'autonomo') {
      scores.practico += 5;
      scores.logico += 2;
    }

    const totalPoints = Object.values(scores).reduce((a, b) => a + b, 0);

    const breakdown: LearningStyleScore[] = (Object.keys(scores) as LearningStyleType[]).map(type => {
      const info = LEARNING_STYLES_INFO[type];
      const score = scores[type];
      const percentage = Math.round((score / totalPoints) * 100);
      return {
        ...info,
        score,
        percentage
      };
    });

    breakdown.sort((a, b) => b.percentage - a.percentage || b.score - a.score);

    const primaryStyle = breakdown[0];
    const secondaryStyle = breakdown[1] || breakdown[0];

    // Evaluate Bimodal condition: High score in both Visual and Auditory
    const visualScoreObj = breakdown.find(b => b.type === 'visual')!;
    const auditoryScoreObj = breakdown.find(b => b.type === 'auditivo')!;
    const isVisualAuditoryBimodal = 
      (visualScoreObj.percentage >= 18 && auditoryScoreObj.percentage >= 18) &&
      Math.abs(visualScoreObj.percentage - auditoryScoreObj.percentage) <= 8 &&
      (primaryStyle.type === 'visual' || primaryStyle.type === 'auditivo' || secondaryStyle.type === 'visual' || secondaryStyle.type === 'auditivo');

    const isBimodal = isVisualAuditoryBimodal;
    const bimodalTitle = isBimodal ? 'Perfil Bimodal: Audiovisual (Visual + Auditivo)' : undefined;
    const bimodalDescription = isBimodal
      ? 'Tu cerebro procesa el código en dos canales simultáneos: mapas espaciales/diagramas de flujo (canal visual) y narración verbal rítmica con la técnica del patito de goma (canal auditivo). ¡Ambas adaptaciones se mantendrán activas en tus retos!'
      : undefined;

    const recommendations: string[] = isBimodal
      ? [
          '🎯 Diagnóstico Bimodal Confirmado: Integras estímulos visuales y auditivos en paralelo.',
          '🎨 Visual: Nodo activará diagramas de flujo de datos, resaltado sintáctico de alto contraste y mapas de bifurcación.',
          '🎧 Auditivo: Nodo habilitará síntesis de voz, técnica del patito de goma (explicar código en voz alta) y efectos melódicos de refuerzo.',
          '⚡ Tus clases y retos IA combinarán de forma balanceada ambas modalidades.'
        ]
      : [
          `Tu estilo principal es ${primaryStyle.name}: ${primaryStyle.tagline}.`,
          `Complementado con tu faceta ${secondaryStyle.name}, aprovechas mejor la plataforma con explicaciones y herramientas de Nodo Bot.`,
          `En cada módulo, Nodo adaptará los recursos según tu ritmo de retención.`
        ];

    const finalResultData: LearningStyleResult = {
      primaryStyle,
      secondaryStyle,
      isBimodal,
      bimodalTitle,
      bimodalDescription,
      breakdown,
      completedAt: new Date().toISOString(),
      recommendations
    };

    setResult(finalResultData);
    setStage('result');
    onComplete(finalResultData);
    playSuccessChord();
  };

  const resetAllChallenges = () => {
    setVisualMetric({ solved: false, timeSeconds: 0, attempts: 0, selectedPiece: null });
    setVisualFlowMetric({ solved: false, selectedTerminal: null, attempts: 0, timeSeconds: 0 });
    setAuditoryMetric({ solved: false, listenedCount: 0, attempts: 0, userSequence: [] });
    setRhythmMetric({ solved: false, userTaps: 0, attempts: 0 });
    setLogicMetric({ solved: false, switchA: false, switchB: false, switchC: true, movesCount: 0 });
    setBimodalMetric({ solved: false, userStep: [], attempts: 0 });
    setSocialMetric({ choice: null, synergyScore: 80, explanation: '' });
    setStage('visual');
    if (onReset) onReset();
  };

  // =========================================================================
  // RENDER: PANTALLA INTRODUCTORIA
  // =========================================================================
  if (stage === 'intro') {
    return (
      <div className="w-full max-w-4xl mx-auto px-4 py-8 animate-fadeIn">
        <div className="bg-white dark:bg-[#0F172A] rounded-3xl border-2 border-slate-200 dark:border-slate-800 p-6 sm:p-10 shadow-sm relative overflow-hidden transition-colors">
          {/* Header Badge */}
          <div className="flex flex-wrap items-center justify-between gap-4 mb-8">
            <span className="inline-flex items-center gap-2 bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-300 dark:border-emerald-800 text-[#007832] dark:text-[#2EE59D] px-3.5 py-1.5 rounded-full text-xs font-black uppercase tracking-wider">
              <Sparkles className="w-4 h-4 text-emerald-500 animate-spin" style={{ animationDuration: '4s' }} />
              Laboratorio Cognitivo de Alta Precisión & Bimodal
            </span>

            <button
              onClick={() => setIsMuted(!isMuted)}
              className="p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition"
              title={isMuted ? 'Activar audio' : 'Silenciar beeps'}
            >
              {isMuted ? <VolumeX className="w-4 h-4 text-rose-500" /> : <Volume2 className="w-4 h-4 text-emerald-600 dark:text-[#2EE59D]" />}
            </button>
          </div>

          <div className="flex flex-col md:flex-row items-center gap-8 mb-8">
            {/* Robot Mascot */}
            <div className="relative shrink-0 w-28 h-28 sm:w-36 sm:h-36 rounded-3xl bg-gradient-to-tr from-[#021824] via-[#052b3d] to-[#043d4d] border-2 border-emerald-400/50 p-2 flex items-center justify-center shadow-lg">
              <NodoTutorAvatar size="lg" emotion="happy" showHoloTablet={true} isAnimated={true} />
              <span className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-[#2EE59D] border-2 border-white dark:border-[#0F172A] animate-pulse" />
            </div>

            <div className="space-y-3 text-center md:text-left">
              <h2 className="text-2xl sm:text-3xl font-black text-[#00283d] dark:text-white tracking-tight">
                Laboratorio Interactivo de Aprendizaje Nodo
              </h2>
              <p className="text-slate-600 dark:text-slate-300 text-sm sm:text-base leading-relaxed max-w-2xl font-medium">
                Diseñado para medir con exactitud tanto <strong>estilos puros</strong> como <strong>perfiles bimodales (Visual + Auditivo)</strong>. Resolverás una batería de desafíos prácticos en vivo: laberinto óptico, mapas de flujo de datos, sintetizador de tonos, cadencia rítmica, compuertas booleanas y el test sincronizado audiovisual.
              </p>
            </div>
          </div>

          {/* Challenges Grid Preview */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 mb-8">
            <div className="bg-[#F8FAFC] dark:bg-[#131F2E] border border-slate-200 dark:border-slate-800 rounded-2xl p-3 text-center">
              <Eye className="w-5 h-5 mx-auto mb-1 text-emerald-600 dark:text-[#2EE59D]" />
              <span className="text-[10px] font-black uppercase text-slate-400 block">1. Óptico</span>
              <span className="text-xs font-black text-[#00324D] dark:text-white">Haz Láser</span>
            </div>

            <div className="bg-[#F8FAFC] dark:bg-[#131F2E] border border-slate-200 dark:border-slate-800 rounded-2xl p-3 text-center">
              <GitBranch className="w-5 h-5 mx-auto mb-1 text-cyan-500" />
              <span className="text-[10px] font-black uppercase text-slate-400 block">2. Espacial</span>
              <span className="text-xs font-black text-[#00324D] dark:text-white">Flujo de Datos</span>
            </div>

            <div className="bg-[#F8FAFC] dark:bg-[#131F2E] border border-slate-200 dark:border-slate-800 rounded-2xl p-3 text-center">
              <Music className="w-5 h-5 mx-auto mb-1 text-purple-500" />
              <span className="text-[10px] font-black uppercase text-slate-400 block">3. Tonal</span>
              <span className="text-xs font-black text-[#00324D] dark:text-white">Sintetizador</span>
            </div>

            <div className="bg-[#F8FAFC] dark:bg-[#131F2E] border border-slate-200 dark:border-slate-800 rounded-2xl p-3 text-center">
              <Activity className="w-5 h-5 mx-auto mb-1 text-indigo-500" />
              <span className="text-[10px] font-black uppercase text-slate-400 block">4. Ritmo</span>
              <span className="text-xs font-black text-[#00324D] dark:text-white">Cadencia Pulso</span>
            </div>

            <div className="bg-[#F8FAFC] dark:bg-[#131F2E] border border-slate-200 dark:border-slate-800 rounded-2xl p-3 text-center">
              <Cpu className="w-5 h-5 mx-auto mb-1 text-sky-500" />
              <span className="text-[10px] font-black uppercase text-slate-400 block">5. Lógica</span>
              <span className="text-xs font-black text-[#00324D] dark:text-white">Compuertas</span>
            </div>

            <div className="bg-[#F8FAFC] dark:bg-[#131F2E] border border-cyan-400/40 dark:border-cyan-500/40 rounded-2xl p-3 text-center bg-cyan-50/50 dark:bg-cyan-950/20">
              <Sparkles className="w-5 h-5 mx-auto mb-1 text-cyan-600 dark:text-cyan-400 animate-spin" />
              <span className="text-[10px] font-black uppercase text-cyan-700 dark:text-cyan-300 block">6. Bimodal</span>
              <span className="text-xs font-black text-[#00324D] dark:text-white">Audiovisual</span>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-4 border-t border-slate-200 dark:border-slate-800">
            {onSkipOrContinue && (
              <button
                onClick={onSkipOrContinue}
                className="w-full sm:w-auto px-5 py-3 rounded-2xl border border-slate-300 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 font-bold text-xs uppercase tracking-wider transition cursor-pointer"
              >
                Omitir por ahora
              </button>
            )}

            <button
              onClick={() => {
                playTone(440, 150, 'sine', 0.1);
                setStage('visual');
              }}
              className="w-full sm:w-auto px-8 py-3.5 rounded-2xl bg-[#2EE59D] hover:bg-[#22d38b] active:translate-y-0.5 text-[#00283d] font-black text-sm uppercase tracking-wider shadow-md transition flex items-center justify-center gap-2 cursor-pointer border-b-2 border-emerald-600"
            >
              <Play className="w-4 h-4 fill-current" />
              <span>Comenzar Laboratorio de Pruebas</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  // =========================================================================
  // TOP STEP NAVIGATION BAR
  // =========================================================================
  const stagesList: { id: ChallengeStage; name: string; icon: React.ReactNode; num: string }[] = [
    { id: 'visual', name: 'Haz Láser', icon: <Eye className="w-3.5 h-3.5" />, num: '1' },
    { id: 'visual_flow', name: 'Flujo Espacial', icon: <GitBranch className="w-3.5 h-3.5" />, num: '2' },
    { id: 'auditory', name: 'Sintetizador', icon: <Music className="w-3.5 h-3.5" />, num: '3' },
    { id: 'auditory_rhythm', name: 'Cadencia', icon: <Activity className="w-3.5 h-3.5" />, num: '4' },
    { id: 'logic', name: 'Compuertas', icon: <Cpu className="w-3.5 h-3.5" />, num: '5' },
    { id: 'bimodal', name: 'Audiovisual', icon: <Sparkles className="w-3.5 h-3.5 text-cyan-400" />, num: '6' },
    { id: 'social', name: 'Dilema Nave', icon: <Users className="w-3.5 h-3.5" />, num: '7' },
  ];

  return (
    <div className="w-full max-w-4xl mx-auto px-4 py-6 sm:py-8">
      {/* Top Breadcrumb Steps */}
      <div className="bg-white dark:bg-[#0F172A] rounded-2xl border-2 border-slate-200 dark:border-slate-800 p-3 sm:p-4 mb-6 shadow-xs flex items-center justify-between gap-2 overflow-x-auto transition-colors">
        <div className="flex items-center gap-1.5 sm:gap-2.5 shrink-0">
          {stagesList.map((st) => {
            const isActive = stage === st.id;
            const isDone = 
              (st.id === 'visual' && visualMetric.solved) ||
              (st.id === 'visual_flow' && visualFlowMetric.solved) ||
              (st.id === 'auditory' && auditoryMetric.solved) ||
              (st.id === 'auditory_rhythm' && rhythmMetric.solved) ||
              (st.id === 'logic' && logicMetric.solved) ||
              (st.id === 'bimodal' && bimodalMetric.solved) ||
              (st.id === 'social' && socialMetric.choice !== null);

            return (
              <div 
                key={st.id}
                className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-black transition ${
                  isActive 
                    ? 'bg-[#00283d] text-white dark:bg-[#2EE59D] dark:text-[#00283d] shadow-xs'
                    : isDone
                      ? 'bg-emerald-50 dark:bg-emerald-950/60 text-[#007832] dark:text-[#2EE59D] border border-emerald-300 dark:border-emerald-800'
                      : 'text-slate-400 dark:text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                <span>{isDone ? '✓' : st.num}.</span>
                {st.icon}
                <span className="hidden lg:inline">{st.name}</span>
              </div>
            );
          })}
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={() => setIsMuted(!isMuted)}
            className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
            title={isMuted ? 'Activar sonido' : 'Silenciar'}
          >
            {isMuted ? <VolumeX className="w-4 h-4 text-rose-500" /> : <Volume2 className="w-4 h-4 text-emerald-600 dark:text-[#2EE59D]" />}
          </button>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 1. DESAFÍO VISUAL 1: HAZ DE LUZ LÁSER */}
      {/* ========================================================================= */}
      {stage === 'visual' && (
        <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white dark:bg-[#0F172A] rounded-3xl border-2 border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-sm transition-colors"
        >
          <div className="flex flex-wrap items-center justify-between gap-3 mb-6">
            <div>
              <span className="text-[11px] font-black uppercase tracking-wider text-emerald-600 dark:text-[#2EE59D] bg-emerald-50 dark:bg-emerald-950/60 px-2.5 py-1 rounded-md border border-emerald-200 dark:border-emerald-800">
                Fase 1 de 7 · Prueba Visual Óptica
              </span>
              <h3 className="text-xl sm:text-2xl font-black text-[#00283d] dark:text-white mt-1">
                Conecta el Haz de Luz Fotónico al Núcleo Receptor
              </h3>
            </div>
            <div className="flex items-center gap-2 text-xs font-mono text-slate-500 dark:text-slate-400 bg-slate-100 dark:bg-slate-800 px-3 py-1.5 rounded-xl">
              <span>Tiempo: {visualMetric.timeSeconds}s</span>
            </div>
          </div>

          <p className="text-sm text-slate-600 dark:text-slate-300 font-medium mb-6">
            Un haz láser viaja horizontalmente. Selecciona y coloca el prisma óptico con el ángulo reflector adecuado en la ranura central para desviar el haz hacia el núcleo receptor verde en la parte inferior.
          </p>

          {/* Interactive Optical Laser Grid */}
          <div className="relative w-full h-64 bg-slate-900 rounded-3xl p-6 overflow-hidden border-2 border-slate-800 shadow-inner flex flex-col justify-between mb-6">
            {/* Background Optical Circuit Lines */}
            <div className="absolute inset-0 opacity-15 pointer-events-none" style={{ backgroundImage: 'radial-gradient(#2EE59D 1px, transparent 1px)', backgroundSize: '20px 20px' }} />

            {/* Top row: Transmitter & Slot */}
            <div className="relative z-10 flex items-center justify-between">
              {/* Transmitter */}
              <div className="flex items-center gap-2">
                <div className="w-10 h-10 rounded-xl bg-cyan-500/20 border-2 border-cyan-400 flex items-center justify-center text-cyan-300 shadow-cyan-500/50 shadow-md">
                  <Zap className="w-5 h-5 animate-pulse" />
                </div>
                <div className="text-[10px] font-mono text-cyan-300 font-bold uppercase">
                  Emisor Fotónico [0,0]
                </div>
              </div>

              {/* Slot */}
              <div className={`w-16 h-16 rounded-2xl border-2 flex flex-col items-center justify-center transition-all ${
                visualMetric.solved 
                  ? 'border-[#2EE59D] bg-[#2EE59D]/20 shadow-[#2EE59D]/40 shadow-lg' 
                  : 'border-dashed border-slate-600 bg-slate-800/80'
              }`}>
                {visualMetric.selectedPiece ? (
                  <span className="text-3xl text-white">
                    {availablePrisms.find(p => p.id === visualMetric.selectedPiece)?.icon}
                  </span>
                ) : (
                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Ranura</span>
                )}
              </div>
            </div>

            {/* Bottom row: Target Sensor */}
            <div className="relative z-10 flex justify-end">
              <div className={`px-4 py-2.5 rounded-2xl border-2 flex items-center gap-3 transition-all ${
                visualMetric.solved 
                  ? 'border-emerald-400 bg-emerald-500/30 text-emerald-200 shadow-lg shadow-emerald-500/30' 
                  : 'border-slate-700 bg-slate-800/50 text-slate-400'
              }`}>
                <div className={`w-3.5 h-3.5 rounded-full ${visualMetric.solved ? 'bg-emerald-400 animate-ping' : 'bg-slate-600'}`} />
                <span className="font-mono text-xs font-black uppercase tracking-wider">
                  {visualMetric.solved ? '✓ Núcleo Receptor Activado' : 'Sensor Receptor (Esperando Haz)'}
                </span>
              </div>
            </div>
          </div>

          {/* Available Pieces */}
          <div className="mb-6">
            <span className="text-xs font-black uppercase tracking-wider text-slate-400 dark:text-slate-500 block mb-3">
              Selecciona el prisma óptico reflector:
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {availablePrisms.map(prism => (
                <button
                  key={prism.id}
                  onClick={() => handleSelectPrism(prism.id)}
                  disabled={visualMetric.solved}
                  className={`p-4 rounded-2xl border-2 transition-all flex items-center gap-3 text-left cursor-pointer ${
                    visualMetric.selectedPiece === prism.id
                      ? prism.isCorrect 
                        ? 'border-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-200'
                        : 'border-rose-400 bg-rose-50 dark:bg-rose-950/40 text-rose-800 dark:text-rose-200'
                      : 'border-slate-200 dark:border-slate-800 hover:border-slate-400 bg-[#F8FAFC] dark:bg-[#131F2E]'
                  }`}
                >
                  <span className="text-2xl font-mono">{prism.icon}</span>
                  <div>
                    <h5 className="font-black text-xs text-[#00324D] dark:text-white">{prism.name}</h5>
                    <span className="text-[10px] text-slate-500 font-mono">{prism.angle}</span>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Advance button */}
          <div className="flex justify-end pt-4 border-t border-slate-200 dark:border-slate-800">
            <button
              onClick={() => {
                playTone(440, 100, 'sine', 0.1);
                setStage('visual_flow');
              }}
              disabled={!visualMetric.solved}
              className="px-6 py-3 rounded-2xl bg-[#2EE59D] hover:bg-[#20ce8a] active:translate-y-0.5 text-[#00283d] font-black text-xs uppercase tracking-wider shadow-md transition flex items-center gap-2 disabled:opacity-40 disabled:pointer-events-none cursor-pointer border-b-2 border-emerald-600"
            >
              <span>Siguiente: Flujo Espacial</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </motion.div>
      )}

      {/* ========================================================================= */}
      {/* 2. DESAFÍO VISUAL 2: MAPA DE FLUJO Y BIFURCACIÓN ESPACIAL */}
      {/* ========================================================================= */}
      {stage === 'visual_flow' && (
        <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white dark:bg-[#0F172A] rounded-3xl border-2 border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-sm transition-colors"
        >
          <div className="flex flex-wrap items-center justify-between gap-3 mb-6">
            <div>
              <span className="text-[11px] font-black uppercase tracking-wider text-cyan-600 dark:text-cyan-400 bg-cyan-50 dark:bg-cyan-950/60 px-2.5 py-1 rounded-md border border-cyan-200 dark:border-cyan-800">
                Fase 2 de 7 · Prueba Visual Espacial & Flujo de Datos
              </span>
              <h3 className="text-xl sm:text-2xl font-black text-[#00283d] dark:text-white mt-1">
                Rastreo Visual de Bifurcación en Mapa de Código
              </h3>
            </div>
            <div className="text-xs font-mono text-slate-500 bg-slate-100 dark:bg-slate-800 px-3 py-1.5 rounded-xl">
              Tiempo: {visualFlowMetric.timeSeconds}s
            </div>
          </div>

          <p className="text-sm text-slate-600 dark:text-slate-300 font-medium mb-6">
            Sigue con la mirada el recorrido del paquete de datos <strong>#42</strong> a través del siguiente mapa de bifurcación condicional. ¿A qué terminal final llegará la carga?
          </p>

          {/* Visual Flow ASCII / Diagram Card */}
          <div className="bg-slate-900 rounded-3xl p-6 border-2 border-slate-800 font-mono text-xs text-slate-300 mb-6 relative overflow-hidden shadow-inner">
            <div className="flex flex-col md:flex-row items-center justify-between gap-4 text-center md:text-left">
              <div className="p-3 bg-cyan-950/80 border border-cyan-400 text-cyan-300 rounded-xl">
                [Entrada: Paquete #42]
              </div>
              <span className="text-cyan-400 font-black">──►</span>
              <div className="p-3 bg-slate-800 border border-slate-600 rounded-xl">
                {'¿Es Par? (42 % 2 === 0)'}
                <div className="text-[10px] text-emerald-400 mt-1">Verdadero ──► Rama Cian</div>
              </div>
              <span className="text-emerald-400 font-black">──►</span>
              <div className="p-3 bg-emerald-950/80 border border-emerald-400 text-emerald-300 rounded-xl">
                {'¿Valor > 20? (42 > 20)'}
                <div className="text-[10px] text-[#2EE59D] mt-1">Verdadero ──► Terminal Alpha</div>
              </div>
            </div>
          </div>

          {/* Terminal Selection Buttons */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-6">
            <button
              onClick={() => handleSelectFlowTerminal('alpha')}
              disabled={visualFlowMetric.solved}
              className={`p-4 rounded-2xl border-2 transition-all flex items-center justify-between cursor-pointer ${
                visualFlowMetric.selectedTerminal === 'alpha'
                  ? 'border-emerald-400 bg-emerald-50 dark:bg-emerald-950/50 text-emerald-800 dark:text-emerald-200 shadow-md'
                  : 'border-slate-200 dark:border-slate-800 bg-[#F8FAFC] dark:bg-[#131F2E]'
              }`}
            >
              <div>
                <span className="text-xs font-black uppercase text-emerald-600 dark:text-[#2EE59D] block">Terminal Alpha</span>
                <span className="text-[11px] text-slate-500">Menta: Rama Principal (V + V)</span>
              </div>
              {visualFlowMetric.solved && <Check className="w-5 h-5 text-emerald-500" />}
            </button>

            <button
              onClick={() => handleSelectFlowTerminal('beta')}
              disabled={visualFlowMetric.solved}
              className="p-4 rounded-2xl border-2 border-slate-200 dark:border-slate-800 bg-[#F8FAFC] dark:bg-[#131F2E] text-left hover:border-slate-400 cursor-pointer"
            >
              <span className="text-xs font-black uppercase text-cyan-600 block">Terminal Beta</span>
              <span className="text-[11px] text-slate-500">Azul: Rama Secundaria (V + F)</span>
            </button>

            <button
              onClick={() => handleSelectFlowTerminal('gamma')}
              disabled={visualFlowMetric.solved}
              className="p-4 rounded-2xl border-2 border-slate-200 dark:border-slate-800 bg-[#F8FAFC] dark:bg-[#131F2E] text-left hover:border-slate-400 cursor-pointer"
            >
              <span className="text-xs font-black uppercase text-amber-600 block">Terminal Gamma</span>
              <span className="text-[11px] text-slate-500">Ámbar: Rama Descarte (Impar)</span>
            </button>
          </div>

          <div className="flex justify-between items-center pt-4 border-t border-slate-200 dark:border-slate-800">
            <button
              onClick={() => setStage('visual')}
              className="px-4 py-2 text-xs font-bold text-slate-500 hover:text-slate-800 dark:hover:text-white"
            >
              ← Volver
            </button>
            <button
              onClick={() => {
                playTone(440, 100, 'sine', 0.1);
                setStage('auditory');
              }}
              disabled={!visualFlowMetric.solved}
              className="px-6 py-3 rounded-2xl bg-[#2EE59D] hover:bg-[#20ce8a] active:translate-y-0.5 text-[#00283d] font-black text-xs uppercase tracking-wider shadow-md transition flex items-center gap-2 disabled:opacity-40 disabled:pointer-events-none cursor-pointer border-b-2 border-emerald-600"
            >
              <span>Siguiente: Sintetizador Auditivo</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </motion.div>
      )}

      {/* ========================================================================= */}
      {/* 3. DESAFÍO AUDITIVO 1: NODO BEATS (SIMÓN DE 4 NOTAS) */}
      {/* ========================================================================= */}
      {stage === 'auditory' && (
        <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white dark:bg-[#0F172A] rounded-3xl border-2 border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-sm transition-colors"
        >
          <div className="flex flex-wrap items-center justify-between gap-3 mb-6">
            <div>
              <span className="text-[11px] font-black uppercase tracking-wider text-purple-600 dark:text-purple-400 bg-purple-50 dark:bg-purple-950/60 px-2.5 py-1 rounded-md border border-purple-200 dark:border-purple-800">
                Fase 3 de 7 · Prueba Auditiva Tonal
              </span>
              <h3 className="text-xl sm:text-2xl font-black text-[#00283d] dark:text-white mt-1">
                Nodo Beats: Retención de Secuencia Melódica
              </h3>
            </div>
            <button
              onClick={playDemoMelody}
              disabled={isPlayingMelody}
              className="px-4 py-2 bg-purple-600 hover:bg-purple-700 active:translate-y-0.5 text-white font-black text-xs uppercase rounded-xl shadow-xs transition flex items-center gap-2 cursor-pointer border-b-2 border-purple-800"
            >
              <Play className="w-3.5 h-3.5" />
              <span>Reproducir Secuencia Sonora</span>
            </button>
          </div>

          <p className="text-sm text-slate-600 dark:text-slate-300 font-medium mb-4">
            {auditoryFeedback}
          </p>

          {/* 4 Musical Synth Pads */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
            {synthPads.map(pad => {
              const isLit = activePadLight === pad.id;
              return (
                <button
                  key={pad.id}
                  onClick={() => handlePadPress(pad.id)}
                  disabled={isPlayingMelody || auditoryMetric.solved}
                  className={`h-32 rounded-3xl border-b-4 flex flex-col items-center justify-center gap-2 transition-all cursor-pointer ${pad.color} ${pad.border} ${
                    isLit ? 'scale-105 brightness-125 shadow-xl ring-4 ring-white' : 'opacity-90'
                  }`}
                >
                  <Music className="w-6 h-6 text-white" />
                  <span className="text-white font-black text-sm uppercase tracking-wider">{pad.label}</span>
                  <span className="text-white/80 font-mono text-[10px]">{pad.note}</span>
                </button>
              );
            })}
          </div>

          <div className="flex justify-between items-center pt-4 border-t border-slate-200 dark:border-slate-800">
            <button
              onClick={() => setStage('visual_flow')}
              className="px-4 py-2 text-xs font-bold text-slate-500 hover:text-slate-800 dark:hover:text-white"
            >
              ← Volver
            </button>
            <button
              onClick={() => {
                playTone(440, 100, 'sine', 0.1);
                setStage('auditory_rhythm');
              }}
              disabled={!auditoryMetric.solved}
              className="px-6 py-3 rounded-2xl bg-[#2EE59D] hover:bg-[#20ce8a] active:translate-y-0.5 text-[#00283d] font-black text-xs uppercase tracking-wider shadow-md transition flex items-center gap-2 disabled:opacity-40 disabled:pointer-events-none cursor-pointer border-b-2 border-emerald-600"
            >
              <span>Siguiente: Cadencia Rítmica</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </motion.div>
      )}

      {/* ========================================================================= */}
      {/* 4. DESAFÍO AUDITIVO 2: CADENCIA Y RITMO SECUENCIAL */}
      {/* ========================================================================= */}
      {stage === 'auditory_rhythm' && (
        <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white dark:bg-[#0F172A] rounded-3xl border-2 border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-sm transition-colors"
        >
          <div className="flex flex-wrap items-center justify-between gap-3 mb-6">
            <div>
              <span className="text-[11px] font-black uppercase tracking-wider text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/60 px-2.5 py-1 rounded-md border border-indigo-200 dark:border-indigo-800">
                Fase 4 de 7 · Prueba Auditiva de Cadencia y Ritmo
              </span>
              <h3 className="text-xl sm:text-2xl font-black text-[#00283d] dark:text-white mt-1">
                Cadencia y Ritmo de Pulsos de Código
              </h3>
            </div>
            <button
              onClick={playDemoRhythm}
              disabled={isPlayingRhythm}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 active:translate-y-0.5 text-white font-black text-xs uppercase rounded-xl shadow-xs transition flex items-center gap-2 cursor-pointer border-b-2 border-indigo-800"
            >
              <Activity className="w-3.5 h-3.5" />
              <span>Escuchar Cadencia de Nodo</span>
            </button>
          </div>

          <p className="text-sm text-slate-600 dark:text-slate-300 font-medium mb-6">
            Los programadores con alta retención auditiva memorizan la cadencia de ejecución del código. Escucha el compás de 3 pulsos y luego toca el pad rítmico para replicar el tempo.
          </p>

          {/* Interactive Rhythm Drum Pad */}
          <div className="flex flex-col items-center justify-center p-8 bg-slate-900 rounded-3xl border-2 border-slate-800 mb-6 text-center">
            <button
              onClick={handleUserTapRhythm}
              disabled={isPlayingRhythm || rhythmMetric.solved}
              className={`w-36 h-36 rounded-full border-4 flex flex-col items-center justify-center transition-all cursor-pointer ${
                rhythmLight 
                  ? 'border-indigo-400 bg-indigo-500 scale-110 shadow-2xl shadow-indigo-500/50' 
                  : 'border-slate-700 bg-slate-800 hover:border-indigo-500'
              }`}
            >
              <Activity className="w-10 h-10 text-white mb-1" />
              <span className="text-xs font-black uppercase tracking-wider text-white">Tocar Pulso</span>
              <span className="text-[10px] text-indigo-300 font-mono font-bold mt-1">({userTapsCount} / 3)</span>
            </button>
            <span className="text-xs text-slate-400 mt-4 font-mono">
              {rhythmMetric.solved ? '✓ ¡Cadencia rítmica verificada con éxito!' : 'Toca el pad 3 veces siguiendo el tempo'}
            </span>
          </div>

          <div className="flex justify-between items-center pt-4 border-t border-slate-200 dark:border-slate-800">
            <button
              onClick={() => setStage('auditory')}
              className="px-4 py-2 text-xs font-bold text-slate-500 hover:text-slate-800 dark:hover:text-white"
            >
              ← Volver
            </button>
            <button
              onClick={() => {
                playTone(440, 100, 'sine', 0.1);
                setStage('logic');
              }}
              disabled={!rhythmMetric.solved}
              className="px-6 py-3 rounded-2xl bg-[#2EE59D] hover:bg-[#20ce8a] active:translate-y-0.5 text-[#00283d] font-black text-xs uppercase tracking-wider shadow-md transition flex items-center gap-2 disabled:opacity-40 disabled:pointer-events-none cursor-pointer border-b-2 border-emerald-600"
            >
              <span>Siguiente: Compuertas Lógicas</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </motion.div>
      )}

      {/* ========================================================================= */}
      {/* 5. DESAFÍO LÓGICO: COMPUERTAS DE SEGURIDAD */}
      {/* ========================================================================= */}
      {stage === 'logic' && (
        <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white dark:bg-[#0F172A] rounded-3xl border-2 border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-sm transition-colors"
        >
          <div className="flex flex-wrap items-center justify-between gap-3 mb-6">
            <div>
              <span className="text-[11px] font-black uppercase tracking-wider text-sky-600 dark:text-sky-400 bg-sky-50 dark:bg-sky-950/60 px-2.5 py-1 rounded-md border border-sky-200 dark:border-sky-800">
                Fase 5 de 7 · Prueba Lógica Deductiva
              </span>
              <h3 className="text-xl sm:text-2xl font-black text-[#00283d] dark:text-white mt-1">
                Panel de Compuertas Booleanas Causa-Efecto
              </h3>
            </div>
            <div className="text-xs font-mono text-slate-500 bg-slate-100 dark:bg-slate-800 px-3 py-1.5 rounded-xl">
              Movimientos: {logicMetric.movesCount}
            </div>
          </div>

          <p className="text-sm text-slate-600 dark:text-slate-300 font-medium mb-6">
            Para despresurizar el reactor, la compuerta se abre si y solo si: <strong>(Interruptor A está ACTIVO Y Interruptor B está ACTIVO) Y la Purga C está APAGADA</strong>. Modifica los estados para abrir el sello.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
            {/* Switch A */}
            <div className="p-5 rounded-2xl bg-[#F8FAFC] dark:bg-[#131F2E] border-2 border-slate-200 dark:border-slate-800 flex flex-col justify-between">
              <div>
                <span className="text-xs font-black uppercase text-slate-400">Interruptor A</span>
                <h5 className="font-black text-sm text-[#00324D] dark:text-white mt-1">Válvula Primaria</h5>
              </div>
              <button
                onClick={() => toggleLogicSwitch('A')}
                className={`mt-4 py-3 rounded-xl font-black text-xs uppercase tracking-wider transition cursor-pointer ${
                  logicMetric.switchA ? 'bg-[#39a900] text-white shadow-xs' : 'bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
                }`}
              >
                {logicMetric.switchA ? 'ON (Activo)' : 'OFF (Inactivo)'}
              </button>
            </div>

            {/* Switch B */}
            <div className="p-5 rounded-2xl bg-[#F8FAFC] dark:bg-[#131F2E] border-2 border-slate-200 dark:border-slate-800 flex flex-col justify-between">
              <div>
                <span className="text-xs font-black uppercase text-slate-400">Interruptor B</span>
                <h5 className="font-black text-sm text-[#00324D] dark:text-white mt-1">Válvula Secundaria</h5>
              </div>
              <button
                onClick={() => toggleLogicSwitch('B')}
                className={`mt-4 py-3 rounded-xl font-black text-xs uppercase tracking-wider transition cursor-pointer ${
                  logicMetric.switchB ? 'bg-[#39a900] text-white shadow-xs' : 'bg-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400'
                }`}
              >
                {logicMetric.switchB ? 'ON (Activo)' : 'OFF (Inactivo)'}
              </button>
            </div>

            {/* Switch C */}
            <div className="p-5 rounded-2xl bg-[#F8FAFC] dark:bg-[#131F2E] border-2 border-slate-200 dark:border-slate-800 flex flex-col justify-between">
              <div>
                <span className="text-xs font-black uppercase text-rose-500">Purga de Freno C</span>
                <h5 className="font-black text-sm text-[#00324D] dark:text-white mt-1">Bloqueo de Seguridad</h5>
              </div>
              <button
                onClick={() => toggleLogicSwitch('C')}
                className={`mt-4 py-3 rounded-xl font-black text-xs uppercase tracking-wider transition cursor-pointer ${
                  logicMetric.switchC ? 'bg-rose-500 text-white shadow-xs' : 'bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
                }`}
              >
                {logicMetric.switchC ? 'ON (Freno Puesto)' : 'OFF (Desactivado)'}
              </button>
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 text-center font-mono text-xs text-white mb-6">
            Estado de Compuerta: {logicMetric.solved ? '🟢 ABIERTA (Flujo Estable)' : '🔴 SELLADA (Condición Incumplida)'}
          </div>

          <div className="flex justify-between items-center pt-4 border-t border-slate-200 dark:border-slate-800">
            <button
              onClick={() => setStage('auditory_rhythm')}
              className="px-4 py-2 text-xs font-bold text-slate-500 hover:text-slate-800 dark:hover:text-white"
            >
              ← Volver
            </button>
            <button
              onClick={() => {
                playTone(440, 100, 'sine', 0.1);
                setStage('bimodal');
              }}
              disabled={!logicMetric.solved}
              className="px-6 py-3 rounded-2xl bg-[#2EE59D] hover:bg-[#20ce8a] active:translate-y-0.5 text-[#00283d] font-black text-xs uppercase tracking-wider shadow-md transition flex items-center gap-2 disabled:opacity-40 disabled:pointer-events-none cursor-pointer border-b-2 border-emerald-600"
            >
              <span>Siguiente: Desafío Bimodal</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </motion.div>
      )}

      {/* ========================================================================= */}
      {/* 6. DESAFÍO BIMODAL: SINCRONIZACIÓN AUDIOVISUAL (LUZ + SONIDO) */}
      {/* ========================================================================= */}
      {stage === 'bimodal' && (
        <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white dark:bg-[#0F172A] rounded-3xl border-2 border-cyan-400/40 dark:border-cyan-500/40 p-6 sm:p-8 shadow-sm transition-colors"
        >
          <div className="flex flex-wrap items-center justify-between gap-3 mb-6">
            <div>
              <span className="text-[11px] font-black uppercase tracking-wider text-cyan-600 dark:text-cyan-400 bg-cyan-50 dark:bg-cyan-950/60 px-2.5 py-1 rounded-md border border-cyan-300 dark:border-cyan-800">
                Fase 6 de 7 · Prueba Bimodal Audiovisual
              </span>
              <h3 className="text-xl sm:text-2xl font-black text-[#00283d] dark:text-white mt-1">
                Sincronización Dual: Luz de Espectro y Frecuencia Sonora
              </h3>
            </div>
            <button
              onClick={playDemoBimodal}
              disabled={isPlayingBimodal}
              className="px-4 py-2 bg-gradient-to-r from-cyan-600 to-emerald-600 hover:from-cyan-500 hover:to-emerald-500 active:translate-y-0.5 text-white font-black text-xs uppercase rounded-xl shadow-xs transition flex items-center gap-2 cursor-pointer border-b-2 border-cyan-800"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Emitir Secuencia Audiovisual</span>
            </button>
          </div>

          <p className="text-sm text-slate-600 dark:text-slate-300 font-medium mb-6">
            Esta prueba mide si tu cerebro integra en paralelo estímulos luminosos de color y notas acústicas. Observa y escucha la secuencia emitida por Nodo y activa los reactores en el orden coordinado:
          </p>

          {/* 3 Bimodal Dual Reactores */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
            {bimodalNodes.map(node => {
              const isLit = activeBimodalLight === node.id;
              return (
                <button
                  key={node.id}
                  onClick={() => handleBimodalNodeClick(node.id)}
                  disabled={isPlayingBimodal || bimodalMetric.solved}
                  className={`p-6 rounded-3xl border-2 transition-all flex flex-col items-center justify-center gap-3 cursor-pointer ${
                    isLit 
                      ? 'scale-105 brightness-125 shadow-xl ring-4 ring-cyan-400 bg-cyan-950 text-white' 
                      : 'bg-[#F8FAFC] dark:bg-[#131F2E] border-slate-200 dark:border-slate-800 hover:border-cyan-400'
                  }`}
                >
                  <span className="text-4xl">{node.icon}</span>
                  <div className="text-center">
                    <h5 className="font-black text-sm text-[#00324D] dark:text-white">{node.name}</h5>
                    <span className="text-[10px] text-slate-400 font-mono font-bold">{node.label}</span>
                  </div>
                </button>
              );
            })}
          </div>

          <div className="flex justify-between items-center pt-4 border-t border-slate-200 dark:border-slate-800">
            <button
              onClick={() => setStage('logic')}
              className="px-4 py-2 text-xs font-bold text-slate-500 hover:text-slate-800 dark:hover:text-white"
            >
              ← Volver
            </button>
            <button
              onClick={() => {
                playTone(440, 100, 'sine', 0.1);
                setStage('social');
              }}
              disabled={!bimodalMetric.solved}
              className="px-6 py-3 rounded-2xl bg-[#2EE59D] hover:bg-[#20ce8a] active:translate-y-0.5 text-[#00283d] font-black text-xs uppercase tracking-wider shadow-md transition flex items-center gap-2 disabled:opacity-40 disabled:pointer-events-none cursor-pointer border-b-2 border-emerald-600"
            >
              <span>Siguiente: Dilema Colaborativo</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </motion.div>
      )}

      {/* ========================================================================= */}
      {/* 7. DESAFÍO SOCIAL: DILEMA DE LA NAVE ESPACIAL */}
      {/* ========================================================================= */}
      {stage === 'social' && (
        <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white dark:bg-[#0F172A] rounded-3xl border-2 border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-sm transition-colors"
        >
          <div className="flex flex-wrap items-center justify-between gap-3 mb-6">
            <div>
              <span className="text-[11px] font-black uppercase tracking-wider text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/60 px-2.5 py-1 rounded-md border border-rose-200 dark:border-rose-800">
                Fase 7 de 7 · Prueba Colaborativa / Social
              </span>
              <h3 className="text-xl sm:text-2xl font-black text-[#00283d] dark:text-white mt-1">
                La Nave Nodo: Tu Estrategia de Trabajo en Equipo
              </h3>
            </div>
          </div>

          <p className="text-sm text-slate-600 dark:text-slate-300 font-medium mb-6">
            Estamos ensamblando los subsistemas de vuelo de la estación Nodo. ¿Cuál de estos entornos de trabajo maximiza tu aprendizaje y confort?
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            {socialOptions.map(opt => {
              const isSelected = socialMetric.choice === opt.id;
              return (
                <div
                  key={opt.id}
                  onClick={() => handleSelectSocialOption(opt.id)}
                  className={`p-5 rounded-3xl border-2 transition-all flex flex-col justify-between cursor-pointer ${
                    isSelected 
                      ? 'border-[#2EE59D] bg-emerald-50 dark:bg-emerald-950/40 shadow-sm' 
                      : 'border-slate-200 dark:border-slate-800 bg-[#F8FAFC] dark:bg-[#131F2E] hover:border-slate-400'
                  }`}
                >
                  <div>
                    <span className="text-3xl mb-2 block">{opt.icon}</span>
                    <span className="text-[10px] font-black uppercase tracking-wider text-slate-400 block">{opt.badge}</span>
                    <h4 className="font-black text-sm text-[#00324D] dark:text-white mt-1 mb-2">{opt.title}</h4>
                    <p className="text-xs text-slate-600 dark:text-slate-300 font-medium leading-relaxed">{opt.description}</p>
                  </div>
                  <div className="mt-4 pt-3 border-t border-slate-200 dark:border-slate-800 flex justify-end">
                    <span className={`text-xs font-black ${isSelected ? 'text-[#007832] dark:text-[#2EE59D]' : 'text-slate-400'}`}>
                      {isSelected ? '✓ Seleccionado' : 'Elegir'}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="flex justify-between items-center pt-4 border-t border-slate-200 dark:border-slate-800">
            <button
              onClick={() => setStage('bimodal')}
              className="px-4 py-2 text-xs font-bold text-slate-500 hover:text-slate-800 dark:hover:text-white"
            >
              ← Volver
            </button>
            <button
              onClick={handleCalculateFinalResult}
              disabled={socialMetric.choice === null}
              className="px-8 py-3.5 rounded-2xl bg-[#2EE59D] hover:bg-[#20ce8a] active:translate-y-0.5 text-[#00283d] font-black text-sm uppercase tracking-wider shadow-md transition flex items-center gap-2 disabled:opacity-40 disabled:pointer-events-none cursor-pointer border-b-2 border-emerald-600"
            >
              <Sparkles className="w-4 h-4" />
              <span>Emitir Diagnóstico Bimodal & Recomendaciones</span>
            </button>
          </div>
        </motion.div>
      )}

      {/* ========================================================================= */}
      {/* 8. PANTALLA FINAL DE RESULTADOS CON DETECCIÓN BIMODAL */}
      {/* ========================================================================= */}
      {stage === 'result' && result && (
        <motion.div 
          initial={{ opacity: 0, scale: 0.98 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-white dark:bg-[#0F172A] rounded-3xl border-2 border-slate-200 dark:border-slate-800 p-6 sm:p-10 shadow-sm transition-colors"
        >
          {/* Header Summary */}
          <div className="text-center max-w-2xl mx-auto mb-10">
            <span className="inline-flex items-center gap-2 bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-300 dark:border-emerald-800 text-[#007832] dark:text-[#2EE59D] px-4 py-1.5 rounded-full text-xs font-black uppercase tracking-wider mb-3">
              <Trophy className="w-4 h-4 text-amber-500" />
              Diagnóstico Multidimensional Completado
            </span>

            {result.isBimodal ? (
              <div>
                <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-gradient-to-r from-cyan-500/20 via-purple-500/20 to-emerald-500/20 border-2 border-cyan-400 text-cyan-800 dark:text-cyan-200 font-black text-xs uppercase tracking-wider mb-3">
                  <Sparkles className="w-4 h-4 text-cyan-500 animate-spin" />
                  {result.bimodalTitle || 'Perfil Bimodal: Audiovisual'}
                </div>
                <h2 className="text-2xl sm:text-3xl font-black text-[#00283d] dark:text-white tracking-tight mb-2">
                  ¡Confirmado: Eres un Aprendiz Bimodal (Visual + Auditivo)!
                </h2>
                <p className="text-slate-600 dark:text-slate-300 text-sm sm:text-base font-medium">
                  {result.bimodalDescription || 'Tu cerebro consolida el código integrando esquemas espaciales y explicaciones habladas.'}
                </p>
              </div>
            ) : (
              <div>
                <h2 className="text-2xl sm:text-3xl font-black text-[#00283d] dark:text-white tracking-tight mb-2">
                  Tu Estilo Predominante es: {result.primaryStyle.name}
                </h2>
                <p className="text-slate-600 dark:text-slate-300 text-sm sm:text-base font-medium">
                  Basado en tu batería de pruebas de haz de luz, flujo espacial, tonos, cadencia rítmica, compuertas y dilema colaborativo.
                </p>
              </div>
            )}
          </div>

          {/* Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            {/* Primary / Visual */}
            <div className="bg-[#F8FAFC] dark:bg-[#131F2E] border-2 border-cyan-400 dark:border-cyan-500 rounded-3xl p-6 relative overflow-hidden shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <span className="text-4xl">{result.primaryStyle.icon}</span>
                <span className="bg-cyan-500/20 text-cyan-800 dark:text-cyan-200 border border-cyan-400 font-black text-xs px-3 py-1 rounded-full uppercase tracking-wider">
                  {result.primaryStyle.name} ({result.primaryStyle.percentage}%)
                </span>
              </div>
              <h4 className="font-black text-xl text-[#00283d] dark:text-white mb-1">
                {result.primaryStyle.name}
              </h4>
              <p className="text-xs font-bold text-cyan-700 dark:text-cyan-300 mb-3">
                {result.primaryStyle.tagline}
              </p>
              <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 font-medium leading-relaxed mb-4">
                {result.primaryStyle.description}
              </p>
            </div>

            {/* Secondary / Auditory */}
            <div className="bg-[#F8FAFC] dark:bg-[#131F2E] border-2 border-purple-400 dark:border-purple-500 rounded-3xl p-6 relative overflow-hidden shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <span className="text-4xl">{result.secondaryStyle.icon}</span>
                <span className="bg-purple-500/20 text-purple-800 dark:text-purple-200 border border-purple-400 font-black text-xs px-3 py-1 rounded-full uppercase tracking-wider">
                  {result.secondaryStyle.name} ({result.secondaryStyle.percentage}%)
                </span>
              </div>
              <h4 className="font-black text-xl text-[#00283d] dark:text-white mb-1">
                {result.secondaryStyle.name}
              </h4>
              <p className="text-xs font-bold text-purple-700 dark:text-purple-300 mb-3">
                {result.secondaryStyle.tagline}
              </p>
              <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 font-medium leading-relaxed mb-4">
                {result.secondaryStyle.description}
              </p>
            </div>
          </div>

          {/* Breakdown Bars */}
          <div className="bg-[#F8FAFC] dark:bg-[#131F2E] rounded-3xl p-6 border border-slate-200 dark:border-slate-800 mb-8">
            <h4 className="text-sm font-black text-[#00283d] dark:text-white uppercase tracking-wider mb-4 flex items-center gap-2">
              <Brain className="w-4 h-4 text-emerald-600 dark:text-[#2EE59D]" />
              Desglose Completo de las 7 Pruebas
            </h4>
            <div className="space-y-4">
              {result.breakdown.map((style) => (
                <div key={style.type}>
                  <div className="flex items-center justify-between text-xs font-bold mb-1">
                    <span className="flex items-center gap-2 text-[#00283d] dark:text-slate-200">
                      <span>{style.icon}</span>
                      <span>{style.name}</span>
                    </span>
                    <span className="font-mono text-slate-500 dark:text-slate-400">{style.percentage}%</span>
                  </div>
                  <div className="w-full bg-slate-200 dark:bg-slate-800 h-2.5 rounded-full overflow-hidden">
                    <div 
                      className="h-full rounded-full transition-all duration-500"
                      style={{ 
                        width: `${style.percentage}%`,
                        backgroundColor: style.color || '#2EE59D'
                      }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-4 border-t border-slate-200 dark:border-slate-800">
            <button
              onClick={resetAllChallenges}
              className="w-full sm:w-auto px-6 py-3 rounded-2xl border-2 border-slate-300 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200 font-bold text-xs uppercase tracking-wider transition flex items-center justify-center gap-2 cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Repetir Laboratorio</span>
            </button>

            {onSkipOrContinue && (
              <button
                onClick={onSkipOrContinue}
                className="w-full sm:w-auto px-8 py-3.5 rounded-2xl bg-[#2EE59D] hover:bg-[#20ce8a] active:translate-y-0.5 text-[#00283d] font-black text-sm uppercase tracking-wider shadow-md transition flex items-center justify-center gap-2 cursor-pointer border-b-2 border-emerald-600"
              >
                <span>Continuar a los Retos Adaptados</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            )}
          </div>
        </motion.div>
      )}
    </div>
  );
}
