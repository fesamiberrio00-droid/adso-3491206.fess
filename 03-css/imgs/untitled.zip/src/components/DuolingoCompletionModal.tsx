import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Sparkles, 
  Flame, 
  Trophy, 
  CheckCircle2, 
  Volume2, 
  VolumeX, 
  ArrowRight, 
  RotateCcw,
  Cpu,
  Award
} from 'lucide-react';
import NodoTutorAvatar from './NodoTutorAvatar';
import { audioFx } from '../utils/audioEffects';
import { LearningStyleType } from '../types';

interface DuolingoCompletionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onReview?: () => void;
  score: number;
  totalQuestions: number;
  xpEarned: number;
  bitsEarned?: number;
  gemsEarned?: number; // backwards compatibility
  streakDays: number;
  learningStyle?: LearningStyleType;
  secondaryStyle?: LearningStyleType;
  isBimodal?: boolean;
  bimodalTitle?: string;
  styleName?: string;
  moduleTitle?: string;
}

export default function DuolingoCompletionModal({
  isOpen,
  onClose,
  onReview,
  score,
  totalQuestions,
  xpEarned,
  bitsEarned,
  gemsEarned = 0,
  streakDays,
  learningStyle = 'visual',
  secondaryStyle,
  isBimodal = false,
  bimodalTitle,
  styleName = 'Visual / Espacial',
  moduleTitle = 'Lógica de Programación'
}: DuolingoCompletionModalProps) {
  const totalBits = bitsEarned !== undefined ? bitsEarned : gemsEarned;
  const [isSpeaking, setIsSpeaking] = useState(false);
  const isPerfect = score === totalQuestions && totalQuestions > 0;
  
  // When bimodal or multimodal, activate both primary and secondary modalities
  const isVisual = learningStyle === 'visual' || secondaryStyle === 'visual' || (isBimodal && (learningStyle === 'auditivo' || secondaryStyle === 'auditivo'));
  const isAuditivo = learningStyle === 'auditivo' || secondaryStyle === 'auditivo' || (isBimodal && (learningStyle === 'visual' || secondaryStyle === 'visual'));
  const isLogico = learningStyle === 'logico' || secondaryStyle === 'logico';
  const isKinestesico = learningStyle === 'practico' || secondaryStyle === 'practico';

  // Floating confetti particles for Visual style (Cyan & Mint Green)
  const [particles] = useState(() => {
    return Array.from({ length: 42 }, (_, i) => ({
      id: i,
      x: Math.random() * 100,
      y: Math.random() * 100,
      size: Math.random() * 10 + 6,
      color: i % 2 === 0 
        ? (i % 4 === 0 ? '#00e5ff' : '#22d3ee') // Cyan tones
        : (i % 3 === 0 ? '#2EE59D' : '#39a900'), // Mint green tones
      delay: Math.random() * 0.8,
      duration: Math.random() * 2 + 1.8,
      rotate: Math.random() * 360
    }));
  });

  useEffect(() => {
    if (!isOpen) {
      audioFx.stopSpeaking();
      setIsSpeaking(false);
      return;
    }

    // Play victory sound
    audioFx.play('victory');

    // If Auditory learner, auto-play Nodo's celebratory speech
    if (isAuditivo) {
      const speech = `¡Sensacional desempeño! Has completado el módulo de ${moduleTitle} con gran precisión. Tu memoria auditiva y concentración rítmica superaron cada reto. ¡He sumado ${xpEarned} puntos de experiencia a tu racha!`;
      const timer = setTimeout(() => {
        setIsSpeaking(true);
        audioFx.speak(
          speech,
          () => setIsSpeaking(false),
          () => setIsSpeaking(true)
        );
      }, 350);

      return () => {
        clearTimeout(timer);
        audioFx.stopSpeaking();
      };
    }
  }, [isOpen, isAuditivo, moduleTitle, xpEarned]);

  const toggleSpeech = () => {
    if (isSpeaking) {
      audioFx.stopSpeaking();
      setIsSpeaking(false);
    } else {
      setIsSpeaking(true);
      const speech = `¡Felicitaciones por terminar este reto! Obtuviste ${score} de ${totalQuestions} aciertos y ganaste ${xpEarned} puntos de experiencia. ¡Sigue aprendiendo con Nodo!`;
      audioFx.speak(
        speech,
        () => setIsSpeaking(false),
        () => setIsSpeaking(true)
      );
    }
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md overflow-y-auto">
        
        {/* Background Visual Confetti Particles (Cian y Verde Menta para Visual) */}
        {isVisual && (
          <div className="absolute inset-0 pointer-events-none overflow-hidden">
            {particles.map(p => (
              <motion.div
                key={p.id}
                initial={{ opacity: 0, y: -20, x: `${p.x}vw`, rotate: 0 }}
                animate={{ 
                  opacity: [0, 1, 1, 0], 
                  y: ['0vh', '100vh'],
                  x: [`${p.x}vw`, `${p.x + (Math.random() * 8 - 4)}vw`],
                  rotate: [0, p.rotate + 360] 
                }}
                transition={{ 
                  duration: p.duration, 
                  repeat: Infinity, 
                  delay: p.delay,
                  ease: "easeInOut" 
                }}
                className="absolute rounded-sm shadow-sm"
                style={{
                  width: `${p.size}px`,
                  height: `${p.size * 1.4}px`,
                  backgroundColor: p.color,
                  filter: 'drop-shadow(0 0 6px rgba(46, 229, 157, 0.6))'
                }}
              />
            ))}
          </div>
        )}

        {/* Modal Container: Duolingo Style Card */}
        <motion.div
          initial={{ scale: 0.8, opacity: 0, y: 30 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          exit={{ scale: 0.85, opacity: 0, y: 20 }}
          transition={{ type: "spring", stiffness: 350, damping: 24 }}
          className={`relative w-full max-w-lg bg-white dark:bg-[#0B1420] border-4 rounded-3xl p-6 sm:p-8 shadow-2xl text-center overflow-hidden z-10 ${
            isVisual 
              ? 'border-cyan-400 dark:border-cyan-500 shadow-cyan-500/20' 
              : isAuditivo 
                ? 'border-purple-400 dark:border-purple-500 shadow-purple-500/20'
                : 'border-[#39a900] shadow-[#39a900]/20'
          }`}
        >
          {/* Subtle glowing ambient behind card */}
          <div className="absolute -top-24 -left-24 w-52 h-52 bg-emerald-400/20 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute -bottom-24 -right-24 w-52 h-52 bg-cyan-400/20 rounded-full blur-3xl pointer-events-none" />

          {/* Top Bar with Clear Back and Close Controls */}
          <div className="flex items-center justify-between mb-4 relative z-20">
            <button
              onClick={() => {
                audioFx.stopSpeaking();
                setIsSpeaking(false);
                audioFx.play('click');
                onClose();
              }}
              className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-xs font-black text-slate-600 dark:text-slate-300 flex items-center gap-1.5 transition cursor-pointer"
              title="Volver a la ruta del mapa"
            >
              <span>←</span>
              <span>Volver</span>
            </button>

            {/* Top Banner Tag */}
            <div className={`inline-flex items-center gap-2 px-3.5 py-1 rounded-full text-[11px] font-black uppercase tracking-wider border ${
              isVisual
                ? 'bg-cyan-500/10 text-cyan-600 dark:text-cyan-300 border-cyan-400/30'
                : isAuditivo
                  ? 'bg-purple-500/10 text-purple-600 dark:text-purple-300 border-purple-400/30'
                  : 'bg-[#39a900]/10 text-[#007832] dark:text-[#2EE59D] border-[#39a900]/30'
            }`}>
              <Sparkles className="w-3.5 h-3.5 animate-spin" />
              <span>{isBimodal ? 'Bimodal' : styleName}</span>
            </div>

            <button
              onClick={() => {
                audioFx.stopSpeaking();
                setIsSpeaking(false);
                audioFx.play('click');
                onClose();
              }}
              className="w-8 h-8 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-400 hover:text-slate-700 dark:hover:text-white flex items-center justify-center font-bold text-sm transition cursor-pointer"
              title="Cerrar modal"
            >
              ✕
            </button>
          </div>

          {/* Duolingo Style Big Animated Nodo Mascot */}
          <div className="relative mx-auto my-3 flex items-center justify-center">
            {/* Halo pulse effect for Visual Learners */}
            {isVisual && (
              <motion.div
                animate={{ scale: [1, 1.25, 1], opacity: [0.4, 0.8, 0.4] }}
                transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
                className="absolute w-36 h-36 rounded-full bg-gradient-to-r from-cyan-400 to-[#2EE59D] blur-xl"
              />
            )}

            <motion.div
              animate={isVisual ? {
                scale: [1, 1.08, 1],
                y: [0, -6, 0]
              } : {
                y: [0, -4, 0]
              }}
              transition={{ duration: 2.2, repeat: Infinity, ease: "easeInOut" }}
              className={`relative z-10 p-3 rounded-3xl bg-gradient-to-tr from-[#00283d] via-[#023b56] to-[#044a6b] border-2 shadow-xl ${
                isVisual ? 'border-cyan-400 scale-110 shadow-cyan-400/30' : 'border-emerald-400/60'
              }`}
            >
              <NodoTutorAvatar
                size={isVisual ? 'xl' : 'lg'}
                emotion={isPerfect ? 'victory' : 'happy'}
                showHoloTablet={true}
                showFloatingParticles={true}
                isAnimated={true}
              />
            </motion.div>
          </div>

          {/* Heading */}
          <h2 className="text-2xl sm:text-3xl font-black text-[#00324D] dark:text-white mt-4 tracking-tight">
            {isPerfect ? '¡Lección Impecable!' : '¡Desafío Completado!'}
          </h2>

          {isBimodal && (
            <div className="mt-2 inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-gradient-to-r from-cyan-500/15 via-purple-500/15 to-emerald-500/15 border border-cyan-400/40 text-[11px] font-black uppercase tracking-wider text-[#00324d] dark:text-cyan-200">
              <Sparkles className="w-3.5 h-3.5 text-cyan-500 animate-spin" />
              <span>{bimodalTitle || 'Perfil Bimodal: Audiovisual (Visual + Auditivo)'}</span>
            </div>
          )}

          <p className="text-sm font-medium text-slate-600 dark:text-slate-300 mt-1 max-w-sm mx-auto">
            {isBimodal ? (
              <span className="text-cyan-700 dark:text-cyan-300 font-bold block">
                ✨🎧 ¡Excelente sincronía audiovisual! Resolviste esquemas espaciales y retuviste las explicaciones sonoras.
              </span>
            ) : (
              <>
                {isVisual && (
                  <span className="text-cyan-700 dark:text-cyan-300 font-bold block">
                    ✨ ¡Tu procesamiento visual y espacial resolvió los patrones con agilidad!
                  </span>
                )}
                {isAuditivo && (
                  <span className="text-purple-700 dark:text-purple-300 font-bold block">
                    🎧 ¡Excelente retención auditiva y discriminación de tono en este reto!
                  </span>
                )}
                {isLogico && (
                  <span className="text-sky-700 dark:text-sky-300 font-bold block">
                    🧩 ¡Deducción algorítmica y análisis de causa-efecto demostrados!
                  </span>
                )}
                {isKinestesico && (
                  <span className="text-emerald-700 dark:text-emerald-300 font-bold block">
                    ⚡ ¡Construcción interactiva y manipulación directa completada!
                  </span>
                )}
              </>
            )}
            Módulo: <strong className="text-[#007832] dark:text-[#2EE59D]">{moduleTitle}</strong>
          </p>

          {/* Auditory Voice Playback Bar for Auditory Style */}
          {isAuditivo && (
            <div className="mt-4 p-3 bg-purple-50 dark:bg-purple-950/40 border border-purple-200 dark:border-purple-800 rounded-2xl flex items-center justify-between gap-3 text-left">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-purple-600 text-white flex items-center justify-center shrink-0 shadow-xs">
                  {isSpeaking ? (
                    <VolumeX className="w-4 h-4 animate-pulse" />
                  ) : (
                    <Volume2 className="w-4 h-4" />
                  )}
                </div>
                <div>
                  <span className="text-[10px] font-black uppercase tracking-wider text-purple-700 dark:text-purple-300 block">
                    {isSpeaking ? 'Nodo Hablando...' : 'Voz de Nodo lista'}
                  </span>
                  <span className="text-xs text-slate-600 dark:text-slate-300 font-medium">
                    {isSpeaking ? 'Escucha la felicitación de voz' : 'Haz clic para escuchar felicitación hablada'}
                  </span>
                </div>
              </div>

              {/* Soundwave equalizer indicator */}
              <div className="flex items-end gap-1 h-5 px-1">
                {[12, 18, 8, 22, 15].map((h, i) => (
                  <motion.div
                    key={i}
                    animate={isSpeaking ? { height: [h * 0.4, h, h * 0.4] } : { height: 6 }}
                    transition={{ duration: 0.6, repeat: Infinity, delay: i * 0.1 }}
                    className="w-1 bg-purple-500 rounded-full"
                  />
                ))}
              </div>

              <button
                onClick={toggleSpeech}
                className="px-2.5 py-1 text-xs font-black rounded-lg bg-purple-600 text-white hover:bg-purple-700 transition cursor-pointer"
              >
                {isSpeaking ? 'Pausar' : 'Escuchar'}
              </button>
            </div>
          )}

          {/* Duolingo Score Breakdown Cards */}
          <div className="grid grid-cols-3 gap-2.5 sm:gap-3 my-5">
            {/* Precision / Score */}
            <div className="p-3 sm:p-3.5 rounded-2xl bg-slate-50 dark:bg-[#131F2E] border-2 border-slate-200 dark:border-slate-800 flex flex-col items-center">
              <CheckCircle2 className="w-5 h-5 text-[#39a900] mb-1" />
              <span className="text-[10px] font-black uppercase text-slate-500 dark:text-slate-400">Aciertos</span>
              <span className="text-lg font-black text-[#00324D] dark:text-white tabular-nums">
                {score} / {totalQuestions}
              </span>
            </div>

            {/* XP Gained */}
            <div className="p-3 sm:p-3.5 rounded-2xl bg-[#fdc300]/15 dark:bg-[#fdc300]/25 border-2 border-[#fdc300]/40 flex flex-col items-center">
              <Trophy className="w-5 h-5 text-amber-500 mb-1" />
              <span className="text-[10px] font-black uppercase text-amber-700 dark:text-amber-300">XP Ganado</span>
              <span className="text-lg font-black text-[#00324D] dark:text-white tabular-nums">
                +{xpEarned}
              </span>
            </div>

            {/* Streak / Fire */}
            <div className="p-3 sm:p-3.5 rounded-2xl bg-orange-50 dark:bg-orange-950/40 border-2 border-orange-200 dark:border-orange-800 flex flex-col items-center">
              <Flame className="w-5 h-5 text-orange-500 mb-1 animate-pulse" />
              <span className="text-[10px] font-black uppercase text-orange-700 dark:text-orange-300">Racha</span>
              <span className="text-lg font-black text-[#00324D] dark:text-white tabular-nums">
                {streakDays} días
              </span>
            </div>
          </div>

          {/* Bits Reward Note */}
          <div className="flex items-center justify-center gap-2 mb-6 text-xs font-bold text-emerald-600 dark:text-[#2EE59D] bg-emerald-50 dark:bg-emerald-950/40 py-2 px-3 rounded-xl border border-emerald-200 dark:border-emerald-800">
            <Cpu className="w-4 h-4 text-cyan-500" />
            <span>+{totalBits} Bits de computación agregados a tu terminal digital</span>
          </div>

          {/* Action Buttons: Duolingo Chunky 3D Style */}
          <div className="space-y-2.5">
            <button
              onClick={() => {
                audioFx.stopSpeaking();
                setIsSpeaking(false);
                audioFx.play('click');
                onClose();
              }}
              className="w-full py-4 rounded-2xl bg-[#39a900] hover:bg-[#329600] border-b-4 border-[#007832] font-black text-sm text-white uppercase tracking-wider shadow-md transition active:translate-y-1 active:border-b-0 flex items-center justify-center gap-2 cursor-pointer"
            >
              <span>Continuar Aprendiendo</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            {onReview && (
              <button
                onClick={() => {
                  audioFx.stopSpeaking();
                  setIsSpeaking(false);
                  audioFx.play('click');
                  onReview();
                }}
                className="w-full py-2.5 text-xs font-bold text-slate-500 dark:text-slate-400 hover:text-[#00324D] dark:hover:text-white transition cursor-pointer"
              >
                Revisar respuestas de esta sesión
              </button>
            )}
          </div>

        </motion.div>
      </div>
    </AnimatePresence>
  );
}
