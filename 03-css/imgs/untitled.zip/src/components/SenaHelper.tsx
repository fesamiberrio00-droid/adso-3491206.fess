import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import NodoTutorAvatar, { TutorEmotion } from './NodoTutorAvatar';

interface SenaHelperProps {
  mood?: 'neutral' | 'happy' | 'thinking' | 'victory' | 'sad';
  text: string;
  onOpenTutor?: () => void;
  className?: string;
  isVisualLearner?: boolean;
}

export default function SenaHelper({ 
  mood = 'neutral', 
  text, 
  onOpenTutor, 
  className = '',
  isVisualLearner = false
}: SenaHelperProps) {
  // Map mood to avatar emotion
  const getAvatarEmotion = (): TutorEmotion => {
    switch (mood) {
      case 'happy':
        return 'happy';
      case 'thinking':
        return 'thinking';
      case 'victory':
        return 'victory';
      default:
        return 'happy';
    }
  };

  const getMoodBadge = () => {
    switch (mood) {
      case 'happy':
        return {
          bg: 'bg-emerald-600',
          text: 'Nodo Bot · ¡Excelente trabajo!',
          border: 'border-emerald-200'
        };
      case 'thinking':
        return {
          bg: 'bg-[#00324D] dark:bg-cyan-900',
          text: 'Nodo Bot · Analizando el código...',
          border: 'border-cyan-200'
        };
      case 'victory':
        return {
          bg: 'bg-amber-500 text-[#002336]',
          text: 'Nodo Bot · ¡Desafío superado!',
          border: 'border-amber-200'
        };
      case 'sad':
        return {
          bg: 'bg-rose-600',
          text: 'Nodo Bot · ¡Revisa el error, tú puedes!',
          border: 'border-rose-200'
        };
      default:
        return {
          bg: 'bg-[#00324D] dark:bg-[#00283d]',
          text: 'Nodo Bot · Tutor IA',
          border: 'border-emerald-200'
        };
    }
  };

  const badge = getMoodBadge();
  const isEnlargedVisual = isVisualLearner && (mood === 'happy' || mood === 'victory');

  return (
    <motion.div 
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className={`flex flex-col sm:flex-row items-center sm:items-start gap-4 bg-white dark:bg-[#131F2E] border-2 ${
        isEnlargedVisual ? 'border-cyan-400 dark:border-cyan-500 shadow-cyan-500/20 shadow-md' : 'border-slate-200 dark:border-slate-800 shadow-xs'
      } p-4 sm:p-5 rounded-3xl transition-all group ${onOpenTutor ? 'cursor-pointer hover:border-emerald-400 dark:hover:border-emerald-500' : ''} ${className}`}
      onClick={onOpenTutor}
    >
      {/* 3D Robot Mascot Avatar with Framer Motion entry/reaction */}
      <AnimatePresence mode="wait">
        <motion.div 
          key={mood}
          initial={{ scale: 0.85, rotate: -4 }}
          animate={isEnlargedVisual ? { 
            scale: [1, 1.15, 1.08], 
            rotate: [0, 4, -4, 0] 
          } : { scale: 1, rotate: 0 }}
          exit={{ scale: 0.85, opacity: 0 }}
          transition={{ type: "spring", stiffness: 350, damping: 20 }}
          className={`relative shrink-0 rounded-2xl bg-gradient-to-tr from-[#021824] via-[#052b3d] to-[#043d4d] p-1.5 flex items-center justify-center border-2 ${
            isEnlargedVisual 
              ? 'w-28 h-28 sm:w-32 sm:h-32 border-cyan-400 ring-4 ring-cyan-400/30 shadow-lg shadow-cyan-500/30' 
              : 'w-20 h-20 border-emerald-400/40 shadow-inner'
          } group-hover:scale-105 transition-all`}
        >
          {isEnlargedVisual && (
            <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-cyan-400/20 to-[#2EE59D]/20 animate-pulse pointer-events-none" />
          )}
          <NodoTutorAvatar
            size={isEnlargedVisual ? 'lg' : 'md'}
            emotion={getAvatarEmotion()}
            showHoloTablet={true}
            showFloatingParticles={true}
            isAnimated={true}
          />
          <span className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-[#2EE59D] rounded-full border-2 border-white dark:border-[#131F2E] animate-pulse" />
        </motion.div>
      </AnimatePresence>

      {/* Bubble text dialogue */}
      <div className="relative flex-1 bg-[#F8FAFC] dark:bg-[#0B131E] border border-slate-200/90 dark:border-slate-800 p-4 rounded-2xl w-full">
        <div className="absolute top-5 -left-2 w-0 h-0 border-t-8 border-t-transparent border-b-8 border-b-transparent border-r-8 border-r-[#F8FAFC] dark:border-r-[#0B131E] hidden sm:block" />

        <div className="flex items-center justify-between gap-2 mb-2">
          <span className={`inline-flex items-center gap-1.5 text-[10px] font-black uppercase tracking-wider px-2.5 py-0.5 rounded-full text-white shadow-2xs ${badge.bg}`}>
            <span className="w-1.5 h-1.5 rounded-full bg-[#2EE59D] inline-block animate-ping" />
            {badge.text}
          </span>

          {onOpenTutor && (
            <span className="text-[11px] font-black text-emerald-600 dark:text-[#2EE59D] hover:underline flex items-center gap-1">
              💬 Abrir chat tutor →
            </span>
          )}
        </div>

        <AnimatePresence mode="wait">
          <motion.p 
            key={text}
            initial={{ opacity: 0, y: 4 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -4 }}
            transition={{ duration: 0.2 }}
            className="text-[#00283d] dark:text-slate-200 font-medium text-sm leading-relaxed whitespace-pre-line"
          >
            {text}
          </motion.p>
        </AnimatePresence>
      </div>
    </motion.div>
  );
}
