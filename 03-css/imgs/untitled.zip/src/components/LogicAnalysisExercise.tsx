import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Bug, Play, CheckCircle2, AlertCircle, ChevronRight, Table, Cpu } from 'lucide-react';
import { audioFx } from '../utils/audioEffects';

interface VariableTraceStep {
  step: number;
  line: string;
  vars: Record<string, string>;
  note: string;
}

interface LogicAnalysisExerciseProps {
  codeLines: string[];
  bugLineNumber: number; // 1-indexed
  bugExplanation: string;
  variableTrace?: VariableTraceStep[];
  selectedLine: number | null;
  onSelectLine: (line: number) => void;
  isAnswerChecked: boolean;
  isCorrect: boolean;
}

export default function LogicAnalysisExercise({
  codeLines,
  bugLineNumber,
  bugExplanation,
  variableTrace = [],
  selectedLine,
  onSelectLine,
  isAnswerChecked,
  isCorrect
}: LogicAnalysisExerciseProps) {
  const [currentStepIndex, setCurrentStepIndex] = useState(0);

  const activeStep = variableTrace.length > 0 ? variableTrace[currentStepIndex] : null;

  return (
    <div className="w-full bg-[#001724] border-2 border-sky-900/60 rounded-2xl p-4 sm:p-5 text-white shadow-inner font-mono text-xs sm:text-sm">
      {/* Exercise Header */}
      <div className="flex items-center justify-between pb-3 border-b border-sky-900/80 mb-4 font-sans">
        <div className="flex items-center gap-2">
          <Cpu className="w-4 h-4 text-sky-400" />
          <span className="text-xs font-black uppercase tracking-wider text-sky-400">
            Reto Lógico · Análisis Paso a Paso & Depuración de Causa-Efecto
          </span>
        </div>
        <span className="text-[11px] font-bold text-slate-400 bg-sky-950/80 px-2.5 py-0.5 rounded-full border border-sky-800">
          Haz clic en la línea que contiene el bug lógico
        </span>
      </div>

      <p className="font-sans text-xs text-slate-300 mb-4">
        🔍 <strong>Instrucciones analíticas:</strong> Inspecciona la ejecución del algoritmo. Examina cómo evolucionan las variables en la memoria y selecciona la línea exacta donde la lógica falla.
      </p>

      {/* Code Inspector with clickable lines */}
      <div className="bg-[#00111a] rounded-xl border border-sky-900/80 overflow-hidden mb-4">
        <div className="bg-[#001c2b] px-3 py-1.5 border-b border-sky-900/80 text-[11px] font-sans text-slate-400 flex items-center justify-between">
          <span>inspector_logico.js</span>
          <span>Depurador en vivo</span>
        </div>

        <div className="p-2 space-y-1">
          {codeLines.map((lineText, idx) => {
            const lineNum = idx + 1;
            const isSelected = selectedLine === lineNum;
            const isActualBug = isAnswerChecked && lineNum === bugLineNumber;
            const isSelectedWrong = isAnswerChecked && isSelected && !isCorrect;

            let rowBg = 'hover:bg-sky-900/30 text-slate-200';
            let lineNumColor = 'text-slate-500';

            if (!isAnswerChecked) {
              if (isSelected) {
                rowBg = 'bg-sky-900/60 text-white font-bold ring-1 ring-sky-400';
                lineNumColor = 'text-sky-400 font-bold';
              }
            } else {
              if (isActualBug) {
                rowBg = 'bg-emerald-950/70 border border-emerald-500 text-emerald-300 font-bold';
                lineNumColor = 'text-emerald-400 font-bold';
              } else if (isSelectedWrong) {
                rowBg = 'bg-rose-950/70 border border-rose-500 text-rose-300 font-bold';
                lineNumColor = 'text-rose-400 font-bold';
              }
            }

            return (
              <div
                key={lineNum}
                onClick={() => {
                  if (isAnswerChecked) return;
                  audioFx.play('click');
                  onSelectLine(lineNum);
                }}
                className={`flex items-center gap-3 px-3 py-1.5 rounded-lg transition cursor-pointer font-mono text-xs sm:text-sm ${rowBg}`}
              >
                <span className={`w-6 text-right select-none ${lineNumColor}`}>
                  {lineNum}
                </span>

                <div className="flex-1 whitespace-pre overflow-x-auto">
                  <code>{lineText}</code>
                </div>

                {isSelected && !isAnswerChecked && (
                  <span className="shrink-0 font-sans text-[10px] bg-sky-500 text-white font-black px-1.5 py-0.5 rounded">
                    Línea Marcada
                  </span>
                )}

                {isActualBug && (
                  <span className="shrink-0 font-sans text-[10px] bg-emerald-500 text-black font-black px-1.5 py-0.5 rounded flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3" />
                    Bug Lógico Aquí
                  </span>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Stepper Variable Trace Table */}
      {variableTrace.length > 0 && (
        <div className="bg-[#00111a] rounded-xl border border-sky-900/70 p-3 font-sans">
          <div className="flex items-center justify-between pb-2 border-b border-sky-900/60 mb-2">
            <div className="flex items-center gap-2 text-xs font-bold text-sky-300">
              <Table className="w-3.5 h-3.5 text-sky-400" />
              <span>Traza de Variables en Memoria (Paso a Paso)</span>
            </div>

            <div className="flex items-center gap-1.5">
              <span className="text-[11px] text-slate-400">
                Paso {currentStepIndex + 1} de {variableTrace.length}
              </span>
              <button
                type="button"
                onClick={() => {
                  audioFx.play('click');
                  setCurrentStepIndex((prev) => (prev + 1) % variableTrace.length);
                }}
                className="px-2 py-0.5 bg-sky-800 hover:bg-sky-700 text-white text-[11px] font-bold rounded flex items-center gap-1 transition cursor-pointer"
              >
                <span>Avanzar</span>
                <ChevronRight className="w-3 h-3" />
              </button>
            </div>
          </div>

          {activeStep && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="space-y-1 bg-[#001b29] p-2.5 rounded-lg border border-sky-900/40">
                <span className="text-[10px] uppercase font-black text-sky-400 block">
                  Estado de Variables en este paso:
                </span>
                <div className="flex flex-wrap gap-2 pt-1 font-mono">
                  {Object.entries(activeStep.vars).map(([vName, vVal]) => (
                    <span key={vName} className="bg-sky-950 px-2 py-1 rounded border border-sky-700/60 text-sky-200">
                      <strong className="text-amber-400">{vName}</strong> = {vVal}
                    </span>
                  ))}
                </div>
              </div>

              <div className="bg-[#001b29] p-2.5 rounded-lg border border-sky-900/40 text-slate-300 text-xs">
                <span className="text-[10px] uppercase font-black text-slate-400 block mb-1">
                  Explicación del Flujo:
                </span>
                <p className="leading-relaxed">{activeStep.note}</p>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
