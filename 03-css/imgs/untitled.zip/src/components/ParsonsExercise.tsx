import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowUp, ArrowDown, GripVertical, CheckCircle, RotateCcw, Play, Sparkles } from 'lucide-react';
import { audioFx } from '../utils/audioEffects';

export interface ParsonsBlock {
  id: string;
  text: string;
  indent?: number; // 0, 1, 2 indentation levels
}

interface ParsonsExerciseProps {
  initialBlocks: ParsonsBlock[];
  solutionOrder: string[]; // Correct ordered block IDs
  onOrderChange: (orderedIds: string[], currentBlocks: ParsonsBlock[]) => void;
  isCompleted?: boolean;
}

export default function ParsonsExercise({
  initialBlocks,
  solutionOrder,
  onOrderChange,
  isCompleted = false
}: ParsonsExerciseProps) {
  const [blocks, setBlocks] = useState<ParsonsBlock[]>(() => {
    // Return shallow copy
    return [...initialBlocks];
  });

  const moveBlock = (fromIndex: number, toIndex: number) => {
    if (toIndex < 0 || toIndex >= blocks.length || isCompleted) return;
    audioFx.play('moveBlock');

    const newBlocks = [...blocks];
    const [moved] = newBlocks.splice(fromIndex, 1);
    newBlocks.splice(toIndex, 0, moved);

    setBlocks(newBlocks);
    onOrderChange(newBlocks.map(b => b.id), newBlocks);
  };

  const resetOrder = () => {
    audioFx.play('click');
    setBlocks([...initialBlocks]);
    onOrderChange(initialBlocks.map(b => b.id), initialBlocks);
  };

  return (
    <div className="w-full bg-slate-900/90 dark:bg-[#001724] border-2 border-slate-700/80 rounded-2xl p-4 sm:p-5 text-white shadow-inner font-mono text-xs sm:text-sm">
      {/* Exercise header */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-700/80 mb-4 font-sans">
        <div className="flex items-center gap-2">
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
          <span className="text-xs font-black uppercase tracking-wider text-emerald-400">
            Reto Kinestésico · Ordena los Bloques de Código (Parsons)
          </span>
        </div>

        <button
          type="button"
          onClick={resetOrder}
          disabled={isCompleted}
          className="text-xs font-bold text-slate-400 hover:text-white flex items-center gap-1 cursor-pointer transition disabled:opacity-40"
          title="Reiniciar orden inicial"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Reiniciar</span>
        </button>
      </div>

      <p className="font-sans text-xs text-slate-300 mb-3">
        🖐️ <strong>Aprende interactuando:</strong> Mueve los bloques de código arriba o abajo para que el algoritmo quede en la secuencia correcta de ejecución.
      </p>

      {/* Blocks reordering list */}
      <div className="space-y-2">
        <AnimatePresence>
          {blocks.map((block, index) => {
            const isFirst = index === 0;
            const isLast = index === blocks.length - 1;
            const indentLevel = block.indent || 0;

            return (
              <motion.div
                key={block.id}
                layout
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ type: "spring", stiffness: 400, damping: 25 }}
                className={`group flex items-center justify-between gap-3 p-3 rounded-xl border-2 transition-all select-none ${
                  isCompleted
                    ? 'bg-emerald-950/40 border-emerald-500/60 text-emerald-300'
                    : 'bg-[#042436] hover:bg-[#073047] border-slate-700 hover:border-emerald-400/80 text-slate-100 shadow-sm'
                }`}
                style={{
                  marginLeft: `${indentLevel * 24}px`
                }}
              >
                {/* Drag handle & Block index */}
                <div className="flex items-center gap-2.5 shrink-0 text-slate-400 font-sans text-xs">
                  <GripVertical className="w-4 h-4 text-slate-500 group-hover:text-emerald-400" />
                  <span className="w-5 h-5 rounded-md bg-slate-800 text-slate-300 flex items-center justify-center font-bold text-[11px]">
                    {index + 1}
                  </span>
                </div>

                {/* Code content */}
                <div className="flex-1 font-mono text-xs sm:text-sm text-[#2EE59D] overflow-x-auto whitespace-pre">
                  <code>{block.text}</code>
                </div>

                {/* Move buttons */}
                {!isCompleted && (
                  <div className="flex items-center gap-1 shrink-0 font-sans">
                    <button
                      type="button"
                      disabled={isFirst}
                      onClick={() => moveBlock(index, index - 1)}
                      className="w-7 h-7 rounded-lg bg-slate-800 hover:bg-emerald-600 disabled:opacity-20 text-white flex items-center justify-center transition cursor-pointer"
                      title="Mover arriba"
                    >
                      <ArrowUp className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      disabled={isLast}
                      onClick={() => moveBlock(index, index + 1)}
                      className="w-7 h-7 rounded-lg bg-slate-800 hover:bg-emerald-600 disabled:opacity-20 text-white flex items-center justify-center transition cursor-pointer"
                      title="Mover abajo"
                    >
                      <ArrowDown className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>

      <div className="mt-3 text-right font-sans text-[11px] text-slate-400">
        Total: {blocks.length} líneas que componen el algoritmo
      </div>
    </div>
  );
}
