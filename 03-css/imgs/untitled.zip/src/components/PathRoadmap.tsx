import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Sparkles, 
  Lock, 
  Unlock, 
  Star, 
  Gift, 
  Flame, 
  Trophy, 
  Play, 
  Check, 
  BookOpen,
  Code2,
  Cpu,
  Zap,
  CheckCircle2,
  Crown,
  ChevronRight
} from 'lucide-react';
import { ModuleRoadmap, RoadmapNode, ThemeMascot, LearningStyleResult } from '../types';
import ThemeMascotCompanion from './ThemeMascotCompanion';
import { audioFx } from '../utils/audioEffects';

export interface ChestClaimResult {
  ok: boolean;
  error?: string;
  rewardBits?: number;
  rewardXP?: number;
}

interface PathRoadmapProps {
  roadmapData: ModuleRoadmap;
  activeModuleId: string;
  onSelectModule: (moduleId: string) => void;
  onStartLessonNode: (node: RoadmapNode, withAI: boolean) => void;
  onClaimChest: (nodeId: string, rewardBits: number, rewardXP: number) => Promise<ChestClaimResult>;
  userClaimedNodes?: Record<string, boolean>;
  learningStyleProfile?: LearningStyleResult | null;
  withAI: boolean;
  onToggleAI: (enabled: boolean) => void;
  isLoadingAI?: boolean;
  hideModuleTabs?: boolean;
}

export default function PathRoadmap({
  roadmapData,
  activeModuleId,
  onSelectModule,
  onStartLessonNode,
  onClaimChest,
  userClaimedNodes = {},
  learningStyleProfile,
  withAI,
  onToggleAI,
  isLoadingAI = false,
  hideModuleTabs = false
}: PathRoadmapProps) {
  const [selectedChestNode, setSelectedChestNode] = useState<RoadmapNode | null>(null);
  const [chestOpening, setChestOpening] = useState(false);
  const [claimedSuccess, setClaimedSuccess] = useState(false);
  const [chestError, setChestError] = useState<string>('');
  const [claimedRewards, setClaimedRewards] = useState<{ bits: number; xp: number } | null>(null);
  const [mascotAnimState, setMascotAnimState] = useState<'idle' | 'talking' | 'celebrating'>('idle');

  // Available module areas
  const modulesList = [
    { id: 'python', label: 'Python', icon: '🐍', color: '#0284C7' },
    { id: 'javascript', label: 'JavaScript', icon: '⚡', color: '#FACC15' },
    { id: 'logica', label: 'Lógica', icon: '🤖', color: '#2EE59D' },
    { id: 'algoritmos', label: 'Algoritmos', icon: '🧠', color: '#8B5CF6' },
    { id: 'basesdatos', label: 'Bases de Datos', icon: '🗄️', color: '#7C3AED' }
  ];

  // Resolve levels list (supporting both `roadmapData.levels` and `roadmapData.roadmap.nodes`)
  const nodes: RoadmapNode[] = (roadmapData.levels && roadmapData.levels.length > 0)
    ? roadmapData.levels
    : (roadmapData.roadmap?.nodes || []);

  const sectionTitle = roadmapData.unitTitle || roadmapData.roadmap?.sectionTitle || "Unidad de Aprendizaje";
  const mascot: ThemeMascot = roadmapData.themeMascot;

  // Geometry constants for exact center-to-center SVG alignment (Zero Broken Lines)
  const SVG_WIDTH = 360;
  const ROW_HEIGHT = 120;
  const TOP_PADDING = 50;
  const TOTAL_HEIGHT = TOP_PADDING * 2 + Math.max(nodes.length - 1, 1) * ROW_HEIGHT;

  // Map curveOffset [-1, 0, 1] to exact SVG X coordinate
  const getNodeSvgX = (offset: number) => {
    switch (offset) {
      case -1: return 85;   // Left column
      case 1: return 275;   // Right column
      case 0:
      default: return 180;  // Center column
    }
  };

  // Find index of the first active (unlocked and not yet completed) node
  const activeNodeIndex = nodes.findIndex(n => {
    const isClaimed = userClaimedNodes[n.id] || n.isClaimed;
    return !n.isLocked && !n.isCompleted && !isClaimed;
  });

  const currentActiveNode = activeNodeIndex !== -1 
    ? nodes[activeNodeIndex] 
    : nodes[0];

  const handleOpenChest = async (node: RoadmapNode) => {
    if (chestOpening || selectedChestNode) return;
    if (node.isLocked) {
      audioFx.play('error');
      return;
    }
    const isAlreadyClaimed = userClaimedNodes[node.id] || node.isClaimed || node.isCompleted;
    if (isAlreadyClaimed) {
      audioFx.play('click');
      return;
    }

    setSelectedChestNode(node);
    setChestOpening(true);
    setClaimedSuccess(false);
    setChestError('');
    setClaimedRewards(null);
    setMascotAnimState('celebrating');
    audioFx.play('chestOpen');

    try {
      const [result] = await Promise.all([
        onClaimChest(node.id, node.rewardBits, node.rewardXP),
        new Promise(resolve => setTimeout(resolve, 500))
      ]);

      setChestOpening(false);
      if (result?.ok) {
        setClaimedSuccess(true);
        setClaimedRewards({
          bits: typeof result.rewardBits === 'number' ? result.rewardBits : node.rewardBits,
          xp: typeof result.rewardXP === 'number' ? result.rewardXP : node.rewardXP
        });
      } else {
        setClaimedSuccess(false);
        setChestError(result?.error || 'No se pudo confirmar el reclamo del cofre en el servidor.');
        setMascotAnimState('idle');
        audioFx.play('error');
      }
    } catch {
      setChestOpening(false);
      setClaimedSuccess(false);
      setChestError('Error de conexión al intentar reclamar el cofre.');
      setMascotAnimState('idle');
      audioFx.play('error');
    }
  };

  const handleNodeClick = (node: RoadmapNode) => {
    audioFx.play('click');
    if (node.isLocked) {
      audioFx.play('error');
      return;
    }

    const nodeType = node.type || node.nodeType || 'lesson';

    if (nodeType === 'chest' || nodeType === 'chest_reward') {
      handleOpenChest(node);
      return;
    }

    if (nodeType === 'boss' || nodeType === 'boss_challenge') {
      audioFx.play('bossAlert');
    }

    setMascotAnimState('talking');
    onStartLessonNode(node, withAI);
  };

  const isMascotOnLeft = mascot.mascotPlacement !== 'right_side';

  return (
    <div className="w-full flex flex-col items-center select-none pb-12">
      
      {/* 1. MODULE AREA TABS (Only if not hidden by top bar) */}
      {!hideModuleTabs && (
        <div className="w-full max-w-4xl mb-4 bg-white dark:bg-[#0F172A] border-2 border-slate-200 dark:border-slate-800 rounded-2xl p-1.5 shadow-xs">
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0 scrollbar-none">
            {modulesList.map((m) => {
              const isSelected = activeModuleId === m.id;
              return (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => {
                    audioFx.play('click');
                    onSelectModule(m.id);
                  }}
                  className={`flex-1 min-w-[100px] py-2 px-3 rounded-xl font-black text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                    isSelected
                      ? 'bg-[#00283D] text-white shadow-xs scale-102 border-2'
                      : 'text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800/60'
                  }`}
                  style={isSelected ? { borderColor: m.color } : {}}
                >
                  <span className="text-sm">{m.icon}</span>
                  <span>{m.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* 2. SECTION COMPACT BANNER & MODE SWITCHER */}
      <div className="w-full max-w-4xl mb-6 bg-white dark:bg-[#0F172A] border-2 border-slate-200 dark:border-slate-800 rounded-2xl p-4 text-[#00324D] dark:text-white shadow-xs relative overflow-hidden flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div 
            className="w-11 h-11 rounded-2xl flex items-center justify-center text-2xl shrink-0 shadow-xs border"
            style={{ 
              backgroundColor: `${mascot.themeColor}15`, 
              borderColor: `${mascot.themeColor}40`
            }}
          >
            {mascot.avatar}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-black uppercase tracking-wider text-slate-400 dark:text-slate-500">
                {roadmapData.moduleTitle}
              </span>
              <span className="w-1 h-1 rounded-full bg-slate-300 dark:bg-slate-700" />
              <span 
                className="text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full"
                style={{ 
                  backgroundColor: `${mascot.themeColor}20`,
                  color: mascot.themeColor || '#38BDF8'
                }}
              >
                Sendero Activo
              </span>
            </div>
            <h2 className="text-base sm:text-lg font-black tracking-tight text-[#00324D] dark:text-white">
              {sectionTitle}
            </h2>
          </div>
        </div>

        {/* Mode Switch: Estándar vs IA */}
        <div className="flex items-center gap-1.5 bg-slate-100 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700/80 p-1 rounded-xl shrink-0 self-start sm:self-auto">
          <button
            type="button"
            onClick={() => {
              audioFx.play('click');
              onToggleAI(false);
            }}
            className={`px-3 py-1.5 rounded-lg text-xs font-black uppercase tracking-wider transition cursor-pointer ${
              !withAI 
                ? 'bg-white dark:bg-slate-700 text-[#00283D] dark:text-white shadow-xs' 
                : 'text-slate-400 hover:text-slate-600 dark:hover:text-white'
            }`}
          >
            📘 Estándar
          </button>
          <button
            type="button"
            onClick={() => {
              audioFx.play('click');
              onToggleAI(true);
            }}
            className={`px-3 py-1.5 rounded-lg text-xs font-black uppercase tracking-wider transition flex items-center gap-1.5 cursor-pointer ${
              withAI 
                ? 'bg-gradient-to-r from-purple-600 to-cyan-500 text-white shadow-xs' 
                : 'text-slate-400 hover:text-slate-600 dark:hover:text-white'
            }`}
          >
            <Sparkles className="w-3 h-3 text-amber-300 animate-pulse" />
            <span>Con IA</span>
          </button>
        </div>
      </div>

      {/* 3. RESPONSIVE CONTAINER WITH LATERAL MASCOT PLACEMENT (NO SQUARE BOX ON TOP) */}
      <div className="w-full max-w-4xl relative flex justify-center items-start gap-6 lg:gap-10">

        {/* DESKTOP LEFT LATERAL COLUMN (When mascotPlacement is left_side) */}
        {isMascotOnLeft && (
          <div className="hidden lg:block w-72 shrink-0 sticky top-28 pt-8">
            <ThemeMascotCompanion
              mascot={mascot}
              moduleId={activeModuleId}
              animationState={mascotAnimState}
              onAskTip={() => {
                if (currentActiveNode?.question?.audioTip) {
                  audioFx.speak(currentActiveNode.question.audioTip);
                } else {
                  audioFx.speak(`¡Concentración! Pythie te aconseja revisar los fundamentos para avanzar.`);
                }
              }}
            />

            {/* Quick Helper Tip Card */}
            <div className="mt-4 p-3 bg-white/60 dark:bg-slate-900/60 backdrop-blur-sm border border-slate-200/80 dark:border-slate-800 rounded-2xl text-[11px] text-slate-500 dark:text-slate-400 text-center">
              💡 <span className="font-bold text-[#00324D] dark:text-white">Tip Pedagógico:</span> Cada nivel adapta explicaciones y retos a tu perfil cognitivo activo.
            </div>
          </div>
        )}

        {/* CENTER COLUMN: CONTINUOUS WINDING ROADMAP PATH */}
        <div 
          className="relative w-full max-w-[360px] shrink-0 flex justify-center"
          style={{ height: `${TOTAL_HEIGHT}px` }}
        >
          {/* Continuous Center-to-Center SVG Vectorial Path (CERO LÍNEAS ROTAS) */}
          <svg 
            viewBox={`0 0 ${SVG_WIDTH} ${TOTAL_HEIGHT}`}
            className="absolute inset-0 w-full h-full pointer-events-none"
            preserveAspectRatio="xMidYMid meet"
          >
            <defs>
              <linearGradient id="activePathGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor={mascot.pathColor || "#38BDF8"} />
                <stop offset="100%" stopColor={mascot.themeColor || "#0284C7"} />
              </linearGradient>
              <filter id="neonGlow" x="-20%" y="-20%" width="140%" height="140%">
                <feGaussianBlur stdDeviation="3" result="blur" />
                <feComposite in="SourceGraphic" in2="blur" operator="over" />
              </filter>
            </defs>

            {nodes.map((node, idx) => {
              if (idx === nodes.length - 1) return null;
              const nextNode = nodes[idx + 1];

              const x1 = getNodeSvgX(node.curveOffset);
              const y1 = TOP_PADDING + idx * ROW_HEIGHT;
              const x2 = getNodeSvgX(nextNode.curveOffset);
              const y2 = TOP_PADDING + (idx + 1) * ROW_HEIGHT;
              const midY = (y1 + y2) / 2;

              // Smooth cubic bezier with strict vertical tangents at both centers
              const d = `M ${x1} ${y1} C ${x1} ${midY}, ${x2} ${midY}, ${x2} ${y2}`;

              const isSegmentActive = !node.isLocked && !nextNode.isLocked;

              return (
                <g key={`curve-${node.id}-${nextNode.id}`}>
                  {/* Thick background track */}
                  <path
                    d={d}
                    fill="none"
                    stroke="#334155"
                    strokeWidth="14"
                    strokeLinecap="round"
                    className="dark:stroke-slate-800 stroke-slate-200"
                  />
                  {/* Inner track border */}
                  <path
                    d={d}
                    fill="none"
                    stroke="#1E293B"
                    strokeWidth="8"
                    strokeLinecap="round"
                    className="dark:stroke-slate-900 stroke-slate-300"
                  />
                  {/* Active Neon Glow path */}
                  {isSegmentActive && (
                    <path
                      d={d}
                      fill="none"
                      stroke="url(#activePathGrad)"
                      strokeWidth="6"
                      strokeLinecap="round"
                      filter="url(#neonGlow)"
                      className="opacity-95"
                    />
                  )}
                </g>
              );
            })}
          </svg>

          {/* Interactive Nodes Placed Exactly at Coordinate Centers */}
          {nodes.map((node, idx) => {
            const x = getNodeSvgX(node.curveOffset);
            const y = TOP_PADDING + idx * ROW_HEIGHT;
            const leftPercent = (x / SVG_WIDTH) * 100;

            const nodeType = node.type || node.nodeType || 'lesson';
            const isCompleted = Boolean(node.isCompleted || userClaimedNodes[node.id] || node.isClaimed);
            const isActive = !node.isLocked && !isCompleted;
            const isLocked = Boolean(node.isLocked && !isCompleted);

            return (
              <div
                key={node.id}
                className="absolute flex flex-col items-center -translate-x-1/2 -translate-y-1/2"
                style={{
                  top: `${y}px`,
                  left: `${leftPercent}%`
                }}
              >
                {/* CHEST NODE */}
                {(nodeType === 'chest' || nodeType === 'chest_reward') ? (
                  <motion.button
                    type="button"
                    whileHover={!isLocked ? { scale: 1.15 } : {}}
                    whileTap={!isLocked ? { scale: 0.95 } : {}}
                    onClick={() => handleOpenChest(node)}
                    disabled={isLocked}
                    className={`relative w-16 h-16 sm:w-18 sm:h-18 rounded-3xl flex items-center justify-center transition-all cursor-pointer shadow-xl ${
                      isCompleted
                        ? 'bg-gradient-to-tr from-emerald-600 to-teal-400 text-white border-3 border-emerald-300'
                        : isLocked
                        ? 'bg-slate-200 dark:bg-slate-800 text-slate-400 dark:text-slate-600 border-2 border-slate-300 dark:border-slate-700 cursor-not-allowed opacity-70'
                        : 'bg-gradient-to-tr from-amber-500 via-amber-400 to-yellow-300 text-amber-950 border-3 border-yellow-200 shadow-amber-500/30'
                    }`}
                  >
                    {isCompleted ? (
                      <Check className="w-8 h-8 stroke-[3]" />
                    ) : (
                      <div className="relative flex items-center justify-center">
                        <Gift className="w-8 h-8 text-[#00283D]" />
                        {!isLocked && (
                          <span className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full animate-ping" />
                        )}
                      </div>
                    )}

                    {/* Reward Floating Badge */}
                    <span className="absolute -bottom-2 px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider bg-black/80 text-amber-300 border border-amber-400/30 shadow-md">
                      +{node.rewardBits} 💻
                    </span>
                  </motion.button>
                ) : (nodeType === 'boss' || nodeType === 'boss_challenge') ? (
                  /* BOSS CHALLENGE NODE */
                  <motion.button
                    type="button"
                    whileHover={!isLocked ? { scale: 1.12 } : {}}
                    whileTap={!isLocked ? { scale: 0.95 } : {}}
                    onClick={() => handleNodeClick(node)}
                    disabled={isLocked}
                    className={`relative w-20 h-20 sm:w-22 sm:h-22 rounded-full flex items-center justify-center transition-all cursor-pointer shadow-2xl ${
                      isCompleted
                        ? 'bg-gradient-to-tr from-emerald-600 to-teal-500 text-white border-4 border-emerald-300'
                        : isLocked
                        ? 'bg-slate-200 dark:bg-slate-800 text-slate-400 dark:text-slate-600 border-3 border-slate-300 dark:border-slate-700 cursor-not-allowed opacity-60'
                        : 'bg-gradient-to-tr from-rose-600 via-red-500 to-amber-500 text-white border-4 border-amber-300 shadow-red-500/40 ring-4 ring-rose-500/20'
                    }`}
                  >
                    {isCompleted ? (
                      <Check className="w-10 h-10 stroke-[3]" />
                    ) : (
                      <div className="relative flex flex-col items-center">
                        <Crown className="w-9 h-9 text-yellow-200" />
                        <span className="text-[9px] font-black uppercase tracking-wider">JEFE</span>
                      </div>
                    )}

                    {/* Boss reward pill */}
                    <span className="absolute -bottom-2.5 px-2.5 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider bg-red-950 text-red-200 border border-red-500 shadow-md">
                      +{node.rewardBits} 💻 · +{node.rewardXP} XP
                    </span>
                  </motion.button>
                ) : (
                  /* REGULAR LESSON NODE */
                  <motion.button
                    type="button"
                    whileHover={!isLocked ? { scale: 1.12 } : {}}
                    whileTap={!isLocked ? { scale: 0.95 } : {}}
                    onClick={() => handleNodeClick(node)}
                    disabled={isLocked}
                    className={`relative w-16 h-16 sm:w-18 sm:h-18 rounded-full flex items-center justify-center transition-all cursor-pointer shadow-xl ${
                      isCompleted
                        ? 'bg-gradient-to-tr from-emerald-500 to-teal-400 text-white border-3 border-emerald-200 shadow-emerald-500/20'
                        : isActive
                        ? 'bg-gradient-to-tr from-[#0284C7] to-cyan-400 text-white border-3 border-cyan-200 shadow-cyan-500/30 ring-4 ring-cyan-400/20'
                        : 'bg-slate-200 dark:bg-slate-800 text-slate-400 dark:text-slate-600 border-2 border-slate-300 dark:border-slate-700 cursor-not-allowed opacity-70'
                    }`}
                    style={isActive ? { borderColor: mascot.themeColor } : {}}
                  >
                    {isCompleted ? (
                      <Check className="w-8 h-8 stroke-[3]" />
                    ) : isLocked ? (
                      <Lock className="w-6 h-6" />
                    ) : (
                      <Play className="w-7 h-7 fill-white translate-x-0.5" />
                    )}

                    {/* Star ratings */}
                    {!isLocked && (
                      <div className="absolute -top-2 flex gap-0.5 bg-black/60 px-1.5 py-0.5 rounded-full border border-white/20">
                        {[1, 2, 3].map((starIdx) => (
                          <Star 
                            key={starIdx} 
                            className={`w-2.5 h-2.5 ${
                              starIdx <= (node.stars || 0)
                                ? 'text-amber-400 fill-amber-400' 
                                : 'text-slate-500'
                            }`}
                          />
                        ))}
                      </div>
                    )}
                  </motion.button>
                )}

                {/* Level Title Label */}
                <div className="mt-2.5 px-2.5 py-1 rounded-xl bg-white/90 dark:bg-[#0F172A]/90 backdrop-blur-sm border border-slate-200/80 dark:border-slate-800 shadow-sm max-w-[130px] text-center">
                  <p className="text-[11px] font-black text-[#00324D] dark:text-white truncate">
                    {node.title}
                  </p>
                  <p className="text-[9px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">
                    {isCompleted ? '✓ Completado' : isLocked ? 'Bloqueado' : 'Disponible'}
                  </p>
                </div>
              </div>
            );
          })}
        </div>

        {/* DESKTOP RIGHT LATERAL COLUMN (When mascotPlacement is right_side or companion widget) */}
        {!isMascotOnLeft && (
          <div className="hidden lg:block w-72 shrink-0 sticky top-28 pt-8">
            <ThemeMascotCompanion
              mascot={mascot}
              moduleId={activeModuleId}
              animationState={mascotAnimState}
              onAskTip={() => {
                if (currentActiveNode?.question?.audioTip) {
                  audioFx.speak(currentActiveNode.question.audioTip);
                } else {
                  audioFx.speak(`¡Adelante! Conecta los eventos y domina el nodo con Voltio JS.`);
                }
              }}
            />

            <div className="mt-4 p-3 bg-white/60 dark:bg-slate-900/60 backdrop-blur-sm border border-slate-200/80 dark:border-slate-800 rounded-2xl text-[11px] text-slate-500 dark:text-slate-400 text-center">
              ⚡ <span className="font-bold text-[#00324D] dark:text-white">Energía Activa:</span> Los nodos conectados alimentan la racha de tu perfil.
            </div>
          </div>
        )}
      </div>

      {/* MOBILE COMPACT FLOATING MASCOT (Fixed at bottom right, never breaks width) */}
      <div className="lg:hidden fixed bottom-6 right-6 z-40">
        <ThemeMascotCompanion
          mascot={mascot}
          moduleId={activeModuleId}
          animationState={mascotAnimState}
          isMobileCompact={true}
          onAskTip={() => {
            if (currentActiveNode?.question?.audioTip) {
              audioFx.speak(currentActiveNode.question.audioTip);
            }
          }}
        />
      </div>

      {/* CHEST REWARD OPENING MODAL */}
      <AnimatePresence>
        {selectedChestNode && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md">
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
              className={`bg-white dark:bg-[#0F172A] border-3 ${chestError ? 'border-rose-400' : 'border-amber-400'} rounded-3xl max-w-sm w-full p-6 text-center shadow-2xl relative overflow-hidden`}
            >
              <div className={`w-20 h-20 mx-auto mb-4 ${chestError ? 'bg-rose-500/15 text-rose-500 border-rose-400/40' : 'bg-amber-400/20 text-amber-500 border-amber-400/40'} rounded-3xl flex items-center justify-center text-4xl shadow-inner border`}>
                {chestOpening ? '🎁' : chestError ? '⚠️' : '🎉'}
              </div>

              <h3 className="text-xl font-black text-[#00324D] dark:text-white mb-1">
                {chestOpening ? 'Abriendo Cofre...' : claimedSuccess ? '¡Recompensa Reclamada!' : chestError ? 'No se pudo reclamar' : 'Abriendo Cofre...'}
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">
                {chestError
                  ? 'No se modificó tu saldo de XP ni Bits.'
                  : claimedSuccess
                    ? `Has desbloqueado y guardado en tu cuenta el cofre ${selectedChestNode.title} de ${roadmapData.moduleTitle}.`
                    : `Validando el cofre ${selectedChestNode.title} en el servidor...`}
              </p>

              {chestError && (
                <div className="mb-4 p-3 rounded-2xl bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-800 text-rose-700 dark:text-rose-300 text-xs font-bold">
                  {chestError}
                </div>
              )}

              {/* Rewards breakdown */}
              {!chestError && (
                <div className="grid grid-cols-2 gap-3 mb-5">
                  <div className="bg-amber-500/10 border border-amber-500/30 rounded-2xl p-3">
                    <span className="text-xs font-bold text-amber-600 dark:text-amber-400 block uppercase">Bits de Computación</span>
                    <span className="text-2xl font-black text-amber-600 dark:text-amber-400">+{claimedRewards?.bits ?? selectedChestNode.rewardBits} 💻</span>
                  </div>
                  <div className="bg-cyan-500/10 border border-cyan-500/30 rounded-2xl p-3">
                    <span className="text-xs font-bold text-cyan-600 dark:text-cyan-400 block uppercase">Experiencia</span>
                    <span className="text-2xl font-black text-cyan-600 dark:text-cyan-400">+{claimedRewards?.xp ?? selectedChestNode.rewardXP} XP</span>
                  </div>
                </div>
              )}

              <button
                type="button"
                disabled={chestOpening}
                onClick={() => {
                  if (chestOpening) return;
                  setSelectedChestNode(null);
                  setClaimedSuccess(false);
                  setChestError('');
                  setClaimedRewards(null);
                  setMascotAnimState('idle');
                }}
                className="w-full py-3 bg-[#00283D] hover:bg-[#003E5E] disabled:opacity-50 text-white font-black text-xs uppercase tracking-wider rounded-xl transition cursor-pointer shadow-md"
              >
                {chestOpening ? 'Validando...' : chestError ? 'Cerrar' : 'Continuar Sendero'}
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
