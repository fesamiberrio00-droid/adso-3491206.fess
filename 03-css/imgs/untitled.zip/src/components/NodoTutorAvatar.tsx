import React from 'react';
import { motion, AnimatePresence } from 'motion/react';

export type TutorEmotion = 'happy' | 'thinking' | 'explaining' | 'victory' | 'neutral';

interface NodoTutorAvatarProps {
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl' | '2xl';
  emotion?: TutorEmotion;
  showHoloTablet?: boolean;
  showFloatingParticles?: boolean;
  className?: string;
  isAnimated?: boolean;
  isResponding?: boolean; // Active speaking or responding state
  onClick?: () => void;
}

export default function NodoTutorAvatar({
  size = 'md',
  emotion = 'happy',
  showHoloTablet = true,
  showFloatingParticles = false,
  className = '',
  isAnimated = true,
  isResponding = false,
  onClick
}: NodoTutorAvatarProps) {
  // Size presets
  const sizeMap = {
    xs: 32,
    sm: 48,
    md: 72,
    lg: 110,
    xl: 180,
    '2xl': 260,
  };

  const dim = sizeMap[size];

  // Expressive motion variants for entrance & exit
  const containerVariants = {
    initial: { 
      scale: 0.65, 
      opacity: 0, 
      y: 16,
      rotate: -5
    },
    animate: { 
      scale: 1, 
      opacity: 1, 
      y: 0,
      rotate: 0,
      transition: {
        type: 'spring' as const,
        stiffness: 340,
        damping: 22,
        mass: 0.8
      }
    },
    exit: { 
      scale: 0.7, 
      opacity: 0, 
      y: -14,
      rotate: 4,
      transition: { 
        duration: 0.22,
        ease: "easeIn" as const 
      } 
    }
  };

  // Emotion-specific reaction variants
  const getReactionAnimation = () => {
    if (!isAnimated) return undefined;
    if (isResponding) {
      return {
        y: [0, -6, 1, -4, 0],
        rotate: [0, -2, 2, -1, 0],
        scale: [1, 1.05, 0.98, 1.03, 1],
        transition: {
          duration: 1.6,
          repeat: Infinity,
          ease: "easeInOut" as const
        }
      };
    }
    if (emotion === 'victory') {
      return {
        y: [0, -10, 2, -6, 0],
        rotate: [0, -4, 4, -2, 0],
        scale: [1, 1.06, 0.96, 1.04, 1],
        transition: {
          duration: 1.8,
          repeat: Infinity,
          ease: "easeInOut" as const
        }
      };
    }
    if (emotion === 'thinking') {
      return {
        y: [0, -3, 0],
        rotate: [-2, 3, -2],
        transition: {
          duration: 2.8,
          repeat: Infinity,
          ease: "easeInOut" as const
        }
      };
    }
    if (emotion === 'explaining') {
      return {
        y: [0, -5, 0],
        rotate: [0, -1.5, 1.5, 0],
        transition: {
          duration: 2.2,
          repeat: Infinity,
          ease: "easeInOut" as const
        }
      };
    }
    // Idle gentle float
    return {
      y: [0, -4, 0],
      rotate: [-0.5, 0.5, -0.5],
      transition: {
        duration: 3.4,
        repeat: Infinity,
        ease: "easeInOut" as const
      }
    };
  };

  return (
    <motion.div
      variants={isAnimated ? containerVariants : undefined}
      initial="initial"
      animate="animate"
      exit="exit"
      whileHover={isAnimated ? { scale: 1.08, rotate: 2 } : undefined}
      whileTap={isAnimated ? { scale: 0.94 } : undefined}
      onClick={onClick}
      className={`relative inline-flex items-center justify-center select-none ${className} ${onClick ? 'cursor-pointer' : ''}`}
      style={{ width: dim, height: dim }}
    >
      {/* Living Floating & Reaction Motion Wrapper */}
      <motion.div
        animate={getReactionAnimation()}
        className="w-full h-full relative flex items-center justify-center"
      >
        <svg
          viewBox="0 0 280 280"
          width={dim}
          height={dim}
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="w-full h-full drop-shadow-md overflow-visible"
        >
          <defs>
            {/* Mint-Green / Cyan Chassis Gradients */}
            <linearGradient id="bodyGrad" x1="60" y1="60" x2="220" y2="240" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#6EE7B7" />
              <stop offset="35%" stopColor="#34D399" />
              <stop offset="85%" stopColor="#059669" />
              <stop offset="100%" stopColor="#047857" />
            </linearGradient>

            <linearGradient id="headHighlight" x1="100" y1="50" x2="180" y2="150" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#A7F3D0" />
              <stop offset="100%" stopColor="#10B981" />
            </linearGradient>

            {/* Visor Screen Dark Glossy Gradient */}
            <linearGradient id="visorGrad" x1="80" y1="90" x2="200" y2="170" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#021E2A" />
              <stop offset="60%" stopColor="#042C3D" />
              <stop offset="100%" stopColor="#01131B" />
            </linearGradient>

            {/* Visor Gloss Reflection */}
            <linearGradient id="visorGloss" x1="90" y1="90" x2="190" y2="130" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#ffffff" stopOpacity="0.35" />
              <stop offset="45%" stopColor="#ffffff" stopOpacity="0.08" />
              <stop offset="100%" stopColor="#ffffff" stopOpacity="0" />
            </linearGradient>

            {/* Holographic Tablet Gradient */}
            <linearGradient id="holoGrad" x1="120" y1="160" x2="230" y2="230" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#00F5D4" stopOpacity="0.9" />
              <stop offset="50%" stopColor="#00BBF9" stopOpacity="0.5" />
              <stop offset="100%" stopColor="#00F5D4" stopOpacity="0.2" />
            </linearGradient>

            {/* Cyan Glow Filter */}
            <filter id="cyanGlow" x="-30%" y="-30%" width="160%" height="160%">
              <feGaussianBlur stdDeviation="3.5" result="blur" />
              <feMerge>
                <feMergeNode in="blur" />
                <feMergeNode in="SourceGraphic" />
              </feMerge>
            </filter>

            <filter id="softGlow" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="2" result="blur" />
              <feMerge>
                <feMergeNode in="blur" />
                <feMergeNode in="SourceGraphic" />
              </feMerge>
            </filter>
          </defs>

          {/* FLOATING CODE PARTICLES & SPARKLES */}
          {(showFloatingParticles || emotion === 'victory') && (
            <g opacity="0.85">
              <text x="20" y="55" fill="#2EE59D" fontSize="13" fontFamily="monospace" fontWeight="bold">{'<>'}</text>
              <text x="245" y="75" fill="#00E5FF" fontSize="13" fontFamily="monospace" fontWeight="bold">{'{}'}</text>
              <text x="15" y="155" fill="#38BDF8" fontSize="11" fontFamily="monospace" fontWeight="bold">{'[]'}</text>
              <text x="240" y="195" fill="#2EE59D" fontSize="12" fontFamily="monospace" fontWeight="bold">{'</>'}</text>
              
              {/* Victory celebration stars */}
              {emotion === 'victory' && (
                <>
                  <circle cx="45" cy="40" r="3.5" fill="#FDC300" filter="url(#cyanGlow)" />
                  <circle cx="230" cy="45" r="4" fill="#FDC300" filter="url(#cyanGlow)" />
                  <path d="M 140 10 L 143 18 L 151 18 L 145 23 L 147 31 L 140 26 L 133 31 L 135 23 L 129 18 L 137 18 Z" fill="#FDC300" filter="url(#cyanGlow)" />
                </>
              )}
              
              {/* Thinking pulsating energy pulse */}
              {emotion === 'thinking' && (
                <>
                  <circle cx="140" cy="30" r="4" fill="#00F5D4" opacity="0.75" />
                  <circle cx="155" cy="20" r="3" fill="#00F5D4" opacity="0.6" />
                  <circle cx="170" cy="12" r="2.5" fill="#00F5D4" opacity="0.45" />
                </>
              )}
            </g>
          )}

          {/* 1. ANTENNA EARS WITH CODE SCREENS ({ } on left, [ ] on right) */}
          {/* Left Ear Antenna Stem */}
          <path d="M 88 88 L 72 58" stroke="#047857" strokeWidth="8" strokeLinecap="round" />
          <g transform="translate(48, 26) rotate(-15)">
            <rect x="0" y="0" width="36" height="42" rx="14" fill="url(#bodyGrad)" stroke="#047857" strokeWidth="2.5" />
            <rect x="5" y="6" width="26" height="30" rx="9" fill="#03222E" />
            <text 
              x="18" 
              y="27" 
              textAnchor="middle" 
              fill="#00F5D4" 
              fontSize="18" 
              fontFamily="'JetBrains Mono', monospace" 
              fontWeight="bold"
              filter="url(#softGlow)"
            >
              {'{ }'}
            </text>
          </g>

          {/* Right Ear Antenna Stem */}
          <path d="M 192 88 L 208 58" stroke="#047857" strokeWidth="8" strokeLinecap="round" />
          <g transform="translate(196, 26) rotate(15)">
            <rect x="0" y="0" width="36" height="42" rx="14" fill="url(#bodyGrad)" stroke="#047857" strokeWidth="2.5" />
            <rect x="5" y="6" width="26" height="30" rx="9" fill="#03222E" />
            <text 
              x="18" 
              y="26" 
              textAnchor="middle" 
              fill="#00F5D4" 
              fontSize="17" 
              fontFamily="'JetBrains Mono', monospace" 
              fontWeight="bold"
              filter="url(#softGlow)"
            >
              {'[ ]'}
            </text>
          </g>

          {/* 2. CHUBBY ROBOT BODY & LEGS */}
          <ellipse cx="140" cy="255" rx="65" ry="12" fill="#001824" opacity="0.25" />

          {/* Left Foot */}
          <rect x="94" y="215" width="34" height="35" rx="16" fill="url(#bodyGrad)" stroke="#047857" strokeWidth="2" />
          <text x="111" y="238" textAnchor="middle" fill="#00F5D4" fontSize="11" fontFamily="monospace" fontWeight="bold">
            {'{ }'}
          </text>

          {/* Right Foot */}
          <rect x="152" y="215" width="34" height="35" rx="16" fill="url(#bodyGrad)" stroke="#047857" strokeWidth="2" />
          <text x="169" y="238" textAnchor="middle" fill="#00F5D4" fontSize="11" fontFamily="monospace" fontWeight="bold">
            {'</>'}
          </text>

          {/* Round Chubby Torso */}
          <rect x="80" y="145" width="120" height="92" rx="46" fill="url(#bodyGrad)" stroke="#047857" strokeWidth="2.5" />
          <ellipse cx="140" cy="180" rx="48" ry="32" fill="#10B981" opacity="0.35" />

          {/* Glowing Circuit Glyphs on Torso */}
          <g opacity="0.85">
            <text x="110" y="175" fill="#00F5D4" fontSize="13" fontFamily="monospace" fontWeight="bold" filter="url(#softGlow)">
              {'{ }'}
            </text>
            <text x="135" y="210" fill="#00F5D4" fontSize="12" fontFamily="monospace" fontWeight="bold" filter="url(#softGlow)">
              {'1 0 1'}
            </text>
          </g>

          {/* 3. HEAD */}
          <rect x="62" y="58" width="156" height="120" rx="55" fill="url(#bodyGrad)" stroke="#047857" strokeWidth="3" />
          <ellipse cx="140" cy="78" rx="55" ry="16" fill="#A7F3D0" opacity="0.45" />

          {/* Side Ear-Caps / Headphones with Glowing Cyan Ring */}
          <ellipse cx="62" cy="118" rx="8" ry="24" fill="#047857" />
          <ellipse cx="60" cy="118" rx="5" ry="18" fill="#00F5D4" filter="url(#softGlow)" opacity="0.85" />
          <ellipse cx="218" cy="118" rx="8" ry="24" fill="#047857" />
          <ellipse cx="220" cy="118" rx="5" ry="18" fill="#00F5D4" filter="url(#softGlow)" opacity="0.85" />

          {/* 4. VISOR */}
          <rect x="82" y="74" width="116" height="88" rx="36" fill="url(#visorGrad)" stroke="#021E2A" strokeWidth="3" />
          
          {/* Visor Glass Reflection */}
          <path
            d="M 88 100 C 95 85, 115 80, 140 80 C 165 80, 185 85, 192 100 C 180 94, 155 90, 140 90 C 125 90, 100 94, 88 100 Z"
            fill="url(#visorGloss)"
          />

          {/* 5. VISOR DIGITAL EYES & MOUTH (Dynamic Emotion States) */}
          {emotion === 'thinking' ? (
            <g filter="url(#cyanGlow)">
              {/* Curious looking-up thinking eyes */}
              <circle cx="112" cy="110" r="5" fill="#00F5D4" />
              <circle cx="122" cy="108" r="4" fill="#00F5D4" opacity="0.7" />
              <circle cx="158" cy="108" r="4" fill="#00F5D4" opacity="0.7" />
              <circle cx="168" cy="110" r="5" fill="#00F5D4" />
              {/* Pensive mouth line */}
              <line x1="126" y1="134" x2="154" y2="134" stroke="#00F5D4" strokeWidth="3.5" strokeLinecap="round" />
            </g>
          ) : emotion === 'victory' ? (
            <g filter="url(#cyanGlow)">
              {/* Star-eyes celebration */}
              <path d="M 116 106 L 119 114 L 127 114 L 121 119 L 123 126 L 116 122 L 109 126 L 111 119 L 105 114 L 113 114 Z" fill="#00F5D4" />
              <path d="M 164 106 L 167 114 L 175 114 L 169 119 L 171 126 L 164 122 L 157 126 L 159 119 L 153 114 L 161 114 Z" fill="#00F5D4" />
              {/* Joyful wide open smile */}
              <path d="M 124 130 Q 140 146 156 130 Z" fill="#00F5D4" />
            </g>
          ) : emotion === 'explaining' ? (
            <g filter="url(#cyanGlow)">
              {/* Animated speaking visor eyes */}
              <path d="M 104 116 Q 116 102 128 116" stroke="#00F5D4" strokeWidth="5" strokeLinecap="round" fill="none" />
              <path d="M 152 116 Q 164 102 176 116" stroke="#00F5D4" strokeWidth="5" strokeLinecap="round" fill="none" />
              {/* Speaking animated waveform mouth */}
              <path d="M 125 132 Q 132 126 140 132 Q 148 138 155 132" stroke="#00F5D4" strokeWidth="3.5" strokeLinecap="round" fill="none" />
            </g>
          ) : (
            <g filter="url(#cyanGlow)">
              {/* Friendly Happy Curved Eyes with Code brackets */}
              <path
                d="M 104 118 Q 116 98 128 118"
                stroke="#00F5D4"
                strokeWidth="5.5"
                strokeLinecap="round"
                fill="none"
              />
              <text x="96" y="130" fill="#00F5D4" fontSize="8" fontFamily="monospace" fontWeight="bold">{'<>'}</text>

              <path
                d="M 152 118 Q 164 98 176 118"
                stroke="#00F5D4"
                strokeWidth="5.5"
                strokeLinecap="round"
                fill="none"
              />
              <text x="178" y="130" fill="#00F5D4" fontSize="8" fontFamily="monospace" fontWeight="bold">{'^>'}</text>

              {/* Cute digital smile */}
              <path
                d="M 132 131 Q 140 140 148 131"
                stroke="#00F5D4"
                strokeWidth="4"
                strokeLinecap="round"
                fill="none"
              />
            </g>
          )}

          {/* 6. HOLOGRAPHIC CODING TABLET & HANDS */}
          {showHoloTablet && (
            <g>
              <polygon
                points="148,155 232,158 214,215 130,210"
                fill="url(#holoGrad)"
                stroke="#00F5D4"
                strokeWidth="2.5"
                filter="url(#softGlow)"
              />

              <text
                x="178"
                y="185"
                fill="#ffffff"
                fontSize="20"
                fontFamily="'JetBrains Mono', monospace"
                fontWeight="900"
                textAnchor="middle"
                filter="url(#cyanGlow)"
              >
                {'</>'}
              </text>

              <text x="156" y="200" fill="#00F5D4" fontSize="8" fontFamily="monospace" fontWeight="bold" opacity="0.85">
                10 01 1
              </text>
              <text x="186" y="202" fill="#00F5D4" fontSize="8" fontFamily="monospace" fontWeight="bold" opacity="0.85">
                {'{ } /'}
              </text>

              {/* Hands */}
              <circle cx="132" cy="180" r="14" fill="url(#bodyGrad)" stroke="#047857" strokeWidth="2" />
              <circle cx="134" cy="178" r="6" fill="#A7F3D0" opacity="0.5" />

              <circle cx="218" cy="186" r="14" fill="url(#bodyGrad)" stroke="#047857" strokeWidth="2" />
              <circle cx="216" cy="184" r="6" fill="#A7F3D0" opacity="0.5" />
            </g>
          )}
        </svg>
      </motion.div>
    </motion.div>
  );
}
