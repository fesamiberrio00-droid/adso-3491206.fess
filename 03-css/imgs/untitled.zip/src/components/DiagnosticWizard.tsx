import React, { useState } from 'react';
import SenaHelper from './SenaHelper';

interface DiagnosticWizardProps {
  onComplete: (answers: string[]) => void;
  loading: boolean;
}

const PREGUNTAS_DIAGNOSTICO = [
  {
    id: 'd1',
    texto: '¿Qué área del desarrollo o tecnología te entusiasma más profundizar?',
    opciones: [
      { id: 'A', text: 'Lógica algorítmica fundamental y razonamiento computacional.' },
      { id: 'B', text: 'Bases de datos, optimización relacional y procedimientos SQL.' },
      { id: 'C', text: 'Desarrollo moderno con Python, APIs e Inteligencia Artificial.' },
      { id: 'D', text: 'Estrategia integral: ¡Quiero dominar todo el ciclo de software!' }
    ],
    senaAdvice: '¡Te damos la bienvenida a Nodo! Soy tu tutor interactivo. Cuéntame tus intereses para trazar tu ruta de aprendizaje ideal.'
  },
  {
    id: 'd2',
    texto: '¿Cuál es tu nivel actual o experiencia previa en programación?',
    opciones: [
      { id: 'A', text: 'Inicial: Empiezo hoy con motivación desde cero.' },
      { id: 'B', text: 'Básico: Conozco variables, condicionales e instrucciones simples.' },
      { id: 'C', text: 'Intermedio: He construido scripts o resuelto retos de lógica.' },
      { id: 'D', text: 'Avanzado: Cuento con preparación o experiencia desarrollando.' }
    ],
    senaAdvice: '¡Cada usuario tiene su propio ritmo! En Nodo adaptamos los retos interactivos para principiantes y programadores avanzados.'
  },
  {
    id: 'd3',
    texto: '¿Cuál es tu método preferido para aprender a programar?',
    opciones: [
      { id: 'A', text: 'Conceptos claros seguidos de retos prácticos inmediatos paso a paso.' },
      { id: 'B', text: 'Escribir código en playground interactivo con validación de pruebas en vivo.' },
      { id: 'C', text: 'Casos prácticos y arquitecturas aplicadas al mundo real.' },
      { id: 'D', text: 'Desafíos de agilidad, gamificación con racha y preguntas de opción múltiple.' }
    ],
    senaAdvice: 'Nuestros playgrounds evalúan tu código en tiempo real con casos unitarios para asegurar una comprensión sólida.'
  },
  {
    id: 'd4',
    texto: '¿De cuánto tiempo dispones semanalmente para tu formación?',
    opciones: [
      { id: 'A', text: '1 a 2 horas semanales a ritmo gradual.' },
      { id: 'B', text: '3 a 5 horas a la semana (ritmo constante con racha diaria).' },
      { id: 'C', text: '6 a 10 horas semanales para avanzar con determinación.' },
      { id: 'D', text: 'Más de 10 horas semanales: ¡Inmersión intensiva total!' }
    ],
    senaAdvice: 'Configuraré tus metas semanales para que mantengas tu racha 🔥 activa de forma consistente.'
  }
];

export default function DiagnosticWizard({ onComplete, loading }: DiagnosticWizardProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [answers, setAnswers] = useState<string[]>([]);

  const handleSelectOption = (optionId: string) => {
    const updated = [...answers];
    updated[currentStep] = optionId;
    setAnswers(updated);
  };

  const handleNext = () => {
    if (currentStep < PREGUNTAS_DIAGNOSTICO.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      onComplete(answers);
    }
  };

  const handlePrev = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const activeQuestion = PREGUNTAS_DIAGNOSTICO[currentStep];
  const selectedOption = answers[currentStep];

  return (
    <div className="max-w-2xl mx-auto bg-white dark:bg-[#0F172A] border-2 border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-8 shadow-sm transition-colors">
      {/* Progress Bar with Nodo official colors */}
      <div className="mb-6">
        <div className="flex justify-between items-center text-xs font-black tracking-wider text-[#00324D] dark:text-slate-200 mb-2">
          <span className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-[#39a900]" />
            TEST 1 DE 2: DIAGNÓSTICO DE NIVEL Y OBJETIVOS
          </span>
          <span className="text-[#007832] dark:text-[#2EE59D]">PREGUNTA {currentStep + 1} DE {PREGUNTAS_DIAGNOSTICO.length}</span>
        </div>
        <div className="w-full bg-slate-100 dark:bg-slate-800 rounded-full h-3 overflow-hidden border border-slate-200 dark:border-slate-700">
          <div 
            className="bg-[#39a900] h-3 rounded-full transition-all duration-300" 
            style={{ width: `${((currentStep + 1) / PREGUNTAS_DIAGNOSTICO.length) * 100}%` }}
          />
        </div>
      </div>

      {/* Nodo Instruction Bubble */}
      <SenaHelper mood={currentStep === 0 ? 'neutral' : 'happy'} text={activeQuestion.senaAdvice} />

      {/* Current Question */}
      <div className="my-6">
        <h2 className="text-xl sm:text-2xl font-black text-[#00324D] dark:text-white leading-snug">
          {activeQuestion.texto}
        </h2>
      </div>

      {/* Options List */}
      <div className="space-y-3">
        {activeQuestion.opciones.map((opt) => {
          const isSelected = selectedOption === opt.id;
          return (
            <button
              key={opt.id}
              onClick={() => handleSelectOption(opt.id)}
              className={`w-full text-left p-4 rounded-2xl border-2 transition-all flex items-center gap-4 cursor-pointer ${
                isSelected
                  ? 'border-[#39a900] bg-[#39a900]/15 dark:bg-[#39a900]/25 text-[#00324D] dark:text-white shadow-xs'
                  : 'border-slate-200 dark:border-slate-700 hover:border-[#39a900]/50 dark:hover:border-emerald-500/50 hover:bg-slate-50/80 dark:hover:bg-slate-800/60 bg-white dark:bg-[#131F2E] text-slate-700 dark:text-slate-200'
              }`}
            >
              <div className={`w-10 h-10 shrink-0 font-black text-sm rounded-xl flex items-center justify-center transition-all ${
                isSelected 
                  ? 'bg-[#39a900] text-white shadow-xs' 
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400'
              }`}>
                {opt.id}
              </div>
              <span className="font-bold text-sm sm:text-base leading-snug text-[#00324D] dark:text-slate-100">{opt.text}</span>
            </button>
          );
        })}
      </div>

      {/* Navigation Footer */}
      <div className="mt-8 pt-4 border-t border-slate-200 dark:border-slate-800 flex justify-between items-center">
        <button
          onClick={handlePrev}
          disabled={currentStep === 0 || loading}
          className="px-5 py-2.5 text-sm font-bold text-slate-500 dark:text-slate-400 hover:text-[#00324D] dark:hover:text-white disabled:opacity-30 disabled:pointer-events-none transition cursor-pointer"
        >
          Atrás
        </button>

        <button
          onClick={handleNext}
          disabled={!selectedOption || loading}
          className="px-7 py-3 rounded-2xl text-sm font-black bg-[#39a900] hover:bg-[#329600] border-b-4 border-[#007832] text-white flex items-center gap-2 shadow-xs transition active:translate-y-0.5 active:border-b-2 disabled:opacity-40 disabled:pointer-events-none cursor-pointer"
        >
          {loading ? (
            <span className="flex items-center gap-2">
              <svg className="animate-spin h-4 w-4 text-white" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
              </svg>
              Analizando Perfil...
            </span>
          ) : currentStep === PREGUNTAS_DIAGNOSTICO.length - 1 ? (
            'Guardar Nivel y Continuar al Test de Aprendizaje →'
          ) : (
            'Siguiente'
          )}
        </button>
      </div>
    </div>
  );
}
