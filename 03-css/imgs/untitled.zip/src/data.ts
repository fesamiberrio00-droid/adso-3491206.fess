import { Module } from './types';
import { STATIC_ROADMAPS } from './data/roadmapsData';

export const STATIC_MODULES: Module[] = [
  {
    id: 'logica',
    title: 'Lógica de Programación',
    description: 'Aprende los cimientos del pensamiento computacional, variables y condicionales interactivos.',
    emoji: '🧠',
    colorClass: 'text-[#007832] bg-[#39a900]/10 border-[#39a900]/30',
    darkColorClass: 'text-[#39a900] bg-[#00324d] border-[#39a900]',
    gradientClass: 'from-[#39a900] to-[#007832]',
    themeMascot: STATIC_ROADMAPS['logica']?.themeMascot,
    roadmap: STATIC_ROADMAPS['logica']?.roadmap,
    questions: [
      {
        id: 'log1',
        type: 'multiple_choice',
        difficulty: 'basico',
        title: 'Pensamiento Algorítmico',
        description: '¿Cuál de las siguientes es la definición más exacta de un "Algoritmo"?',
        options: [
          { id: 'A', text: 'Un microchip de alta velocidad diseñado por ingenieros de Google.' },
          { id: 'B', text: 'Una secuencia paso a paso, finita y bien definida de instrucciones para resolver un problema.' },
          { id: 'C', text: 'La interfaz gráfica de usuario en aplicaciones móviles avanzadas.' },
          { id: 'D', text: 'Un error inesperado que ocurre durante la ejecución de un programa informático.' }
        ],
        correctOptionId: 'B',
        explanation: 'Un algoritmo es simplemente una receta de cocina intelectual: un conjunto ordenado de operaciones para lograr un fin.'
      },
      {
        id: 'log2',
        type: 'multiple_choice',
        difficulty: 'basico',
        title: 'Evaluación lógica',
        description: 'Si declaramos que la variable "temperatura = 15" y "estaLloviendo = true". ¿Qué evalúa el siguiente condicional?\n\n(temperatura < 20 && !estaLloviendo)',
        options: [
          { id: 'A', text: 'Evalúa a true (verdadero)' },
          { id: 'B', text: 'Evalúa a false (falso)' },
          { id: 'C', text: 'Produce un error syntax compilador' },
          { id: 'D', text: 'Evalúa a null' }
        ],
        correctOptionId: 'B',
        explanation: 'Como estaLloviendo es true, !estaLloviendo es false. En un operador condicional AND (&&), si uno de los lados es falso, todo el resultado es falso.'
      },
      {
        id: 'log3',
        type: 'multiple_choice',
        difficulty: 'intermedio',
        title: 'Operador del residuo (Módulo)',
        description: 'En programación, usamos el operador % (módulo) para obtener el residuo de una división. ¿Cuál de las siguientes expresiones siempre evalúa si un número "n" es IMPAR?',
        options: [
          { id: 'A', text: 'n % 2 === 0' },
          { id: 'B', text: 'n % 2 === 1' },
          { id: 'C', text: 'n / 2 === 1' },
          { id: 'D', text: 'n % 3 === 0' }
        ],
        correctOptionId: 'B',
        explanation: 'Cualquier número impar dividido por 2 tiene un residuo de 1, por lo que n % 2 === 1 valida la disparidad numérica.'
      },
      {
        id: 'log4',
        type: 'coding',
        difficulty: 'intermedio',
        title: 'Ejercicios de código en tiempo real: ¿Es de noche?',
        description: 'Nodo necesita tu ayuda en el centro de control. Completa la función `esHoraDeDormir` que recibe una hora (número del 0 al 23) y retorna `true` si la hora es desde las 22 (inclusive) hasta las 5 (inclusive) para simular horas de sueño, y `false` en cualquier otro caso.',
        initialCode: `function esHoraDeDormir(hora) {
  // Tu código aquí
  
}`,
        solutionCode: `function esHoraDeDormir(hora) {
  return hora >= 22 || hora <= 5;
}`,
        testCases: [
          { id: 'tc1_1', input: '23', codeCheck: 'esHoraDeDormir(23)', expectedOutput: 'true' },
          { id: 'tc1_2', input: '14', codeCheck: 'esHoraDeDormir(14)', expectedOutput: 'false' },
          { id: 'tc1_3', input: '4', codeCheck: 'esHoraDeDormir(4)', expectedOutput: 'true' }
        ],
        explanation: 'En condicionales usamos operados OR (||). Evaluamos si la hora es superior o igual a 22, o inferior o igual a 5.'
      },
      {
        id: 'log5',
        type: 'coding',
        difficulty: 'avanzado',
        title: 'Reto Avanzado: Sumador de Impares',
        description: 'Codifica una función en tiempo real llamada `sumarImparesRecurrente(limite)` que sume todos los números enteros impares comprendidos entre 1 y el "limite" (inclusive). Por ejemplo, si el límite es 5, debe sumar 1 + 3 + 5 = 9.',
        initialCode: `function sumarImparesRecurrente(limite) {
  // Escribe tu algoritmo interactivo aquí
  
}`,
        solutionCode: `function sumarImparesRecurrente(limite) {
  let suma = 0;
  for (let i = 1; i <= limite; i++) {
    if (i % 2 !== 0) {
      suma += i;
    }
  }
  return suma;
}`,
        testCases: [
          { id: 'tc2_1', input: '5', codeCheck: 'sumarImparesRecurrente(5)', expectedOutput: '9' },
          { id: 'tc2_2', input: '10', codeCheck: 'sumarImparesRecurrente(10)', expectedOutput: '25' },
          { id: 'tc2_3', input: '1', codeCheck: 'sumarImparesRecurrente(1)', expectedOutput: '1' }
        ],
        explanation: 'Un ciclo for de 1 a limite examinando i % 2 !== 0 nos permite acumular únicamente impares de manera efectiva.'
      }
    ]
  },
  {
    id: 'algoritmos',
    title: 'Algoritmos y Estructura de Datos',
    description: 'Explora flujos de ordenamiento, complejidad Big O y estructuras en memoria fundamentales.',
    emoji: '📊',
    colorClass: 'text-[#00324d] bg-[#00324d]/10 border-[#00324d]/30',
    darkColorClass: 'text-white bg-[#00324d] border-[#007832]',
    gradientClass: 'from-[#00324d] to-[#007832]',
    themeMascot: STATIC_ROADMAPS['algoritmos']?.themeMascot,
    roadmap: STATIC_ROADMAPS['algoritmos']?.roadmap,
    questions: [
      {
        id: 'alg1',
        type: 'multiple_choice',
        difficulty: 'basico',
        title: 'Estantería de pilas',
        description: '¿Qué principio de extracción rige el comportamiento de una estructura tipo LIFO (Pila)?',
        options: [
          { id: 'A', text: 'First In, First Out (El primero que ingresa es el primero en ser atendido).' },
          { id: 'B', text: 'Last In, First Out (El último que ingresa es el primero en salir, como una montaña de platos).' },
          { id: 'C', text: 'Random Access Memory (Se puede leer cualquier elemento aleatoriamente sin pila).' },
          { id: 'D', text: 'Ninguna de las anteriores.' }
        ],
        correctOptionId: 'B',
        explanation: 'Las Pilas (Stacks) operan bajo el comportamiento LIFO. Piensa en una pila de platos: siempre retiras el último que colocaste arriba.'
      },
      {
        id: 'alg2',
        type: 'multiple_choice',
        difficulty: 'basico',
        title: 'Eficiencia de código',
        description: '¿Qué notación se utiliza universalmente para calcular la complejidad de tiempo en el peor de los casos de un algoritmo?',
        options: [
          { id: 'A', text: 'Notación Little Omega (ω)' },
          { id: 'B', text: 'Notación Big O (O de n)' },
          { id: 'C', text: 'Notación Binaria Directa' },
          { id: 'D', text: 'Análisis de reloj de CPU' }
        ],
        correctOptionId: 'B',
        explanation: 'La notación Big O describe el límite superior del tiempo o del espacio de ejecución en función del tamaño de la entrada.'
      },
      {
        id: 'alg3',
        type: 'multiple_choice',
        difficulty: 'intermedio',
        title: 'Complejidad de Búsqueda Binaria',
        description: 'Para un arreglo ordenado de tamaño N, ¿cuál es la complejidad temporal de la Búsqueda Binaria?',
        options: [
          { id: 'A', text: 'O(N)' },
          { id: 'B', text: 'O(1)' },
          { id: 'C', text: 'O(log N)' },
          { id: 'D', text: 'O(N²)' }
        ],
        correctOptionId: 'C',
        explanation: 'La búsqueda binaria reduce a la mitad el rango de búsqueda en cada paso, lo que genera una eficiencia logarítmica O(log N).'
      },
      {
        id: 'alg4',
        type: 'coding',
        difficulty: 'intermedio',
        title: 'Ejercicios de código en tiempo real: Buscador de Índices',
        description: 'Escribe una función llamada `buscarElemento(arr, target)` que implemente una búsqueda lineal y devuelva el primer índice donde se encuentra `target` en el arreglo `arr`. Si no se encuentra, retorna -1.',
        initialCode: `function buscarElemento(arr, target) {
  // Tu código alternativo aquí
  
}`,
        solutionCode: `function buscarElemento(arr, target) {
  return arr.indexOf(target);
}`,
        testCases: [
          { id: 'tc3_1', input: '([10, 20, 30], 20)', codeCheck: 'buscarElemento([10, 20, 30], 20)', expectedOutput: '1' },
          { id: 'tc3_2', input: '([5, 8, 12], 9)', codeCheck: 'buscarElemento([5, 8, 12], 9)', expectedOutput: '-1' },
          { id: 'tc3_3', input: '(["python", "js"], "js")', codeCheck: 'buscarElemento(["python", "js"], "js")', expectedOutput: '1' }
        ],
        explanation: 'Al buscar secuencialmente, si encontramos el elemento regresamos la posición actual i; de lo contrario persistimos y retornamos -1.'
      },
      {
        id: 'alg5',
        type: 'coding',
        difficulty: 'avanzado',
        title: 'Reto Avanzado: Filtro de Únicos',
        description: 'Crea un algoritmo en tiempo real `filtrarRepetidos(arr)` que devuelva un nuevo arreglo conteniendo únicamente los elementos que aparecen exactamente una vez en la colección de entrada. El orden debe preservarse.',
        initialCode: `function filtrarRepetidos(arr) {
  // Escribe tu solución optimizada aquí
  
}`,
        solutionCode: `function filtrarRepetidos(arr) {
  return arr.filter(el => arr.indexOf(el) === arr.lastIndexOf(el));
}`,
        testCases: [
          { id: 'tc4_1', input: '[1, 2, 2, 3, 4, 4]', codeCheck: 'JSON.stringify(filtrarRepetidos([1, 2, 2, 3, 4, 4]))', expectedOutput: '[1,3]' },
          { id: 'tc4_2', input: '["a", "b", "a"]', codeCheck: 'JSON.stringify(filtrarRepetidos(["a", "b", "a"]))', expectedOutput: '["b"]' }
        ],
        explanation: 'Comprobamos si el indexOf y lastIndexOf coinciden para cada elemento; si coinciden, significa que existe una sola ocurrencia de éste.'
      }
    ]
  },
  {
    id: 'python',
    title: 'Python Avanzado & Scripting',
    description: 'Aprende metaprogramación, funciones de alto orden, decoradores conceptuales y asincronía.',
    emoji: '🐍',
    colorClass: 'text-[#38BDF8] bg-[#38BDF8]/10 border-[#38BDF8]/30',
    darkColorClass: 'text-white bg-[#0284c7] border-[#38BDF8]',
    gradientClass: 'from-[#0284c7] to-[#38BDF8]',
    themeMascot: STATIC_ROADMAPS['python']?.themeMascot,
    roadmap: STATIC_ROADMAPS['python']?.roadmap,
    questions: [
      {
        id: 'py1',
        type: 'multiple_choice',
        difficulty: 'basico',
        title: 'Decoradores Conceptuales',
        description: '¿Qué describe mejor un "Decorador" en Python o JS moderno?',
        options: [
          { id: 'A', text: 'Un archivo de estilo CSS que decora las etiquetas HTML del sitio.' },
          { id: 'B', text: 'Una función que toma otra función como argumento y extiende su comportamiento de manera transparente.' },
          { id: 'C', text: 'Un corrector automático de errores ortográficos en el compilador de Python.' },
          { id: 'D', text: 'Un editor de código interactivo que añade colores inteligentes.' }
        ],
        correctOptionId: 'B',
        explanation: 'Los decoradores modifican o auditan el comportamiento de funciones o clases envolviéndolas gracias a que las funciones son ciudadanos de primer nivel.'
      },
      {
        id: 'py2',
        type: 'multiple_choice',
        difficulty: 'basico',
        title: 'Generadores y Expresiones Yield',
        description: '¿Cuál es la ventaja primordial de utilizar un Generador con "yield" en lugar de retornar una lista común?',
        options: [
          { id: 'A', text: 'Produce un código que se ejecuta más de 100 veces más rápido en cualquier CPU.' },
          { id: 'B', text: 'Reduce enormemente el consumo de memoria al pausarse y devolver elementos uno a uno bajo demanda.' },
          { id: 'C', text: 'No permite valores duplicados en su secuencia.' },
          { id: 'D', text: 'Permite compartir variables globales de forma automática.' }
        ],
        correctOptionId: 'B',
        explanation: 'Los generadores calculan perezosamente ("lazy evaluation") un elemento por turno, ahorrando gigabytes de memoria en conjuntos de datos infinitos.'
      },
      {
        id: 'py3',
        type: 'multiple_choice',
        difficulty: 'intermedio',
        title: 'Asincronía y Promesas',
        description: '¿Qué valor entrega una función asíncrona declarada con `async` cuando es ejecutada?',
        options: [
          { id: 'A', text: 'Un hilo de ejecución nativo del sistema operativo.' },
          { id: 'B', text: 'Una Promesa (Promise) que se resolverá en el futuro con el valor de retorno real.' },
          { id: 'C', text: 'Un callback síncrono bloqueante.' },
          { id: 'D', text: 'Devuelve undefinido de inmediato sin posibilidad de captura.' }
        ],
        correctOptionId: 'B',
        explanation: 'Las funciones `async` devuelven implícitamente una Promesa, permitiendo flujos no bloqueantes de entrada/salida.'
      },
      {
        id: 'py4',
        type: 'coding',
        difficulty: 'intermedio',
        title: 'Ejercicios de código en tiempo real: Formateador en JSON',
        description: 'Crea una función llamada `formatearResultado(exito, datos)` que devuelva una cadena JSON (un string) con el formato `{ "status": "success" | "error", "payload": datos }`. Si exito es `true`, status es "success", si es `false`, es "error".',
        initialCode: `function formatearResultado(exito, datos) {
  // Escribe tu respuesta interactiva aquí
  
}`,
        solutionCode: `function formatearResultado(exito, datos) {
  return JSON.stringify({
    status: exito ? "success" : "error",
    payload: datos
  });
}`,
        testCases: [
          { id: 'tc5_1', input: '(true, "Token válido")', codeCheck: 'formatearResultado(true, "Token válido")', expectedOutput: '{"status":"success","payload":"Token válido"}' },
          { id: 'tc5_2', input: '(false, "Error 404")', codeCheck: 'formatearResultado(false, "Error 404")', expectedOutput: '{"status":"error","payload":"Error 404"}' }
        ],
        explanation: 'Utilizamos JSON.stringify para transformar un objeto literal de JS en una cadena compatible de manera directa.'
      },
      {
        id: 'py5',
        type: 'coding',
        difficulty: 'avanzado',
        title: 'Reto Avanzado: Filtro de Edad de Estudiantes',
        description: 'Escribe una función de orden superior `filtrarYCalcularPromedio(estudiantes, edadMinima)` que reciba un arreglo de objetos estudiante e.g. `[{ nombre: "Juan", edad: 20 }, ...]` y filtre por edad superior o igual a `edadMinima`. Luego, calcula el promedio decimal de edad de los estudiantes filtrados. Si no queda ninguno, retorna 0.',
        initialCode: `function filtrarYCalcularPromedio(estudiantes, edadMinima) {
  // Tu magia asíncrona/lógica en tiempo real aquí
  
}`,
        solutionCode: `function filtrarYCalcularPromedio(estudiantes, edadMinima) {
  const filtrados = estudiantes.filter(e => e.edad >= edadMinima);
  if (filtrados.length === 0) return 0;
  const suma = filtrados.reduce((acc, e) => acc + e.edad, 0);
  return Number((suma / filtrados.length).toFixed(1));
}`,
        testCases: [
          { id: 'tc6_1', input: '([{edad: 21}, {edad: 19}], 20)', codeCheck: 'filtrarYCalcularPromedio([{edad: 21}, {edad: 19}], 20)', expectedOutput: '21' },
          { id: 'tc6_2', input: '([{edad: 30}, {edad: 32}, {edad: 15}], 25)', codeCheck: 'filtrarYCalcularPromedio([{edad: 30}, {edad: 32}, {edad: 15}], 25)', expectedOutput: '31' }
        ],
        explanation: 'Filtramos con filter, reducimos con reduce y calculamos la media, controlando que la división por cero retorne cero de manera robusta.'
      }
    ]
  },
  {
    id: 'basesdatos',
    title: 'Bases de Datos & SQL Avanzado',
    description: 'Aprende consultas relacionales, lógica de procedimientos almacenados, transacciones y escritura masiva en bases relacionales.',
    emoji: '🗄️',
    colorClass: 'text-[#00324d] bg-[#fdc300]/15 border-[#fdc300]/40',
    darkColorClass: 'text-[#00324d] bg-[#fdc300] border-[#00324d]',
    gradientClass: 'from-[#fdc300] to-[#d9a500]',
    themeMascot: STATIC_ROADMAPS['basesdatos']?.themeMascot,
    roadmap: STATIC_ROADMAPS['basesdatos']?.roadmap,
    questions: [
      {
        id: 'db1',
        type: 'multiple_choice',
        difficulty: 'basico',
        title: 'Consultas Relacionales con INNER JOIN',
        description: 'Deseas listar todos los campos de ventas junto con los nombres de los productos relacionados. ¿Qué consulta SQL cruza ambas tablas basándose en la clave foránea "id_producto"?',
        options: [
          { id: 'A', text: 'SELECT * FROM detalle_ventas CROSS JOIN productos' },
          { id: 'B', text: 'SELECT * FROM detalle_ventas INNER JOIN productos ON detalle_ventas.id_producto = productos.id' },
          { id: 'C', text: 'SELECT * FROM detalle_ventas UNION SELECT * FROM productos' },
          { id: 'D', text: 'MERGE TABLE detalle_ventas AND productos' }
        ],
        correctOptionId: 'B',
        explanation: 'INNER JOIN combina registros de dos o más tablas en una consulta relacional cuando hay coincidencia en la condición designada tras la cláusula ON.'
      },
      {
        id: 'db2',
        type: 'multiple_choice',
        difficulty: 'intermedio',
        title: 'Compilación de Procedimientos Almacenados',
        description: 'En MariaDB, antes de declarar un procedimiento almacenado (como "insertar_detalles_masivos") que internamente contiene múltiples instrucciones terminadas en ";", ¿con qué comando se altera temporalmente el terminador de sentencias para compilarlo todo como un único bloque?',
        options: [
          { id: 'A', text: 'DELIMITER $$ (o DELIMITER //)' },
          { id: 'B', text: 'START TRANSACTION;' },
          { id: 'C', text: 'BEGIN BATCH ON;' },
          { id: 'D', text: 'SET TIMEOUT_SEMICOLON = FALSE;' }
        ],
        correctOptionId: 'A',
        explanation: 'Cambiar el "DELIMITER" le indica al cliente de base de datos que ignore los ";" internos del procedimiento y no intente mandar a ejecutar el código a mitad de la declaración.'
      },
      {
        id: 'db3',
        type: 'multiple_choice',
        difficulty: 'intermedio',
        title: 'Optimización de Escritura en Disco (COMMIT)',
        description: 'En el procedimiento almacenado analizado, un bloque de control condicional "IF i % 1000 = 0 THEN COMMIT; END IF;" reparte la confirmación. ¿Cuál es el beneficio de agrupar los COMMITs en lotes?',
        options: [
          { id: 'A', text: 'Evita errores de sintaxis en bucles WHILE.' },
          { id: 'B', text: 'Acelera notablemente la ejecución al disminuir las operaciones de sincronización física a disco (fsync) de forma repetitiva.' },
          { id: 'C', text: 'Permite que MariaDB autoincremente los IDs de forma inversa.' },
          { id: 'D', text: 'Cambia los tipos de campos flotantes a decimales de forma transparente.' }
        ],
        correctOptionId: 'B',
        explanation: 'Inscribir transacciones de 1000 en 1000 registros de manera transaccional reduce la latencia i/o de disco brutalmente en comparación con hacer COMMIT en cada iteración individual.'
      },
      {
        id: 'db4',
        type: 'coding',
        difficulty: 'intermedio',
        title: 'Cálculo de Subtotal con Descuento Proporcional',
        description: 'La fórmula matemática de tu procedimiento es:\n`subtotal = (precio * cantidad) * (1 - descuento/100)`\n\nCodifica una función JavaScript llamada `calcularSubtotal(precio, cantidad, descuento)` que emule este cálculo de MariaDB y retorne el valor formateado con exactamente 2 decimales fijos (retorna un número flotante, usando por ejemplo: `Number(resultado.toFixed(2))`).',
        initialCode: `function calcularSubtotal(precio, cantidad, descuento) {
  // Tu cálculo matemático aquí
  
}`,
        solutionCode: `function calcularSubtotal(precio, cantidad, descuento) {
  const tot = (precio * cantidad) * (1 - (descuento / 100));
  return Number(tot.toFixed(2));
}`,
        testCases: [
          { id: 'tcdb1_1', input: '(20.50, 5, 10)', codeCheck: 'calcularSubtotal(20.50, 5, 10)', expectedOutput: '92.25' },
          { id: 'tcdb1_2', input: '(150.00, 2, 0)', codeCheck: 'calcularSubtotal(150.00, 2, 0)', expectedOutput: '300' },
          { id: 'tcdb1_3', input: '(10.00, 10, 50)', codeCheck: 'calcularSubtotal(10.00, 10, 50)', expectedOutput: '50' }
        ],
        explanation: 'Multiplicamos el valor base (precio * cantidad) y luego aplicamos el descuento relativo. .toFixed(2) asegura que el redondeo decimal sea idéntico al tipo DECIMAL(10,2) de SQL.'
      },
      {
        id: 'db5',
        type: 'coding',
        difficulty: 'avanzado',
        title: 'Generación Dinámica de Items Aleatorios',
        description: 'Codifica una función interactiva llamada `generarItemVenta(i, iteracionActual)` que devuelva un objeto con la estructura de un detalle de venta. Debe cumplir:\n- id_venta: debe ser igual al parámetro `i`.\n- id_producto: un entero aleatorio correspondiente a la iteración multiplicada por 5: `iteracionActual * 5`.\n- cantidad: un número aleatorio entero de 1 a 10 inclusive, generado usando una semilla.\n- precio_unitario: un valor constante de `59.90`.\n- descuento: si `i % 2 === 0` entonces el descuento es `15`, de lo contrario es `0`.\n- subtotal: debe llamar a la fórmula matemática de subtotal aplicando el descuento respectivo (redondeado a 2 decimales).',
        initialCode: `function generarItemVenta(i, iteracionActual) {
  // Escribe la lógica para generar el registro simulado
  
}`,
        solutionCode: `function generarItemVenta(i, iteracionActual) {
  const id_venta = i;
  const id_producto = iteracionActual * 5;
  const cantidad = 5; // Semilla simplificada para pruebas unitarias
  const precio_unitario = 59.90;
  const descuento = i % 2 === 0 ? 15 : 0;
  const subtotal = Number(((precio_unitario * cantidad) * (1 - (descuento / 100))).toFixed(2));
  return { id_venta, id_producto, cantidad, precio_unitario, descuento, subtotal };
}`,
        testCases: [
          { id: 'tcdb2_1', input: '(10, 3)', codeCheck: 'JSON.stringify(generarItemVenta(10, 3))', expectedOutput: '{"id_venta":10,"id_producto":15,"cantidad":5,"precio_unitario":59.9,"descuento":15,"subtotal":254.58}' },
          { id: 'tcdb2_2', input: '(11, 4)', codeCheck: 'JSON.stringify(generarItemVenta(11, 4))', expectedOutput: '{"id_venta":11,"id_producto":20,"cantidad":5,"precio_unitario":59.9,"descuento":0,"subtotal":299.5}' }
        ],
        explanation: 'Determinamos el descuento basándonos en la paridad de id_venta y multiplicamos por precio_unitario redondeado de manera robusta para emular un procesador procedural.'
      }
    ]
  },
  {
    id: 'javascript',
    title: 'JavaScript Moderno & Web',
    description: 'Explora el motor V8, Event Loop, Promesas, asincronía y reactores interactivos del DOM.',
    emoji: '⚡',
    colorClass: 'text-[#F59E0B] bg-[#F59E0B]/10 border-[#F59E0B]/30',
    darkColorClass: 'text-white bg-[#D97706] border-[#F59E0B]',
    gradientClass: 'from-[#D97706] to-[#F59E0B]',
    themeMascot: STATIC_ROADMAPS['javascript']?.themeMascot,
    roadmap: STATIC_ROADMAPS['javascript']?.roadmap,
    questions: (STATIC_ROADMAPS['javascript']?.roadmap?.nodes.filter(n => n.question).map(n => n.question!) || [])
  }
];

