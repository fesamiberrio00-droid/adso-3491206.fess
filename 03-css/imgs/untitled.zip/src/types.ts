export interface Option {
  id: string;
  text: string;
}

export interface Question {
  id: string;
  type: 'multiple_choice' | 'coding' | 'parsons' | 'logic_analysis';
  difficulty: 'basico' | 'intermedio' | 'avanzado';
  title: string;
  description: string;
  options?: Option[]; // For multiple choice
  correctOptionId?: string; // For multiple choice
  initialCode?: string; // For coding exercise
  solutionCode?: string; // For reference
  testCases?: TestCase[]; // For coding exercise
  explanation: string;
  // Adaptive Learning Style properties:
  visualDiagram?: string; // Graphical ASCII/flow diagram for Visual learners
  codeFlowMap?: { step: number; title: string; desc: string; highlightCode?: string; color: string }[]; // Visual flow map
  semanticHighlights?: { token: string; label: string; color: string }[]; // Semantic color highlighting
  speechText?: string; // Spoken explanation ready for voice synthesizer
  audioTip?: string; // Verbalization / Rubber Duck tip for Auditory learners
  docSnippet?: string; // Technical specification reference for Read/Write learners
  logicPremise?: string; // Algorithmic deduction & Big-O note for Analytical learners
  logicAnalysis?: {
    bugLineNumber: number;
    bugExplanation: string;
    variableTrace: { step: number; line: string; vars: Record<string, string>; note: string }[];
  }; // Logic step-by-step trace & bug detector
  parsonsBlocks?: { id: string; text: string; indent?: number }[]; // Kinesthetic drag & reorder blocks
  parsonsSolutionOrder?: string[]; // Correct ordered block IDs
  correctOrder?: string[]; // Alias for ordered block IDs
  codeSnippet?: string;
  codeLines?: string[]; // Code split into individual numbered lines
  bugLine?: number;
  bugLineNumber?: number; // Alias for bug line
  bugExplanation?: string;
  variableTrace?: { step: number; line: string; vars: Record<string, string>; note: string }[]; // Step-by-step trace
  pairProgrammingPrompt?: string; // Team scenario for Collaborative learners
}

export interface TestCase {
  id: string;
  input: string; // Printable input representation
  codeCheck: string; // JS expression to test like: "esPar(4)"
  expectedOutput: any; // Expected matching JSON/String/Number/Boolean
}

export type ModuleModality = 'offline' | 'ia';

export interface ModuleProgress {
  moduleId: string;
  modality: ModuleModality;
  completed: boolean;
  score: number;
  level: 'Principiante' | 'Intermedio' | 'Avanzado';
  completedAt?: string;
}

export interface ModuleModalityProgress {
  offline?: ModuleProgress;
  ia?: ModuleProgress;
}

export type LearningStyleType = 'practico' | 'visual' | 'auditivo' | 'lectoescritor' | 'logico' | 'social';

export interface LearningStyleScore {
  type: LearningStyleType;
  name: string;
  shortName: string;
  icon: string;
  color: string;
  accentBg: string;
  accentBorder: string;
  accentText: string;
  score: number;
  percentage: number;
  tagline: string;
  description: string;
  studyTips: string[];
}

export interface LearningStyleResult {
  primaryStyle: LearningStyleScore;
  secondaryStyle: LearningStyleScore;
  isBimodal?: boolean;
  bimodalTitle?: string;
  bimodalDescription?: string;
  breakdown: LearningStyleScore[];
  completedAt: string;
  recommendations: string[];
}

export interface RoadmapNodeProgress {
  moduleId: string;
  nodeId: string;
  completed: boolean;
  score: number;
  stars: number;
  attempts: number;
  lastAttemptAt?: string;
}

export interface UserProfile {
  username: string;
  email: string;
  age: number;
  streakDays: number;
  streak?: number; // Alias for streakDays
  xpDays: { [dateSlug: string]: number }; // tracking daily XP
  lastCompletedDate?: string;
  totalXP: number;
  points?: number; // Alias for totalXP
  tokens?: number; // Balance of bits / currency
  level: number;
  title: string;
  interests: string[];
  recommendedPlan?: {
    overview: string;
    weeks: { title: string; target: string; focus: string }[];
  };
  learningStyleProfile?: LearningStyleResult;
  progress: { [moduleId: string]: ModuleModalityProgress };
  roadmapProgress?: { [nodeId: string]: RoadmapNodeProgress };
  claimedNodes?: { [nodeId: string]: boolean };
}

export interface ThemeMascot {
  name: string;
  avatar: string;
  themeColor: string;
  accentColor?: string;
  pathColor?: string;
  greeting?: string;
  dialogue?: string;
  speechAudio?: string;
  mascotPlacement?: 'left_side' | 'right_side';
  animationStates?: {
    idle: string;
    talking: string;
    celebrating: string;
  };
}

export type RoadmapNodeType = 'lesson' | 'checkpoint' | 'chest_reward' | 'boss_challenge' | 'chest' | 'boss';

export interface RoadmapNode {
  id: string;
  title: string;
  type?: 'lesson' | 'chest' | 'boss' | 'checkpoint';
  nodeType?: RoadmapNodeType;
  curveOffset: number; // -1, 0, 1 (or -2..2)
  isLocked: boolean;
  isCompleted?: boolean;
  stars?: number; // 0, 1, 2, 3
  rewardBits: number;
  rewardXP: number;
  question?: Question;
  isClaimed?: boolean;
  checkpointRequirement?: string;
}

export interface RoadmapSection {
  sectionTitle?: string;
  unitTitle?: string;
  nodes: RoadmapNode[];
}

export interface ModuleRoadmap {
  moduleId: string;
  moduleTitle: string;
  unitTitle?: string;
  themeMascot: ThemeMascot;
  roadmap?: RoadmapSection;
  levels?: RoadmapNode[];
}

export interface Module {
  id: string;
  title: string;
  description: string;
  emoji: string;
  colorClass: string;
  darkColorClass: string;
  gradientClass: string;
  questions: Question[];
  themeMascot?: ThemeMascot;
  roadmap?: RoadmapSection;
}

