import { LearningStyleType, LearningStyleScore } from '../types';

export interface LearningStyleQuestionOption {
  id: string;
  style: LearningStyleType;
  badge: string;
  icon: string;
  colorClass: string;
  title: string;
  description: string;
}

export interface LearningStyleQuestion {
  id: number;
  situation: string;
  icon: string;
  pregunta: string;
  senaAdvice: string;
  opciones: LearningStyleQuestionOption[];
}

export const LEARNING_STYLES_INFO: Record<LearningStyleType, Omit<LearningStyleScore, 'score' | 'percentage'>> = {
  practico: {
    type: 'practico',
    name: 'Práctico / Kinestésico',
    shortName: 'Práctico',
    icon: '⚡',
    color: '#39a900',
    accentBg: 'bg-[#39a900]/10',
    accentBorder: 'border-[#39a900]',
    accentText: 'text-[#007832]',
    tagline: 'Aprendizaje por acción directa ("Learning by Doing")',
    description: 'Retienes y comprendes los conceptos programando directamente. Tu cerebro consolida la lógica cuando tocas el código, pruebas errores en vivo y construyes proyectos tangibles.',
    studyTips: [
      'Aprovecha el playground de código en tiempo real de Nodo para escribir soluciones tú mismo.',
      'Cuando leas una regla sintáctica, ábrela de inmediato en el editor y cámbiale los parámetros.',
      'Aprende depurando: rompe el código a propósito para ver cómo responde la consola.'
    ]
  },
  visual: {
    type: 'visual',
    name: 'Visual / Espacial',
    shortName: 'Visual',
    icon: '🎨',
    color: '#00324d',
    accentBg: 'bg-[#00324d]/10',
    accentBorder: 'border-[#00324d]',
    accentText: 'text-[#00324d]',
    tagline: 'Comprensión mediante esquemas, mapas y diagramas',
    description: 'Procesas mejor la información cuando puedes ver la estructura espacial, mapas conceptuales, diagramas de flujo y código con resaltado sintáctico de alto contraste.',
    studyTips: [
      'Dibuja diagramas de flujo de datos antes de programar una función o bucle.',
      'Usa mapas mentales para conectar conceptos (variables → condiciones → funciones).',
      'Presta atención a las barras de progreso, estadísticas visuales y esquemas gráficos de Nodo.'
    ]
  },
  auditivo: {
    type: 'auditivo',
    name: 'Auditivo / Aural',
    shortName: 'Auditivo',
    icon: '🎧',
    color: '#71277a',
    accentBg: 'bg-[#71277a]/10',
    accentBorder: 'border-[#71277a]',
    accentText: 'text-[#71277a]',
    tagline: 'Asimilación a través de explicaciones verbales y ritmo sonoro',
    description: 'Aprendes escuchando la lógica explicada con palabras, debatiendo conceptos en voz alta y asociando sonidos o entonaciones a patrones de programación.',
    studyTips: [
      'Aplica la técnica del "Patito de Goma" (Rubber Duck): explica tu código en voz alta a un objeto o a ti mismo.',
      'Activa el sintetizador de voz de Nodo para escuchar las preguntas y explicaciones.',
      'Escucha podcasts y conferencias sobre programación mientras repasas conceptos.'
    ]
  },
  lectoescritor: {
    type: 'lectoescritor',
    name: 'Lectoescritura / Verbal',
    shortName: 'Lectoescritor',
    icon: '📚',
    color: '#fdc300',
    accentBg: 'bg-[#fdc300]/15',
    accentBorder: 'border-[#fdc300]',
    accentText: 'text-[#00324d]',
    tagline: 'Dominio mediante documentación, notas escritas y glosarios',
    description: 'Prefieres interactuar con texto escrito: manuales técnicos oficiales, guías detalladas, apuntes estructurados, resúmenes y redacción de pseudocódigo minucioso.',
    studyTips: [
      'Toma apuntes estructurados de cada módulo en un cuaderno o aplicación de notas.',
      'Escribe pseudocódigo detallado en comentarios antes de redactar el código real.',
      'Lee minuciosamente las explicaciones teóricas que Nodo ofrece al terminar cada reto.'
    ]
  },
  logico: {
    type: 'logico',
    name: 'Lógico / Analítico',
    shortName: 'Lógico-Analítico',
    icon: '🧩',
    color: '#0284c7',
    accentBg: 'bg-sky-50',
    accentBorder: 'border-sky-500',
    accentText: 'text-sky-700',
    tagline: 'Deducción formal, algoritmos y descomposición matemática',
    description: 'Aprendes mejor descomponiendo problemas en partes lógicas pequeñas, encontrando patrones matemáticos, analizando tablas de verdad y entendiendo la causa y efecto estricta.',
    studyTips: [
      'Descompón cada reto en premisas lógicas: ¿cuál es la entrada, la transformación y la salida?',
      'Analiza la complejidad algorítmica y los casos extremos (edge cases).',
      'Concéntrate en los retos de algoritmos y optimización de rendimiento de Nodo.'
    ]
  },
  social: {
    type: 'social',
    name: 'Social / Colaborativo',
    shortName: 'Colaborativo',
    icon: '👥',
    color: '#e11d48',
    accentBg: 'bg-rose-50',
    accentBorder: 'border-rose-500',
    accentText: 'text-rose-700',
    tagline: 'Aprendizaje en comunidad, trabajo en equipo e intercambio de ideas',
    description: 'Te motiva aprender con otros, discutir soluciones en conjunto, programar en parejas (pair programming), enseñar lo que aprendes y medir tu progreso en grupo.',
    studyTips: [
      'Compara tus puntuaciones y posición en la tabla de líderes de Nodo.',
      'Explica los ejercicios a compañeros o amigos principiantes para afianzar tu comprensión.',
      'Participa en retos grupales y comparte tus logros de racha con la comunidad.'
    ]
  }
};

export const LEARNING_STYLE_QUESTIONS: LearningStyleQuestion[] = [
  {
    id: 1,
    situation: 'Nuevo concepto de programación',
    icon: '💡',
    pregunta: 'Cuando te enfrentas a un concepto completamente nuevo (como un bucle for o recursión), ¿cuál es tu primera reacción para entenderlo?',
    senaAdvice: '¡Cada cerebro procesa la lógica a su manera! Cuéntame qué paso das primero.',
    opciones: [
      {
        id: '1_practico',
        style: 'practico',
        badge: '⚡ Práctico',
        icon: '💻',
        colorClass: 'border-[#39a900] bg-[#39a900]/10 text-[#007832]',
        title: 'Abrir el editor y experimentar',
        description: 'Escribo un bucle en el playground de inmediato y cambio los números para ver qué sucede en vivo.'
      },
      {
        id: '1_visual',
        style: 'visual',
        badge: '🎨 Visual',
        icon: '📊',
        colorClass: 'border-[#00324d] bg-[#00324d]/10 text-[#00324d]',
        title: 'Buscar un diagrama de flujo o animación',
        description: 'Necesito ver una ilustración gráfica de cómo entran los datos y se repiten los ciclos paso a paso.'
      },
      {
        id: '1_auditivo',
        style: 'auditivo',
        badge: '🎧 Auditivo',
        icon: '🎙️',
        colorClass: 'border-[#71277a] bg-[#71277a]/10 text-[#71277a]',
        title: 'Escuchar a alguien explicarlo con analogías',
        description: 'Prefiero que un tutor o audio me narre cómo funciona con una historia o ejemplo verbal cotidiano.'
      },
      {
        id: '1_lectoescritor',
        style: 'lectoescritor',
        badge: '📚 Lectoescritor',
        icon: '📖',
        colorClass: 'border-[#fdc300] bg-[#fdc300]/15 text-[#00324d]',
        title: 'Leer la documentación oficial detallada',
        description: 'Busco la especificación técnica escrita, leo la sintaxis exacta y anoto apuntes en mi cuaderno.'
      },
      {
        id: '1_logico',
        style: 'logico',
        badge: '🧩 Lógico',
        icon: '🔍',
        colorClass: 'border-sky-500 bg-sky-50 text-sky-800',
        title: 'Desglosar la regla matemática y condición',
        description: 'Analizo la condición booleana, el contador y deduzco el número exacto de iteraciones por inducción.'
      },
      {
        id: '1_social',
        style: 'social',
        badge: '👥 Colaborativo',
        icon: '🤝',
        colorClass: 'border-rose-500 bg-rose-50 text-rose-800',
        title: 'Preguntar y debatir con compañeros o comunidad',
        description: 'Pregunto en foros o a un colega cómo lo aplican en proyectos reales y discutimos diferentes enfoques.'
      }
    ]
  },
  {
    id: 2,
    situation: 'Depurando un error (Bug)',
    icon: '🐛',
    pregunta: 'Tu código arroja un error inesperado y no compila. ¿Cómo abordas el problema para solucionarlo?',
    senaAdvice: 'La resolución de errores revela mucho sobre tus patrones cognitivos de aprendizaje.',
    opciones: [
      {
        id: '2_practico',
        style: 'practico',
        badge: '⚡ Práctico',
        icon: '🛠️',
        colorClass: 'border-[#39a900] bg-[#39a900]/10 text-[#007832]',
        title: 'Tocar líneas y probar soluciones rápidas',
        description: 'Inserto console.log(), modifico variables y ejecuto repetidamente hasta ver la salida deseada.'
      },
      {
        id: '2_visual',
        style: 'visual',
        badge: '🎨 Visual',
        icon: '🎯',
        colorClass: 'border-[#00324d] bg-[#00324d]/10 text-[#00324d]',
        title: 'Graficar el flujo y usar depurador visual',
        description: 'Pongo puntos de interrupción (breakpoints) o imagino el árbol de ejecución para ver dónde se desvía.'
      },
      {
        id: '2_auditivo',
        style: 'auditivo',
        badge: '🎧 Auditivo',
        icon: '🦆',
        colorClass: 'border-[#71277a] bg-[#71277a]/10 text-[#71277a]',
        title: 'Explicar la función en voz alta (Rubber Duck)',
        description: 'Hablo solo o con un amigo repasando qué se supone que hace cada línea hasta notar la inconsistencia.'
      },
      {
        id: '2_lectoescritor',
        style: 'lectoescritor',
        badge: '📚 Lectoescritor',
        icon: '📝',
        colorClass: 'border-[#fdc300] bg-[#fdc300]/15 text-[#00324d]',
        title: 'Leer meticulosamente el mensaje y stack trace',
        description: 'Copio el error, leo cada palabra del registro, busco en la documentación y anoto la solución.'
      },
      {
        id: '2_logico',
        style: 'logico',
        badge: '🧩 Lógico',
        icon: '⚙️',
        colorClass: 'border-sky-500 bg-sky-50 text-sky-800',
        title: 'Rastrear premisas lógicas y tipos de datos',
        description: 'Verifico rigurosamente los tipos de entrada, valores nulos y casos borde paso por paso.'
      },
      {
        id: '2_social',
        style: 'social',
        badge: '👥 Colaborativo',
        icon: '💬',
        colorClass: 'border-rose-500 bg-rose-50 text-rose-800',
        title: 'Compartir el snippet y pedir otra perspectiva',
        description: 'Muestro la pantalla a otro programador o comparto el fragmento en un canal para recibir retroalimentación.'
      }
    ]
  },
  {
    id: 3,
    situation: 'Material de estudio preferido',
    icon: '📚',
    pregunta: 'Si tuvieras que aprender una tecnología de cero en un fin de semana, ¿qué recurso elegirías como principal?',
    senaAdvice: 'El formato que te resulta más cómodo acelera tu velocidad de aprendizaje hasta 3 veces.',
    opciones: [
      {
        id: '3_practico',
        style: 'practico',
        badge: '⚡ Práctico',
        icon: '🚀',
        colorClass: 'border-[#39a900] bg-[#39a900]/10 text-[#007832]',
        title: 'Un playground interactivo con retos que compilen',
        description: 'Aprender haciendo: una plataforma como Nodo que me ponga a escribir código desde el primer minuto.'
      },
      {
        id: '3_visual',
        style: 'visual',
        badge: '🎨 Visual',
        icon: '🗺️',
        colorClass: 'border-[#00324d] bg-[#00324d]/10 text-[#00324d]',
        title: 'Infografías interactivas y mapas de ruta visuales',
        description: 'Esquemas gráficos con código coloreado, diagramas arquitectónicos y resúmenes visuales de alto impacto.'
      },
      {
        id: '3_auditivo',
        style: 'auditivo',
        badge: '🎧 Auditivo',
        icon: '📻',
        colorClass: 'border-[#71277a] bg-[#71277a]/10 text-[#71277a]',
        title: 'Podcasts técnicos y clases magistrales habladas',
        description: 'Explicaciones en audio donde profesionales debatan las mejores prácticas y justifiquen cada decisión.'
      },
      {
        id: '3_lectoescritor',
        style: 'lectoescritor',
        badge: '📚 Lectoescritor',
        icon: '📑',
        colorClass: 'border-[#fdc300] bg-[#fdc300]/15 text-[#00324d]',
        title: 'Un libro técnico o documentación estructurada',
        description: 'Manuales con explicaciones detalladas, glosario de métodos y ejemplos comentados línea a línea.'
      },
      {
        id: '3_logico',
        style: 'logico',
        badge: '🧩 Lógico',
        icon: '🧠',
        colorClass: 'border-sky-500 bg-sky-50 text-sky-800',
        title: 'Problemas algorítmicos con complejidad y demostración',
        description: 'Ejercicios de lógica pura que expliquen la teoría formal de computación y por qué una solución es óptima.'
      },
      {
        id: '3_social',
        style: 'social',
        badge: '👥 Colaborativo',
        icon: '👨‍💻👩‍💻',
        colorClass: 'border-rose-500 bg-rose-50 text-rose-800',
        title: 'Un hackathon o grupo de estudio en vivo',
        description: 'Trabajar en equipo con metas comunes, compartiendo código y aprendiendo de los aciertos de otros.'
      }
    ]
  },
  {
    id: 4,
    situation: 'Comprobación de dominio',
    icon: '🏆',
    pregunta: '¿Cuándo sientes tú que realmente "dominaste" un tema o lenguaje de programación?',
    senaAdvice: 'Cada estilo tiene su propio termómetro de éxito y confianza técnica.',
    opciones: [
      {
        id: '4_practico',
        style: 'practico',
        badge: '⚡ Práctico',
        icon: '🏗️',
        colorClass: 'border-[#39a900] bg-[#39a900]/10 text-[#007832]',
        title: 'Cuando construyo un proyecto funcional real',
        description: 'Cuando puedo crear una app desde cero sin copiar código y verla corriendo perfectamente en el navegador.'
      },
      {
        id: '4_visual',
        style: 'visual',
        badge: '🎨 Visual',
        icon: '👁️',
        colorClass: 'border-[#00324d] bg-[#00324d]/10 text-[#00324d]',
        title: 'Cuando puedo ver mentalmente la arquitectura completa',
        description: 'Cuando puedo cerrar los ojos y visualizar claramente cómo se conectan los módulos y fluyen los datos.'
      },
      {
        id: '4_auditivo',
        style: 'auditivo',
        badge: '🎧 Auditivo',
        icon: '🗣️',
        colorClass: 'border-[#71277a] bg-[#71277a]/10 text-[#71277a]',
        title: 'Cuando puedo explicarlo con soltura en una conversación',
        description: 'Cuando participo en un debate técnico o entrevista y expongo los conceptos fluidamente sin dudar.'
      },
      {
        id: '4_lectoescritor',
        style: 'lectoescritor',
        badge: '📚 Lectoescritor',
        icon: '✍️',
        colorClass: 'border-[#fdc300] bg-[#fdc300]/15 text-[#00324d]',
        title: 'Cuando puedo redactar una guía o tutorial completo',
        description: 'Cuando soy capaz de escribir un documento técnico claro con instrucciones precisas para otros.'
      },
      {
        id: '4_logico',
        style: 'logico',
        badge: '🧩 Lógico',
        icon: '📐',
        colorClass: 'border-sky-500 bg-sky-50 text-sky-800',
        title: 'Cuando comprendo el rendimiento y casos límite',
        description: 'Cuando entiendo el coste computacional (Big-O), gestión de memoria y no hay magia oculta para mí.'
      },
      {
        id: '4_social',
        style: 'social',
        badge: '👥 Colaborativo',
        icon: '🌟',
        colorClass: 'border-rose-500 bg-rose-50 text-rose-800',
        title: 'Cuando ayudo con éxito a otro desarrollador a resolverlo',
        description: 'Cuando un compañero se traba y puedo guiarlo paso a paso hasta que su código funcione.'
      }
    ]
  },
  {
    id: 5,
    situation: 'Entorno de concentración óptimo',
    icon: '🧘',
    pregunta: '¿Cuál de estos entornos ambientales maximiza tu concentración y memoria de trabajo al programar?',
    senaAdvice: 'Tu ambiente sensorial ideal te protege de la fatiga cognitiva.',
    opciones: [
      {
        id: '5_practico',
        style: 'practico',
        badge: '⚡ Práctico',
        icon: '⌨️',
        colorClass: 'border-[#39a900] bg-[#39a900]/10 text-[#007832]',
        title: 'Dos pantallas con recarga viva inmediata',
        description: 'Un monitor para el código y otro para ver los resultados en vivo inmediatamente tras pulsar Ctrl+S.'
      },
      {
        id: '5_visual',
        style: 'visual',
        badge: '🎨 Visual',
        icon: '🖥️',
        colorClass: 'border-[#00324d] bg-[#00324d]/10 text-[#00324d]',
        title: 'Espacio limpio con tema de color bien contrastado',
        description: 'Pizarrón blanco a mano para dibujar, editor con resaltado de sintaxis armónico y paneles organizados.'
      },
      {
        id: '5_auditivo',
        style: 'auditivo',
        badge: '🎧 Auditivo',
        icon: '🎵',
        colorClass: 'border-[#71277a] bg-[#71277a]/10 text-[#71277a]',
        title: 'Auriculares con música binaural o narración activa',
        description: 'Sonidos de concentración, grabaciones explicativas o un ambiente donde pueda murmurar mi lógica sin molestar.'
      },
      {
        id: '5_lectoescritor',
        style: 'lectoescritor',
        badge: '📚 Lectoescritor',
        icon: '📓',
        colorClass: 'border-[#fdc300] bg-[#fdc300]/15 text-[#00324d]',
        title: 'Escritorio con cuaderno físico y documentación abierta',
        description: 'Un lugar en silencio donde pueda leer con calma, subrayar puntos clave y tener mis fichas de estudio.'
      },
      {
        id: '5_logico',
        style: 'logico',
        badge: '🧩 Lógico',
        icon: '☕',
        colorClass: 'border-sky-500 bg-sky-50 text-sky-800',
        title: 'Silencio absoluto para razonamiento abstracto',
        description: 'Cero interrupciones: tiempo ininterrumpido para desentrañar algoritmos complejos en mi cabeza.'
      },
      {
        id: '5_social',
        style: 'social',
        badge: '👥 Colaborativo',
        icon: '☕💻',
        colorClass: 'border-rose-500 bg-rose-50 text-rose-800',
        title: 'Café de trabajo colaborativo o sala de coworking',
        description: 'Estar rodeado de otras personas productivas con quienes intercambiar ideas breves durante los descansos.'
      }
    ]
  },
  {
    id: 6,
    situation: 'Explicación de un mentor',
    icon: '👨‍🏫',
    pregunta: 'Un tutor o colega senior te está enseñando una técnica avanzada. ¿Qué frase describe mejor lo que más te ayuda?',
    senaAdvice: 'Imagina que estoy sentado a tu lado explicándote una estructura de datos compleja.',
    opciones: [
      {
        id: '6_practico',
        style: 'practico',
        badge: '⚡ Práctico',
        icon: '🎮',
        colorClass: 'border-[#39a900] bg-[#39a900]/10 text-[#007832]',
        title: '"Déjame tomar el teclado y tecleo mientras me guías"',
        description: 'Aprendo mucho más si soy yo quien pulsa las teclas y comete los primeros errores guiados.'
      },
      {
        id: '6_visual',
        style: 'visual',
        badge: '🎨 Visual',
        icon: '✏️',
        colorClass: 'border-[#00324d] bg-[#00324d]/10 text-[#00324d]',
        title: '"Dibújame en una pizarra cómo se transforman los datos"',
        description: 'Un croquis con flechas y cajas me deja claro el problema en 30 segundos más que 20 minutos de charla.'
      },
      {
        id: '6_auditivo',
        style: 'auditivo',
        badge: '🎧 Auditivo',
        icon: '🗣️',
        colorClass: 'border-[#71277a] bg-[#71277a]/10 text-[#71277a]',
        title: '"Cuéntamelo con tus palabras y déjame parafrasearlo"',
        description: 'Escucho la explicación, la repito en voz alta con mi propio vocabulario y pregunto sobre cada detalle.'
      },
      {
        id: '6_lectoescritor',
        style: 'lectoescritor',
        badge: '📚 Lectoescritor',
        icon: '📄',
        colorClass: 'border-[#fdc300] bg-[#fdc300]/15 text-[#00324d]',
        title: '"Pásame el enlace al artículo o el snippet documentado"',
        description: 'Prefiero tener el texto para leerlo a mi propio ritmo, analizando cada línea comentada.'
      },
      {
        id: '6_logico',
        style: 'logico',
        badge: '🧩 Lógico',
        icon: '⚖️',
        colorClass: 'border-sky-500 bg-sky-50 text-sky-800',
        title: '"Muéstrame el razonamiento formal: ¿por qué esta solución?"',
        description: 'Quiero entender el porqué matemático o lógico detrás de la elección antes de ver la sintaxis.'
      },
      {
        id: '6_social',
        style: 'social',
        badge: '👥 Colaborativo',
        icon: '💬',
        colorClass: 'border-rose-500 bg-rose-50 text-rose-800',
        title: '"Hagamos Pair Programming: resolvamos el reto juntos"',
        description: 'Uno piensa la estrategia (Driver) y el otro programa (Navigator), alternando roles activamente.'
      }
    ]
  },
  {
    id: 7,
    situation: 'Motivación y constancia (Racha)',
    icon: '🔥',
    pregunta: 'Para mantener tu racha diaria en Nodo y no abandonar, ¿cuál de estas dinámicas te engancha más?',
    senaAdvice: '¡Última pregunta! Con esto Nodo configurará tu experiencia a tu medida.',
    opciones: [
      {
        id: '7_practico',
        style: 'practico',
        badge: '⚡ Práctico',
        icon: '⚡',
        colorClass: 'border-[#39a900] bg-[#39a900]/10 text-[#007832]',
        title: 'Retos de código diarios interactivos con validación instantánea',
        description: 'Ver que mis funciones pasan las pruebas unitarias en verde con XP inmediata me da un subidón de dopamina.'
      },
      {
        id: '7_visual',
        style: 'visual',
        badge: '🎨 Visual',
        icon: '🌈',
        colorClass: 'border-[#00324d] bg-[#00324d]/10 text-[#00324d]',
        title: 'Ver mi mapa de habilidades y gráficos de racha crecer',
        description: 'Completar el camino visual de módulos, desbloquear colores y ver los anillos de progreso llenarse.'
      },
      {
        id: '7_auditivo',
        style: 'auditivo',
        badge: '🎧 Auditivo',
        icon: '🔔',
        colorClass: 'border-[#71277a] bg-[#71277a]/10 text-[#71277a]',
        title: 'Efectos de sonido de éxito y el tutor hablando conmigo',
        description: 'El sonido de acierto sintetizado, el audio de subida de nivel y las palabras de aliento de Nodo Bot.'
      },
      {
        id: '7_lectoescritor',
        style: 'lectoescritor',
        badge: '📚 Lectoescritor',
        icon: '📖',
        colorClass: 'border-[#fdc300] bg-[#fdc300]/15 text-[#00324d]',
        title: 'Desbloquear resúmenes técnicos y glosarios exclusivos',
        description: 'Completar mi biblioteca personal de apuntes y tarjetas de referencia para repasar en cualquier momento.'
      },
      {
        id: '7_logico',
        style: 'logico',
        badge: '🧩 Lógico',
        icon: '♟️',
        colorClass: 'border-sky-500 bg-sky-50 text-sky-800',
        title: 'Acertijos algorítmicos con dificultad creciente',
        description: 'Superar problemas difíciles que requieran ingenio matemático y optimización de código eficiente.'
      },
      {
        id: '7_social',
        style: 'social',
        badge: '👥 Colaborativo',
        icon: '🏆',
        colorClass: 'border-rose-500 bg-rose-50 text-rose-800',
        title: 'Escalar en la tabla de líderes y competir amistosamente',
        description: 'Ver mi posición subir en el ranking semanal y superar la puntuación de mis compañeros.'
      }
    ]
  }
];

// Helper to compute learning style results from selected answers
export function calculateLearningStyleResult(answers: Record<number, LearningStyleType>): {
  primaryStyle: LearningStyleScore;
  secondaryStyle: LearningStyleScore;
  breakdown: LearningStyleScore[];
  recommendations: string[];
} {
  const counts: Record<LearningStyleType, number> = {
    practico: 0,
    visual: 0,
    auditivo: 0,
    lectoescritor: 0,
    logico: 0,
    social: 0
  };

  const totalQuestions = Object.keys(answers).length || 1;

  Object.values(answers).forEach((style) => {
    if (counts[style] !== undefined) {
      counts[style]++;
    }
  });

  const breakdown: LearningStyleScore[] = (Object.keys(counts) as LearningStyleType[]).map((type) => {
    const info = LEARNING_STYLES_INFO[type];
    const score = counts[type];
    const percentage = Math.round((score / totalQuestions) * 100);
    return {
      ...info,
      score,
      percentage
    };
  });

  // Sort descending by score / percentage
  breakdown.sort((a, b) => b.score - a.score || b.percentage - a.percentage);

  const primaryStyle = breakdown[0];
  const secondaryStyle = breakdown[1] || breakdown[0];

  const recommendations: string[] = [
    ...primaryStyle.studyTips.slice(0, 2),
    ...secondaryStyle.studyTips.slice(0, 2)
  ];

  return {
    primaryStyle,
    secondaryStyle,
    breakdown,
    recommendations
  };
}
