import { ModuleRoadmap } from '../types';

export const STATIC_ROADMAPS: Record<string, ModuleRoadmap> = {
  python: {
    moduleId: "python",
    moduleTitle: "Python Avanzado & Scripting Dinámico",
    unitTitle: "Unidad 1: Fundamentos Sintácticos & Estructuras Python",
    themeMascot: {
      name: "Pythie la Serpiente",
      avatar: "🐍",
      themeColor: "#0284c7",
      accentColor: "#fbbf24",
      pathColor: "#38bdf8",
      dialogue: "¡Sss-aludos! Sígueme por el sendero para dominar las listas y funciones de Python.",
      speechAudio: "Saludos. Sígueme por el sendero para dominar las listas y funciones de Python.",
      mascotPlacement: "left_side",
      animationStates: {
        idle: "float_gentle",
        talking: "wiggle_wave",
        celebrating: "bounce_stars"
      }
    },
    levels: [
      {
        id: "py_lvl_1",
        title: "Nacimiento del Script",
        type: "lesson",
        nodeType: "lesson",
        curveOffset: 0,
        isLocked: false,
        isCompleted: true,
        stars: 3,
        rewardBits: 25,
        rewardXP: 50,
        question: {
          id: "py_q1",
          type: "coding",
          difficulty: "basico",
          title: "Tu primera variable y retorno",
          description: "Crea una función llamada `saludoSerpiente()` que devuelva exactamente 'Sss-hola'.",
          initialCode: "function saludoSerpiente() {\n  // Tu código aquí\n  return 'Sss-hola';\n}",
          testCases: [{ id: "tc1", input: "()", codeCheck: "saludoSerpiente()", expectedOutput: "Sss-hola" }],
          explanation: "Define un string simple y usa return para emitir el valor.",
          speechText: "Pythie te acompaña en tu primer paso: define la función saludoSerpiente y retorna el string exacto.",
          audioTip: "Recuerda que return finaliza la ejecución de la función y entrega el resultado.",
          visualDiagram: "[saludoSerpiente()] ──► { Retorna: 'Sss-hola' } ──► [Consola]"
        }
      },
      {
        id: "py_lvl_2",
        title: "Bifurcaciones con Elif",
        type: "lesson",
        nodeType: "lesson",
        curveOffset: 1,
        isLocked: false,
        isCompleted: false,
        stars: 0,
        rewardBits: 30,
        rewardXP: 60,
        question: {
          id: "py_q2",
          type: "multiple_choice",
          difficulty: "intermedio",
          title: "Condicionales en Python",
          description: "¿Cuál es la palabra clave para 'else if' en Python?",
          options: [
            { id: "A", text: "elseif" },
            { id: "B", text: "elif" },
            { id: "C", text: "else if" },
            { id: "D", text: "then if" }
          ],
          correctOptionId: "B",
          explanation: "Python sintetiza 'else if' en la directiva 'elif' para simplificar la anidación.",
          speechText: "Pythie te pregunta: ¿Cuál es la directiva que combina else e if en una sola palabra clave?",
          audioTip: "Es una contracción de 4 letras muy famosa en Python.",
          visualDiagram: "[Condición 1 (if)] ──► Falso ──► [Condición 2 (elif)] ──► Verdadero"
        }
      },
      {
        id: "py_lvl_3",
        title: "Cofre de Pythie",
        type: "chest",
        nodeType: "chest_reward",
        curveOffset: 0,
        isLocked: false,
        isCompleted: false,
        rewardBits: 100,
        rewardXP: 120
      },
      {
        id: "py_lvl_4",
        title: "Comprensión de Listas",
        type: "lesson",
        nodeType: "lesson",
        curveOffset: -1,
        isLocked: true,
        isCompleted: false,
        stars: 0,
        rewardBits: 40,
        rewardXP: 80,
        question: {
          id: "py_q3",
          type: "parsons",
          difficulty: "intermedio",
          title: "Sintaxis de List Comprehension",
          description: "Ordena los bloques para construir la lista de cuadrados: `[x**2 for x in numeros]`.",
          parsonsBlocks: [
            { id: "b1", text: "const cuadrados = [" },
            { id: "b2", text: "  numeros.map(x => x ** 2)" },
            { id: "b3", text: "];" }
          ],
          correctOrder: ["b1", "b2", "b3"],
          explanation: "La comprensión de listas transforma cada elemento aplicando una expresión concisa.",
          speechText: "Construyamos la transformación de la lista paso a paso colocando la apertura, el mapeo y el cierre.",
          visualDiagram: "[1, 2, 3] ──( x ** 2 )──► [1, 4, 9]"
        }
      },
      {
        id: "py_lvl_5",
        title: "Jefe: Algoritmo Anaconda",
        type: "boss",
        nodeType: "boss_challenge",
        curveOffset: 0,
        isLocked: true,
        isCompleted: false,
        stars: 0,
        rewardBits: 200,
        rewardXP: 300,
        question: {
          id: "py_boss",
          type: "coding",
          difficulty: "avanzado",
          title: "Desafío Final: Suma de Pares",
          description: "Crea una función llamada `sumarPares(lista)` que tome un arreglo numérico y devuelva la suma de los números pares.",
          initialCode: "function sumarPares(lista) {\n  // Completa el algoritmo del Jefe Anaconda\n  return lista.filter(n => n % 2 === 0).reduce((a, b) => a + b, 0);\n}",
          testCases: [
            { id: "tb1", input: "([1, 2, 3, 4, 6])", codeCheck: "sumarPares([1, 2, 3, 4, 6])", expectedOutput: 12 },
            { id: "tb2", input: "([1, 3, 5])", codeCheck: "sumarPares([1, 3, 5])", expectedOutput: 0 }
          ],
          explanation: "Filtra con módulo 2 y acumula los valores con suma.",
          speechText: "¡El Jefe Anaconda te desafía! Filtra únicamente los pares y acumula su total.",
          visualDiagram: "[1, 2, 3, 4, 6] ──► Filtro Pares [2, 4, 6] ──► Suma Total = 12"
        }
      }
    ],
    roadmap: {
      sectionTitle: "Unidad 1: Fundamentos Sintácticos & Estructuras Python",
      nodes: []
    }
  },

  javascript: {
    moduleId: "javascript",
    moduleTitle: "JavaScript Moderno & Web Interactiva",
    unitTitle: "Unidad 1: Energía Reactiva & Eventos del DOM",
    themeMascot: {
      name: "Voltio JS",
      avatar: "⚡",
      themeColor: "#FACC15",
      accentColor: "#F59E0B",
      pathColor: "#FDE047",
      dialogue: "¡Zzzap! Conectemos los reactores y eventos dinámicos del DOM a la velocidad de la luz.",
      speechAudio: "Zzzap. Conectemos los reactores y eventos dinámicos del DOM a la velocidad de la luz.",
      mascotPlacement: "right_side",
      animationStates: {
        idle: "float_gentle",
        talking: "wiggle_wave",
        celebrating: "bounce_stars"
      }
    },
    levels: [
      {
        id: "js_lvl_1",
        title: "Chispa de Variables: Const vs Let",
        type: "lesson",
        nodeType: "lesson",
        curveOffset: 0,
        isLocked: false,
        isCompleted: true,
        stars: 3,
        rewardBits: 25,
        rewardXP: 50,
        question: {
          id: "js_q1",
          type: "multiple_choice",
          difficulty: "basico",
          title: "Inmutabilidad de enlace en JS",
          description: "¿Qué palabra clave declara una variable cuyo identificador no puede ser reasignado?",
          options: [
            { id: "A", text: "var" },
            { id: "B", text: "const" },
            { id: "C", text: "let" },
            { id: "D", text: "static" }
          ],
          correctOptionId: "B",
          explanation: "const crea una referencia inmutable al valor o estructura asignada.",
          speechText: "Voltio JS te pregunta: ¿Cuál palabra clave previene que reasignes una variable por accidente?",
          audioTip: "Empieza por C y es la más recomendada en código limpio moderno.",
          visualDiagram: "const PI = 3.14 ──► [Candado de Reasignación] ──► Intento de PI = 4 arroja TypeError"
        }
      },
      {
        id: "js_lvl_2",
        title: "Disparadores de Eventos",
        type: "lesson",
        nodeType: "lesson",
        curveOffset: 1,
        isLocked: false,
        isCompleted: false,
        stars: 0,
        rewardBits: 30,
        rewardXP: 60,
        question: {
          id: "js_q2",
          type: "coding",
          difficulty: "basico",
          title: "Función Flecha de Pulsos",
          description: "Crea una arrow function llamada `multiplicarVoltaje(v)` que multiplique el valor recibido por 2.",
          initialCode: "const multiplicarVoltaje = (v) => {\n  // Tu código flecha aquí\n  return v * 2;\n};",
          testCases: [
            { id: "jt1", input: "(5)", codeCheck: "multiplicarVoltaje(5)", expectedOutput: 10 },
            { id: "jt2", input: "(12)", codeCheck: "multiplicarVoltaje(12)", expectedOutput: 24 }
          ],
          explanation: "Las arrow functions ofrecen una sintaxis compacta y mantienen el enlace lexico.",
          speechText: "Voltio JS necesita duplicar la energía: retorna v multiplicado por dos.",
          visualDiagram: "(v: 5) ──[ => v * 2 ]──► Resultado: 10"
        }
      },
      {
        id: "js_lvl_3",
        title: "Reactor de Bits",
        type: "chest",
        nodeType: "chest_reward",
        curveOffset: 0,
        isLocked: false,
        isCompleted: false,
        rewardBits: 100,
        rewardXP: 120
      },
      {
        id: "js_lvl_4",
        title: "Desestructuración de Objetos",
        type: "lesson",
        nodeType: "lesson",
        curveOffset: -1,
        isLocked: true,
        isCompleted: false,
        stars: 0,
        rewardBits: 40,
        rewardXP: 80,
        question: {
          id: "js_q3",
          type: "parsons",
          difficulty: "intermedio",
          title: "Destructuring Assignment",
          description: "Ordena los bloques para extraer las propiedades `nombre` y `potencia` del reactor.",
          parsonsBlocks: [
            { id: "b1", text: "const reactor = { nombre: 'Arc', potencia: 9000 };" },
            { id: "b2", text: "const { nombre, potencia } = reactor;" },
            { id: "b3", text: "return `${nombre}:${potencia}`;" }
          ],
          correctOrder: ["b1", "b2", "b3"],
          explanation: "El destructuring desempaca propiedades de objetos directamente en variables.",
          speechText: "Extrae de una sola línea las variables nombre y potencia usando llaves.",
          visualDiagram: "{ nombre: 'Arc', potencia: 9000 } ──► const { nombre, potencia }"
        }
      },
      {
        id: "js_lvl_5",
        title: "Jefe: Sobrecarga del Reactor",
        type: "boss",
        nodeType: "boss_challenge",
        curveOffset: 0,
        isLocked: true,
        isCompleted: false,
        stars: 0,
        rewardBits: 200,
        rewardXP: 300,
        question: {
          id: "js_boss",
          type: "coding",
          difficulty: "avanzado",
          title: "Estabilizador Asíncrono",
          description: "Crea una función llamada `filtrarEstables(lecturas)` que reciba un arreglo numérico y devuelva solo los valores entre 50 y 100 inclusive.",
          initialCode: "function filtrarEstables(lecturas) {\n  // Estabiliza las lecturas del reactor\n  return lecturas.filter(v => v >= 50 && v <= 100);\n}",
          testCases: [
            { id: "jtb1", input: "([20, 60, 85, 120])", codeCheck: "filtrarEstables([20, 60, 85, 120])", expectedOutput: [60, 85] }
          ],
          explanation: "Filtra con condiciones compuestas usando el operador lógico AND.",
          speechText: "¡Sobrecarga inminente! Filtra únicamente los voltajes estables entre 50 y 100.",
          visualDiagram: "[20, 60, 85, 120] ──► Condición (v >= 50 && v <= 100) ──► [60, 85]"
        }
      }
    ],
    roadmap: {
      sectionTitle: "Unidad 1: Energía Reactiva & Eventos del DOM",
      nodes: []
    }
  },

  logica: {
    moduleId: "logica",
    moduleTitle: "Lógica de Programación & Pensamiento Computacional",
    unitTitle: "Unidad 1: Compuertas Booleanas & Decisiones",
    themeMascot: {
      name: "Nodo Bot",
      avatar: "🤖",
      themeColor: "#2EE59D",
      accentColor: "#007832",
      pathColor: "#10B981",
      dialogue: "¡Saludos, programador! Iniciando diagnóstico lógico y compuertas booleanas.",
      speechAudio: "Saludos programador. Iniciando diagnóstico lógico y compuertas booleanas.",
      mascotPlacement: "left_side",
      animationStates: {
        idle: "float_gentle",
        talking: "wiggle_wave",
        celebrating: "bounce_stars"
      }
    },
    levels: [
      {
        id: "log_lvl_1",
        title: "Compuertas AND / OR",
        type: "lesson",
        nodeType: "lesson",
        curveOffset: 0,
        isLocked: false,
        isCompleted: true,
        stars: 3,
        rewardBits: 25,
        rewardXP: 50,
        question: {
          id: "log_q1",
          type: "multiple_choice",
          difficulty: "basico",
          title: "Evaluación Booleana de Verdad",
          description: "¿Cuál es el resultado de la expresión: `(true && false) || (true && true)`?",
          options: [
            { id: "A", text: "false" },
            { id: "B", text: "true" },
            { id: "C", text: "null" },
            { id: "D", text: "undefined" }
          ],
          correctOptionId: "B",
          explanation: "`true && false` es false, pero `true && true` es true. Al unirlos con OR (||), el resultado es true.",
          speechText: "Nodo Bot diagnostica la compuerta: false unido con OR a true resulta en verdadero.",
          audioTip: "Recuerda que con el operador OR basta con que un solo lado sea verdadero.",
          visualDiagram: "(true && false) -> false \n(true && true) -> true \nfalse || true ──► TRUE"
        }
      },
      {
        id: "log_lvl_2",
        title: "Compuerta de Acceso Seguro",
        type: "lesson",
        nodeType: "lesson",
        curveOffset: 1,
        isLocked: false,
        isCompleted: false,
        stars: 0,
        rewardBits: 30,
        rewardXP: 60,
        question: {
          id: "log_q2",
          type: "coding",
          difficulty: "basico",
          title: "Función de Validación de Acceso",
          description: "Crea una función llamada `puedePasar(edad, tienePermiso)` que devuelva true si la edad es >= 18 o si tienePermiso es true.",
          initialCode: "function puedePasar(edad, tienePermiso) {\n  // Tu lógica aquí\n  return edad >= 18 || tienePermiso === true;\n}",
          testCases: [
            { id: "lt1", input: "(17, true)", codeCheck: "puedePasar(17, true)", expectedOutput: true },
            { id: "lt2", input: "(16, false)", codeCheck: "puedePasar(16, false)", expectedOutput: false },
            { id: "lt3", input: "(20, false)", codeCheck: "puedePasar(20, false)", expectedOutput: true }
          ],
          explanation: "La disyunción lógica evalúa positivamente si cualquiera de las dos condiciones se cumple.",
          speechText: "Diseña la compuerta de seguridad: permite el acceso si es mayor de edad o cuenta con permiso.",
          visualDiagram: "[Edad >= 18] ───OR───► [Tiene Permiso] ──► Acceso Concedido"
        }
      },
      {
        id: "log_lvl_3",
        title: "Cofre de la Lógica",
        type: "chest",
        nodeType: "chest_reward",
        curveOffset: 0,
        isLocked: false,
        isCompleted: false,
        rewardBits: 100,
        rewardXP: 120
      },
      {
        id: "log_lvl_4",
        title: "Detector de Paradojas",
        type: "lesson",
        nodeType: "lesson",
        curveOffset: -1,
        isLocked: true,
        isCompleted: false,
        stars: 0,
        rewardBits: 40,
        rewardXP: 80,
        question: {
          id: "log_q3",
          type: "logic_analysis",
          difficulty: "intermedio",
          title: "Detección de Error en Bucle",
          description: "Localiza la línea que genera una condición inalcanzable o error de asignación en lugar de comparación.",
          codeSnippet: "function verificar(x) {\n  let estado = false;\n  if (x = 10) {\n    estado = true;\n  }\n  return estado;\n}",
          bugLine: 3,
          bugExplanation: "En la línea 3 se usa el operador de asignación '=' en lugar de igualdad '===' dentro del if.",
          explanation: "En la línea 3 se usa el operador de asignación '=' en lugar de igualdad '===' dentro de la expresión condicional.",
          speechText: "Nodo Bot detectó una anomalía en la condición: observa con atención el operador dentro del if.",
          visualDiagram: "Línea 3: if (x = 10) ──► ERROR: Asigna 10 a x y siempre evalúa como truthy."
        }
      },
      {
        id: "log_lvl_5",
        title: "Jefe: Oráculo Booleano",
        type: "boss",
        nodeType: "boss_challenge",
        curveOffset: 0,
        isLocked: true,
        isCompleted: false,
        stars: 0,
        rewardBits: 200,
        rewardXP: 300,
        question: {
          id: "log_boss",
          type: "coding",
          difficulty: "avanzado",
          title: "Evaluador de Paridad y Signo",
          description: "Crea una función llamada `analizarNumero(n)` que retorne 'POSITIVO_PAR', 'POSITIVO_IMPAR', 'NEGATIVO' o 'CERO'.",
          initialCode: "function analizarNumero(n) {\n  if (n === 0) return 'CERO';\n  if (n < 0) return 'NEGATIVO';\n  return n % 2 === 0 ? 'POSITIVO_PAR' : 'POSITIVO_IMPAR';\n}",
          testCases: [
            { id: "lb1", input: "(4)", codeCheck: "analizarNumero(4)", expectedOutput: "POSITIVO_PAR" },
            { id: "lb2", input: "(7)", codeCheck: "analizarNumero(7)", expectedOutput: "POSITIVO_IMPAR" },
            { id: "lb3", input: "(-3)", codeCheck: "analizarNumero(-3)", expectedOutput: "NEGATIVO" },
            { id: "lb4", input: "(0)", codeCheck: "analizarNumero(0)", expectedOutput: "CERO" }
          ],
          explanation: "Encadena bifurcaciones para clasificar exhaustivamente el dominio numérico.",
          speechText: "¡El Oráculo Booleano pone a prueba tu control de flujo! Clasifica el número según su signo y paridad.",
          visualDiagram: "n ──► [Es Cero?] ──► [Es Negativo?] ──► [Par o Impar?]"
        }
      }
    ],
    roadmap: {
      sectionTitle: "Unidad 1: Compuertas Booleanas & Decisiones",
      nodes: []
    }
  },

  basesdatos: {
    moduleId: "basesdatos",
    moduleTitle: "Bases de Datos & SQL Relacional",
    unitTitle: "Unidad 1: Modelado Entidad-Relación & Consultas Clave",
    themeMascot: {
      name: "Cylo DB",
      avatar: "🗄️",
      themeColor: "#7C3AED",
      accentColor: "#C084FC",
      pathColor: "#A855F7",
      dialogue: "¡Bip bop! Estructurando tablas relacionales normalizadas e índices de alta velocidad.",
      speechAudio: "Bip bop. Estructurando tablas relacionales normalizadas e índices de alta velocidad.",
      mascotPlacement: "right_side",
      animationStates: {
        idle: "float_gentle",
        talking: "wiggle_wave",
        celebrating: "bounce_stars"
      }
    },
    levels: [
      {
        id: "db_lvl_1",
        title: "Llaves Primarias y Foráneas",
        type: "lesson",
        nodeType: "lesson",
        curveOffset: 0,
        isLocked: false,
        isCompleted: true,
        stars: 3,
        rewardBits: 25,
        rewardXP: 50,
        question: {
          id: "db_q1",
          type: "multiple_choice",
          difficulty: "basico",
          title: "Integridad Referencial",
          description: "¿Qué restricción garantiza que un campo sea único y no nulo para identificar cada registro?",
          options: [
            { id: "A", text: "FOREIGN KEY" },
            { id: "B", text: "PRIMARY KEY" },
            { id: "C", text: "CHECK" },
            { id: "D", text: "DEFAULT" }
          ],
          correctOptionId: "B",
          explanation: "La PRIMARY KEY asegura la unicidad e integridad de cada fila en una tabla relacional.",
          speechText: "Cylo DB pregunta: ¿Cuál es la llave principal que identifica unívocamente a cada registro?",
          audioTip: "Se compone de dos palabras y en inglés significa 'llave primaria'.",
          visualDiagram: "[Tabla Usuarios] ──► { id (PK): 101, nombre: 'Ana' } ──► Único y Obligatorio"
        }
      },
      {
        id: "db_lvl_2",
        title: "Filtrado con Clausula WHERE",
        type: "lesson",
        nodeType: "lesson",
        curveOffset: 1,
        isLocked: false,
        isCompleted: false,
        stars: 0,
        rewardBits: 30,
        rewardXP: 60,
        question: {
          id: "db_q2",
          type: "coding",
          difficulty: "basico",
          title: "Consulta SQL Básica",
          description: "Crea una función llamada `generarSQL(rol)` que devuelva la consulta: `SELECT * FROM usuarios WHERE rol = '${rol}';`",
          initialCode: "function generarSQL(rol) {\n  // Retorna la consulta SQL interpolada\n  return `SELECT * FROM usuarios WHERE rol = '${rol}';`;\n}",
          testCases: [
            { id: "dbt1", input: "('admin')", codeCheck: "generarSQL('admin')", expectedOutput: "SELECT * FROM usuarios WHERE rol = 'admin';" },
            { id: "dbt2", input: "('estudiante')", codeCheck: "generarSQL('estudiante')", expectedOutput: "SELECT * FROM usuarios WHERE rol = 'estudiante';" }
          ],
          explanation: "WHERE permite filtrar subconjuntos de datos en base a condiciones declarativas.",
          speechText: "Cylo DB necesita filtrar registros: interpola la condición WHERE rol igual al argumento.",
          visualDiagram: "[SELECT * FROM usuarios] ──► [Filtro WHERE rol = 'admin'] ──► Subconjunto Filtrado"
        }
      },
      {
        id: "db_lvl_3",
        title: "Bóveda de Transacciones",
        type: "chest",
        nodeType: "chest_reward",
        curveOffset: 0,
        isLocked: false,
        isCompleted: false,
        rewardBits: 100,
        rewardXP: 120
      },
      {
        id: "db_lvl_4",
        title: "Uniones con INNER JOIN",
        type: "lesson",
        nodeType: "lesson",
        curveOffset: -1,
        isLocked: true,
        isCompleted: false,
        stars: 0,
        rewardBits: 40,
        rewardXP: 80,
        question: {
          id: "db_q3",
          type: "parsons",
          difficulty: "intermedio",
          title: "Estructura de un INNER JOIN",
          description: "Ordena los bloques para construir la consulta que une aprendices con su ficha de matrícula.",
          parsonsBlocks: [
            { id: "b1", text: "SELECT a.nombre, f.codigo" },
            { id: "b2", text: "FROM aprendices a" },
            { id: "b3", text: "INNER JOIN fichas f ON a.ficha_id = f.id;" }
          ],
          correctOrder: ["b1", "b2", "b3"],
          explanation: "INNER JOIN combina filas de dos o más tablas cuando la condición de enlace se cumple en ambas.",
          speechText: "Conecta las dos tablas mediante la clave foránea ficha_id y la clave primaria id.",
          visualDiagram: "[aprendices] ──(a.ficha_id = f.id)──► [fichas] ──► Registros Coincidentes"
        }
      },
      {
        id: "db_lvl_5",
        title: "Jefe: Arquitecto de Consultas Cylo",
        type: "boss",
        nodeType: "boss_challenge",
        curveOffset: 0,
        isLocked: true,
        isCompleted: false,
        stars: 0,
        rewardBits: 200,
        rewardXP: 300,
        question: {
          id: "db_boss",
          type: "coding",
          difficulty: "avanzado",
          title: "Agrupación y Conteo",
          description: "Crea una función llamada `contarPorCategoria(productos)` que reciba un arreglo de objetos `{ nombre, categoria }` y devuelva un objeto con el conteo por categoría.",
          initialCode: "function contarPorCategoria(productos) {\n  return productos.reduce((acc, p) => {\n    acc[p.categoria] = (acc[p.categoria] || 0) + 1;\n    return acc;\n  }, {});\n}",
          testCases: [
            {
              id: "dbb1",
              input: "([{ nombre: 'Mouse', categoria: 'Tech' }, { nombre: 'Teclado', categoria: 'Tech' }, { nombre: 'Silla', categoria: 'Muebles' }])",
              codeCheck: "contarPorCategoria([{ nombre: 'Mouse', categoria: 'Tech' }, { nombre: 'Teclado', categoria: 'Tech' }, { nombre: 'Silla', categoria: 'Muebles' }])",
              expectedOutput: { Tech: 2, Muebles: 1 }
            }
          ],
          explanation: "Simula el comportamiento de una cláusula `GROUP BY categoria, COUNT(*)`.",
          speechText: "¡Cylo DB activa el optimizador de consultas! Agrupa los elementos y cuenta sus apariciones.",
          visualDiagram: "[Colección de Productos] ──► [GROUP BY Categoria] ──► { Tech: 2, Muebles: 1 }"
        }
      }
    ],
    roadmap: {
      sectionTitle: "Unidad 1: Modelado Entidad-Relación & Consultas Clave",
      nodes: []
    }
  },

  algoritmos: {
    moduleId: "algoritmos",
    moduleTitle: "Algoritmos & Estructuras de Datos",
    unitTitle: "Unidad 1: Notación Big-O & Búsqueda Eficiente",
    themeMascot: {
      name: "Nodo Bot Sabio",
      avatar: "🧠",
      themeColor: "#8B5CF6",
      accentColor: "#6366F1",
      pathColor: "#A78BFA",
      dialogue: "¡Patrones y optimización O(n)! Recorramos los árboles y grafos del algoritmo.",
      speechAudio: "Patrones y optimización O(n). Recorramos los árboles y grafos del algoritmo.",
      mascotPlacement: "left_side",
      animationStates: {
        idle: "float_gentle",
        talking: "wiggle_wave",
        celebrating: "bounce_stars"
      }
    },
    levels: [
      {
        id: "alg_lvl_1",
        title: "Búsqueda Binaria O(log n)",
        type: "lesson",
        nodeType: "lesson",
        curveOffset: 0,
        isLocked: false,
        isCompleted: true,
        stars: 3,
        rewardBits: 25,
        rewardXP: 50,
        question: {
          id: "alg_q1",
          type: "multiple_choice",
          difficulty: "basico",
          title: "Precondición de Búsqueda Binaria",
          description: "¿Cuál es el requisito indispensable que debe cumplir un arreglo para aplicar búsqueda binaria?",
          options: [
            { id: "A", text: "Debe contener solo números primos" },
            { id: "B", text: "Debe estar previamente ordenado" },
            { id: "C", text: "Debe tener una longitud par" },
            { id: "D", text: "No debe tener valores duplicados" }
          ],
          correctOptionId: "B",
          explanation: "La búsqueda binaria descarta la mitad de los elementos en cada paso aprovechando el orden relativo.",
          speechText: "Nodo Bot Sabio te recuerda: para dividir el espacio de búsqueda por la mitad, los elementos deben estar en orden.",
          audioTip: "Piensa en cómo buscas una palabra en un diccionario de papel.",
          visualDiagram: "[1, 3, 5, 7, 9, 11] ──► Punto Medio: 7 ──► Si buscamos 3, descartamos la mitad derecha"
        }
      },
      {
        id: "alg_lvl_2",
        title: "Búsqueda Lineal Adaptativa",
        type: "lesson",
        nodeType: "lesson",
        curveOffset: 1,
        isLocked: false,
        isCompleted: false,
        stars: 0,
        rewardBits: 30,
        rewardXP: 60,
        question: {
          id: "alg_q2",
          type: "coding",
          difficulty: "basico",
          title: "Implementación de Búsqueda Lineal",
          description: "Crea una función llamada `buscarElemento(arr, objetivo)` que retorne el índice donde se encuentra el objetivo, o -1 si no existe.",
          initialCode: "function buscarElemento(arr, objetivo) {\n  // Retorna el índice o -1\n  return arr.indexOf(objetivo);\n}",
          testCases: [
            { id: "at1", input: "(['a', 'b', 'c'], 'b')", codeCheck: "buscarElemento(['a', 'b', 'c'], 'b')", expectedOutput: 1 },
            { id: "at2", input: "(['a', 'b', 'c'], 'z')", codeCheck: "buscarElemento(['a', 'b', 'c'], 'z')", expectedOutput: -1 }
          ],
          explanation: "La búsqueda lineal recorre secuencialmente el arreglo con complejidad O(n).",
          speechText: "Recorre la colección secuencialmente y devuelve la posición del elemento solicitado.",
          visualDiagram: "['a', 'b', 'c'] ──► Compara 'a' (no) ──► Compara 'b' (encontrado en índice 1)"
        }
      },
      {
        id: "alg_lvl_3",
        title: "Cofre del Algoritmo Óptimo",
        type: "chest",
        nodeType: "chest_reward",
        curveOffset: 0,
        isLocked: false,
        isCompleted: false,
        rewardBits: 100,
        rewardXP: 120
      },
      {
        id: "alg_lvl_4",
        title: "Pilas y Colas (LIFO vs FIFO)",
        type: "lesson",
        nodeType: "lesson",
        curveOffset: -1,
        isLocked: true,
        isCompleted: false,
        stars: 0,
        rewardBits: 40,
        rewardXP: 80,
        question: {
          id: "alg_q3",
          type: "parsons",
          difficulty: "intermedio",
          title: "Estructura de una Pila (Stack)",
          description: "Ordena los bloques para crear una pila que apile y luego desapile un valor.",
          parsonsBlocks: [
            { id: "b1", text: "const pila = [];" },
            { id: "b2", text: "pila.push('Nodo A');" },
            { id: "b3", text: "const ultimo = pila.pop();" },
            { id: "b4", text: "return ultimo;" }
          ],
          correctOrder: ["b1", "b2", "b3", "b4"],
          explanation: "Las pilas operan bajo la disciplina LIFO (Last-In, First-Out).",
          speechText: "Primero inicializa la pila, inserta el elemento con push y extráelo con pop.",
          visualDiagram: "[Vacía] ──push('A')──► ['A'] ──pop()──► Retorna 'A'"
        }
      },
      {
        id: "alg_lvl_5",
        title: "Jefe: Algoritmo Gran O",
        type: "boss",
        nodeType: "boss_challenge",
        curveOffset: 0,
        isLocked: true,
        isCompleted: false,
        stars: 0,
        rewardBits: 200,
        rewardXP: 300,
        question: {
          id: "alg_boss",
          type: "coding",
          difficulty: "avanzado",
          title: "Eliminación de Duplicados en O(n)",
          description: "Crea una función llamada `removerDuplicados(arr)` que devuelva un nuevo arreglo con los valores únicos conservando el orden de aparición.",
          initialCode: "function removerDuplicados(arr) {\n  return [...new Set(arr)];\n}",
          testCases: [
            { id: "ab1", input: "([1, 2, 2, 3, 4, 4, 5])", codeCheck: "removerDuplicados([1, 2, 2, 3, 4, 4, 5])", expectedOutput: [1, 2, 3, 4, 5] },
            { id: "ab2", input: "(['x', 'y', 'x'])", codeCheck: "removerDuplicados(['x', 'y', 'x'])", expectedOutput: ['x', 'y'] }
          ],
          explanation: "Utilizar un conjunto (Set) garantiza unicidad en tiempo lineal O(n).",
          speechText: "¡El Jefe Gran O evalúa la eficiencia de tu código! Elimina duplicados conservando el orden en tiempo O(n).",
          visualDiagram: "[1, 2, 2, 3, 4, 4, 5] ──► Set(Unicidad O(n)) ──► [1, 2, 3, 4, 5]"
        }
      }
    ],
    roadmap: {
      sectionTitle: "Unidad 1: Notación Big-O & Búsqueda Eficiente",
      nodes: []
    }
  }
};

// Ensure roadmap.nodes points directly to levels for backward compatibility
Object.values(STATIC_ROADMAPS).forEach(mod => {
  if (mod.levels && mod.roadmap) {
    mod.roadmap.nodes = mod.levels;
    if (mod.unitTitle) {
      mod.roadmap.sectionTitle = mod.unitTitle;
    }
  }
});
