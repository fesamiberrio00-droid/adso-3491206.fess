-- ====================================================================
-- MIGRACIÓN 003: MODALIDAD INDEPENDIENTE EN PROGRESO DE MÓDULOS
-- Compatible con PostgreSQL 15+ / Neon Cloud PostgreSQL
-- ====================================================================

-- 1. Incorporar columna modality para diferenciar 'offline' (Estándar) e 'ia' (Clase con IA)
ALTER TABLE progreso_modulos_usuario
ADD COLUMN IF NOT EXISTS modality VARCHAR(20) NOT NULL DEFAULT 'offline';

-- 2. Restricción de valores permitidos para modality
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'chk_progreso_modulo_modality'
  ) THEN
    ALTER TABLE progreso_modulos_usuario
    ADD CONSTRAINT chk_progreso_modulo_modality
    CHECK (modality IN ('offline', 'ia'));
  END IF;
END $$;

-- 3. Reemplazar restricción única (user_id, modulo_id) por (user_id, modulo_id, modality)
ALTER TABLE progreso_modulos_usuario
DROP CONSTRAINT IF EXISTS uq_progreso_modulo_user;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'uq_progreso_modulo_user_modality'
  ) THEN
    ALTER TABLE progreso_modulos_usuario
    ADD CONSTRAINT uq_progreso_modulo_user_modality
    UNIQUE (user_id, modulo_id, modality);
  END IF;
END $$;
