-- ====================================================================
-- MIGRACIÓN 001: ESQUEMA INICIAL RELACIONAL — PROYECTO NODO
-- Compatible con PostgreSQL 15+ / Neon Cloud PostgreSQL
-- ====================================================================

-- Habilitar extensión para generación de identificadores UUID nativos
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- --------------------------------------------------------------------
-- TABLA DE CONTROL DEL SISTEMA DE MIGRACIONES
-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS _migraciones (
  id SERIAL PRIMARY KEY,
  nombre VARCHAR(255) NOT NULL UNIQUE,
  ejecutado_en TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- --------------------------------------------------------------------
-- DOMINIO 1: IDENTIDAD, SEGURIDAD Y GAMIFICACIÓN GLOBAL
-- --------------------------------------------------------------------

-- Tabla raíz de estudiantes y autenticación
CREATE TABLE IF NOT EXISTS usuarios (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  username VARCHAR(100) NOT NULL,
  email VARCHAR(255) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NULL, -- Permite NULL para cuentas exclusivas de Google OAuth
  auth_provider VARCHAR(50) NOT NULL DEFAULT 'local', -- 'local', 'google', 'both'
  google_id VARCHAR(255) NULL UNIQUE,
  age INTEGER NOT NULL DEFAULT 20,
  streak_days INTEGER NOT NULL DEFAULT 1, -- Racha de motivación inicial
  last_active_date DATE NULL,
  total_xp INTEGER NOT NULL DEFAULT 50, -- Bonificación inicial de bienvenida
  bits_balance INTEGER NOT NULL DEFAULT 300, -- Saldo formal de bienvenida para la tienda de Bits
  level INTEGER NOT NULL DEFAULT 1,
  title VARCHAR(100) NOT NULL DEFAULT 'Iniciado de Código 🐍',
  verified BOOLEAN NOT NULL DEFAULT false,
  deleted_at TIMESTAMPTZ NULL DEFAULT NULL, -- Borrado lógico (Soft Delete)
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Códigos de verificación temporal (OTP)
CREATE TABLE IF NOT EXISTS otps_verificacion (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE ON UPDATE CASCADE,
  email VARCHAR(255) NOT NULL,
  codigo_hash VARCHAR(255) NOT NULL, -- Almacenado como hash para evitar exposición
  proposito VARCHAR(50) NOT NULL DEFAULT 'registro_verificacion', -- 'registro_verificacion' | 'recuperacion_contrasena'
  intentos INTEGER NOT NULL DEFAULT 0,
  max_intentos INTEGER NOT NULL DEFAULT 5,
  expira_en TIMESTAMPTZ NOT NULL,
  usado BOOLEAN NOT NULL DEFAULT false,
  creado_en TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- --------------------------------------------------------------------
-- DOMINIO 2: NEURODIDÁCTICA Y DIAGNÓSTICO COGNITIVO
-- --------------------------------------------------------------------

-- Perfil de estilo de aprendizaje resultante del laboratorio cognitivo (7 fases)
CREATE TABLE IF NOT EXISTS perfiles_aprendizaje (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL UNIQUE REFERENCES usuarios(id) ON DELETE CASCADE ON UPDATE CASCADE,
  primary_style VARCHAR(50) NOT NULL, -- 'practico' | 'visual' | 'auditivo' | 'lectoescritor' | 'logico' | 'social'
  secondary_style VARCHAR(50) NOT NULL,
  visual_percentage NUMERIC(5,2) NOT NULL,
  auditory_percentage NUMERIC(5,2) NOT NULL,
  is_bimodal BOOLEAN NOT NULL DEFAULT false,
  bimodal_title VARCHAR(255) NULL,
  bimodal_description TEXT NULL,
  scores_breakdown JSONB NOT NULL, -- Puntajes detallados de las 6 afinidades cognitivas
  recommendations JSONB NOT NULL, -- Lista de directivas neurodidácticas adaptativas
  completed_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Respuestas al cuestionario inicial (DiagnosticWizard: 4 preguntas)
CREATE TABLE IF NOT EXISTS diagnosticos_iniciales (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE ON UPDATE CASCADE,
  answers JSONB NOT NULL, -- Array de respuestas [q1, q2, q3, q4]
  experience_level VARCHAR(100) NOT NULL,
  study_hours VARCHAR(100) NOT NULL,
  recommended_plan JSONB NOT NULL, -- Plan de 3 semanas estructurado por IA/reglas
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- --------------------------------------------------------------------
-- DOMINIO 3: SENDEROS DE APRENDIZAJE Y GAMIFICACIÓN (ESTILO DUOLINGO)
-- --------------------------------------------------------------------

-- Catálogo de módulos troncales de NODO
CREATE TABLE IF NOT EXISTS modulos (
  id VARCHAR(50) PRIMARY KEY, -- 'python', 'javascript', 'logica', 'basesdatos', 'algoritmos'
  title VARCHAR(150) NOT NULL,
  description TEXT NOT NULL,
  unit_title VARCHAR(200) NULL,
  emoji VARCHAR(20) NOT NULL,
  theme_color VARCHAR(50) NOT NULL,
  accent_color VARCHAR(50) NULL,
  theme_mascot JSONB NOT NULL, -- Datos de la mascota temática (nombre, avatar, diálogo, estados de animación)
  orden INTEGER NOT NULL DEFAULT 1,
  activo BOOLEAN NOT NULL DEFAULT true
);

-- Nodos individuales del sendero vectorial Bézier de cada módulo
CREATE TABLE IF NOT EXISTS nodos_sendero (
  id VARCHAR(100) PRIMARY KEY, -- ej. 'py_lvl_1', 'py_chest_1'
  modulo_id VARCHAR(50) NOT NULL REFERENCES modulos(id) ON DELETE CASCADE ON UPDATE CASCADE,
  title VARCHAR(150) NOT NULL,
  node_type VARCHAR(50) NOT NULL, -- 'lesson' | 'chest' | 'boss' | 'checkpoint'
  curve_offset INTEGER NOT NULL DEFAULT 0, -- Desplazamiento horizontal para la curva Bézier (-1, 0, 1)
  order_index INTEGER NOT NULL,
  reward_bits INTEGER NOT NULL DEFAULT 25,
  reward_xp INTEGER NOT NULL DEFAULT 50,
  question_data JSONB NULL, -- Pregunta pedagógica, casos unitarios, pistas de voz y diagramas
  checkpoint_requirement TEXT NULL,
  CONSTRAINT uq_nodos_sendero_id_modulo UNIQUE (id, modulo_id) -- Integridad referencial compuesta
);

-- Registro de avance y superación de lecciones por estudiante
CREATE TABLE IF NOT EXISTS progreso_usuario (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE ON UPDATE CASCADE,
  modulo_id VARCHAR(50) NOT NULL,
  node_id VARCHAR(100) NOT NULL,
  completed BOOLEAN NOT NULL DEFAULT false,
  score INTEGER NOT NULL DEFAULT 0, -- Calificación porcentual (0 a 100)
  stars INTEGER NOT NULL DEFAULT 0, -- Estrellas obtenidas (0, 1, 2, 3)
  attempts INTEGER NOT NULL DEFAULT 1,
  last_attempt_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT uq_progreso_user_node UNIQUE (user_id, node_id),
  CONSTRAINT fk_progreso_nodo_modulo FOREIGN KEY (node_id, modulo_id) 
    REFERENCES nodos_sendero(id, modulo_id) ON DELETE CASCADE ON UPDATE CASCADE
);

-- Registro de cofres abiertos (Garantiza atomicidad e idempotencia estricta en recompensas)
CREATE TABLE IF NOT EXISTS recompensas_reclamadas (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE ON UPDATE CASCADE,
  node_id VARCHAR(100) NOT NULL REFERENCES nodos_sendero(id) ON DELETE CASCADE ON UPDATE CASCADE,
  reward_bits INTEGER NOT NULL,
  reward_xp INTEGER NOT NULL,
  claimed_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT uq_recompensas_user_node UNIQUE (user_id, node_id) -- Impide duplicar el reclamo de un cofre
);

-- Historial de experiencia diaria para gráficas y control de racha
CREATE TABLE IF NOT EXISTS xp_diario (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE ON UPDATE CASCADE,
  date_slug DATE NOT NULL, -- Fecha formato YYYY-MM-DD
  xp_amount INTEGER NOT NULL DEFAULT 0,
  CONSTRAINT uq_xp_diario_user_date UNIQUE (user_id, date_slug)
);

-- --------------------------------------------------------------------
-- DOMINIO 4: INTELIGENCIA ARTIFICIAL SOCRÁTICA (NODO BOT)
-- --------------------------------------------------------------------

-- Historial conversacional socrático con Nodo Bot
CREATE TABLE IF NOT EXISTS conversaciones_tutor (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NULL REFERENCES usuarios(id) ON DELETE SET NULL ON UPDATE CASCADE, -- Permite anonimización en purga
  modulo_id VARCHAR(50) NULL REFERENCES modulos(id) ON DELETE SET NULL ON UPDATE CASCADE,
  node_id VARCHAR(100) NULL REFERENCES nodos_sendero(id) ON DELETE SET NULL ON UPDATE CASCADE,
  role VARCHAR(20) NOT NULL, -- 'user' | 'assistant'
  content TEXT NOT NULL,
  mode VARCHAR(50) NOT NULL DEFAULT 'socratic', -- 'socratic' | 'debug' | 'challenge'
  emotion_detected VARCHAR(50) NULL, -- 'thinking' | 'explaining' | 'victory' | 'neutral'
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- --------------------------------------------------------------------
-- ÍNDICES OPTIMIZADOS (Exclusivamente no redundantes)
-- --------------------------------------------------------------------
-- NOTA: Se omiten índices manuales sobre columnas con restricciones PRIMARY KEY
-- o UNIQUE, ya que PostgreSQL los genera automáticamente en segundo plano.

-- 1. Búsqueda rápida de usuarios activos con exclusión de borrados lógicos
CREATE INDEX IF NOT EXISTS idx_usuarios_deleted_at ON usuarios (deleted_at);

-- 2. Localización de códigos OTP pendientes por usuario y propósito
CREATE INDEX IF NOT EXISTS idx_otps_user_proposito ON otps_verificacion (user_id, proposito, usado);

-- 3. Lectura rápida del diagnóstico inicial por usuario
CREATE INDEX IF NOT EXISTS idx_diagnosticos_user_id ON diagnosticos_iniciales (user_id);

-- 4. Ordenamiento visual del catálogo de módulos en el menú
CREATE INDEX IF NOT EXISTS idx_modulos_orden ON modulos (orden, activo);

-- 5. Consulta y renderizado ordenado del sendero Bézier por módulo
CREATE INDEX IF NOT EXISTS idx_nodos_modulo_order ON nodos_sendero (modulo_id, order_index);

-- 6. Consulta de avance de un estudiante en un módulo completo
CREATE INDEX IF NOT EXISTS idx_progreso_user_modulo ON progreso_usuario (user_id, modulo_id);

-- 7. Carga cronológica de las conversaciones recientes del tutor Nodo Bot
CREATE INDEX IF NOT EXISTS idx_conversaciones_user_created ON conversaciones_tutor (user_id, created_at DESC);
