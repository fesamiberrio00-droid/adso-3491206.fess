-- ====================================================================
-- MIGRACIÓN 002: INTERESES DE USUARIO Y PROGRESO DE MÓDULOS
-- Compatible con PostgreSQL 15+ / Neon Cloud PostgreSQL
-- ====================================================================

-- 1. Incorporar columna interests en usuarios con validación de arreglo JSON
ALTER TABLE usuarios 
ADD COLUMN IF NOT EXISTS interests JSONB NOT NULL DEFAULT '[]'::jsonb;

-- Restricción para garantizar que interests sea estrictamente un arreglo JSON
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'chk_usuarios_interests_is_array'
  ) THEN
    ALTER TABLE usuarios 
    ADD CONSTRAINT chk_usuarios_interests_is_array 
    CHECK (jsonb_typeof(interests) = 'array');
  END IF;
END $$;

-- 2. Crear tabla progreso_modulos_usuario para el resumen por módulo
CREATE TABLE IF NOT EXISTS progreso_modulos_usuario (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE ON UPDATE CASCADE,
  modulo_id VARCHAR(50) NOT NULL REFERENCES modulos(id) ON DELETE CASCADE ON UPDATE CASCADE,
  completed BOOLEAN NOT NULL DEFAULT false,
  score INTEGER NOT NULL DEFAULT 0,
  level VARCHAR(50) NOT NULL DEFAULT 'Principiante',
  completed_at DATE NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),

  -- Restricción 1: Unicidad por estudiante y módulo
  CONSTRAINT uq_progreso_modulo_user UNIQUE (user_id, modulo_id),

  -- Restricción 2: Calificación acotada entre 0 y 100 %
  CONSTRAINT chk_progreso_modulo_score CHECK (score >= 0 AND score <= 100),

  -- Restricción 3: Niveles permitidos estrictamente cerrados
  CONSTRAINT chk_progreso_modulo_level CHECK (level IN ('Principiante', 'Intermedio', 'Avanzado')),

  -- Restricción 4: Coherencia temporal de completitud
  CONSTRAINT chk_progreso_modulo_completed_at CHECK (
    (completed = true AND completed_at IS NOT NULL) OR 
    (completed = false AND completed_at IS NULL)
  )
);

