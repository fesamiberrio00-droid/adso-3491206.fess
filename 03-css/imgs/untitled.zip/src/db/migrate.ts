/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * EJECUTOR DE MIGRACIONES VERSIONADAS (PostgreSQL / Neon)
 * Proyecto NODO — Fase 3
 */

import 'dotenv/config';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { getPool, closePool } from '../db';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const MIGRATIONS_DIR = path.resolve(__dirname, 'migrations');

export interface MigrationResult {
  executed: string[];
  skipped: string[];
  total: number;
  success: boolean;
  error?: string;
}

/**
 * Prepara la tabla técnica de control `_migraciones` e inspecciona
 * los archivos SQL disponibles en orden secuencial.
 */
export async function runMigrations(): Promise<MigrationResult> {
  const result: MigrationResult = {
    executed: [],
    skipped: [],
    total: 0,
    success: false,
  };

  // 1. Verificación de presencia de DATABASE_URL
  if (!process.env.DATABASE_URL) {
    const msg =
      'DATABASE_URL no está definida en las variables de entorno. ' +
      'No es posible ejecutar las migraciones sin una base de datos de destino.';
    console.warn(`[NODO Migraciones] ⚠️  ${msg}`);
    result.error = msg;
    return result;
  }

  // 2. Comprobar existencia del directorio de migraciones
  if (!fs.existsSync(MIGRATIONS_DIR)) {
    const msg = `El directorio de migraciones no existe: ${MIGRATIONS_DIR}`;
    console.error(`[NODO Migraciones] ❌ ${msg}`);
    result.error = msg;
    return result;
  }

  // 3. Obtener y ordenar alfanuméricamente los archivos .sql
  const migrationFiles = fs
    .readdirSync(MIGRATIONS_DIR)
    .filter((file) => file.endsWith('.sql'))
    .sort((a, b) => a.localeCompare(b, undefined, { numeric: true, sensitivity: 'base' }));

  result.total = migrationFiles.length;

  if (migrationFiles.length === 0) {
    console.log('[NODO Migraciones] ℹ️  No se encontraron archivos de migración .sql para procesar.');
    result.success = true;
    return result;
  }

  console.log(`[NODO Migraciones] 🚀 Iniciando verificación de ${migrationFiles.length} migraciones...`);

  const pool = getPool();
  const client = await pool.connect();

  try {
    // 4. Preparación de la tabla técnica _migraciones (idempotente)
    // Coincide exactamente con la definición estructural de 001_initial_schema.sql
    await client.query(`
      CREATE TABLE IF NOT EXISTS _migraciones (
        id SERIAL PRIMARY KEY,
        nombre VARCHAR(255) NOT NULL UNIQUE,
        ejecutado_en TIMESTAMPTZ NOT NULL DEFAULT NOW()
      );
    `);

    // 5. Consultar migraciones previamente ejecutadas
    const appliedResult = await client.query<{ nombre: string }>(
      'SELECT nombre FROM _migraciones ORDER BY id ASC;'
    );
    const appliedSet = new Set(appliedResult.rows.map((row) => row.nombre));

    // 6. Procesar cada archivo en orden dentro de una transacción individual
    for (const file of migrationFiles) {
      if (appliedSet.has(file)) {
        console.log(`[NODO Migraciones] ⏭️  Saltando "${file}" (ya registrada en _migraciones).`);
        result.skipped.push(file);
        continue;
      }

      console.log(`[NODO Migraciones] ⏳ Aplicando migración "${file}" dentro de transacción...`);
      const filePath = path.join(MIGRATIONS_DIR, file);
      const sqlContent = fs.readFileSync(filePath, 'utf-8');

      await client.query('BEGIN;');
      try {
        // Ejecución del script DDL
        await client.query(sqlContent);

        // Registro atómico en la tabla técnica
        await client.query('INSERT INTO _migraciones (nombre) VALUES ($1);', [file]);

        await client.query('COMMIT;');
        console.log(`[NODO Migraciones] ✅ Migración "${file}" aplicada y registrada exitosamente.`);
        result.executed.push(file);
      } catch (migrationError: any) {
        await client.query('ROLLBACK;');
        const errorMsg = `Error crítico al aplicar "${file}": ${migrationError.message}`;
        console.error(`[NODO Migraciones] ❌ ${errorMsg}`);
        result.error = errorMsg;
        result.success = false;
        return result;
      }
    }

    result.success = true;
    console.log(
      `[NODO Migraciones] 🏁 Proceso completado. Ejecutadas: ${result.executed.length}, Omitidas: ${result.skipped.length}, Total: ${result.total}.`
    );
    return result;
  } finally {
    client.release();
  }
}

// Ejecución directa por CLI (`npm run migrate` o `tsx src/db/migrate.ts`)
const isDirectExecution =
  process.argv[1] &&
  (process.argv[1].endsWith('migrate.ts') || process.argv[1].endsWith('migrate.js'));

if (isDirectExecution) {
  runMigrations()
    .then((res) => {
      if (!res.success && res.error && process.env.DATABASE_URL) {
        process.exitCode = 1;
      }
    })
    .catch((err) => {
      console.error('[NODO Migraciones] ❌ Error no controlado en ejecutor:', err);
      process.exitCode = 1;
    })
    .finally(() => {
      closePool().catch(() => {});
    });
}
