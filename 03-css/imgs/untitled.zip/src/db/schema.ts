/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * ESQUEMA DE BASE DE DATOS Y CONTRATOS DE TIPOS (PostgreSQL / Neon)
 * Proyecto NODO — Fase 2
 */

import { Question, LearningStyleScore, ThemeMascot } from '../types';

/**
 * Tabla de control de migraciones del sistema
 */
export interface DBMigracion {
  id: number;
  nombre: string;
  ejecutado_en: Date | string;
}

/**
 * Tabla: usuarios
 * Representa la entidad raíz del estudiante en la plataforma
 */
export interface DBUsuario {
  id: string; // UUID v4
  username: string;
  email: string;
  password_hash: string | null; // NULL para cuentas exclusivas de Google OAuth
  auth_provider: 'local' | 'google' | 'both';
  google_id: string | null;
  age: number;
  streak_days: number;
  last_active_date: string | null; // Formato YYYY-MM-DD
  total_xp: number;
  bits_balance: number; // Saldo formal de Bits de bienvenida (300)
  level: number;
  title: string;
  interests: string[]; // Representado como JSONB en PostgreSQL (array de temas)
  verified: boolean;
  deleted_at: Date | string | null; // Soft Delete: NULL indica cuenta activa
  created_at: Date | string;
  updated_at: Date | string;
}

/**
 * Tabla: otps_verificacion
 * Códigos de verificación temporal por correo / pantalla
 */
export interface DBOtpVerificacion {
  id: string; // UUID v4
  user_id: string; // FK -> usuarios(id)
  email: string;
  codigo_hash: string;
  proposito: 'registro_verificacion' | 'recuperacion_contrasena';
  intentos: number;
  max_intentos: number;
  expira_en: Date | string;
  usado: boolean;
  creado_en: Date | string;
}

/**
 * Tabla: perfiles_aprendizaje
 * Resultados del laboratorio cognitivo de 7 fases y clasificación bimodal
 */
export interface DBPerfilAprendizaje {
  id: string; // UUID v4
  user_id: string; // FK -> usuarios(id) [UNIQUE]
  primary_style: 'practico' | 'visual' | 'auditivo' | 'lectoescritor' | 'logico' | 'social';
  secondary_style: 'practico' | 'visual' | 'auditivo' | 'lectoescritor' | 'logico' | 'social';
  visual_percentage: number;
  auditory_percentage: number;
  is_bimodal: boolean;
  bimodal_title: string | null;
  bimodal_description: string | null;
  scores_breakdown: LearningStyleScore[];
  recommendations: string[];
  completed_at: Date | string;
}

/**
 * Tabla: diagnosticos_iniciales
 * Respuestas y plan semanal de DiagnosticWizard (4 preguntas)
 */
export interface DBDiagnosticoInicial {
  id: string; // UUID v4
  user_id: string; // FK -> usuarios(id)
  answers: string[]; // [q1, q2, q3, q4]
  experience_level: string;
  study_hours: string;
  recommended_plan: {
    overview: string;
    weeks: { title: string; target: string; focus: string }[];
  };
  created_at: Date | string;
}

/**
 * Tabla: modulos
 * Catálogo troncal de rutas formativas de NODO
 */
export interface DBModulo {
  id: string; // 'python' | 'javascript' | 'logica' | 'basesdatos' | 'algoritmos'
  title: string;
  description: string;
  unit_title: string | null;
  emoji: string;
  theme_color: string;
  accent_color: string | null;
  theme_mascot: ThemeMascot;
  orden: number;
  activo: boolean;
}

/**
 * Tabla: nodos_sendero
 * Estaciones del sendero Bézier tipo Duolingo
 */
export interface DBNodoSendero {
  id: string; // ej. 'py_lvl_1', 'py_chest_1'
  modulo_id: string; // FK -> modulos(id)
  title: string;
  node_type: 'lesson' | 'chest' | 'boss' | 'checkpoint';
  curve_offset: number; // -1, 0, 1
  order_index: number;
  reward_bits: number;
  reward_xp: number;
  question_data: Question | null;
  checkpoint_requirement: string | null;
}

/**
 * Tabla: progreso_usuario
 * Avance individual por lección y nodo
 */
export interface DBProgresoUsuario {
  id: string; // UUID v4
  user_id: string; // FK -> usuarios(id)
  modulo_id: string; // Parte de la clave foránea compuesta
  node_id: string; // FK compuesta -> nodos_sendero(id, modulo_id)
  completed: boolean;
  score: number; // 0 - 100
  stars: number; // 0, 1, 2, 3
  attempts: number;
  last_attempt_at: Date | string;
}

/**
 * Modalidad independiente de cursado de un módulo
 */
export type ModuleModality = 'offline' | 'ia';

/**
 * Tabla: progreso_modulos_usuario
 * Resumen de desempeño y estado de completitud a nivel de módulo y modalidad
 */
export interface DBProgresoModuloUsuario {
  id: string; // UUID v4
  user_id: string; // FK -> usuarios(id)
  modulo_id: string; // FK -> modulos(id)
  modality: ModuleModality; // 'offline' | 'ia'
  completed: boolean;
  score: number; // Restringido a rango 0 - 100
  level: 'Principiante' | 'Intermedio' | 'Avanzado'; // Tipado unión estricto
  completed_at: string | Date | null; // Coherente con completed (NOT NULL si completed es true)
  updated_at: Date | string;
}

/**
 * Tabla: recompensas_reclamadas
 * Registro atómico de apertura de cofres en el sendero
 */
export interface DBRecompensaReclamada {
  id: string; // UUID v4
  user_id: string; // FK -> usuarios(id)
  node_id: string; // FK -> nodos_sendero(id)
  reward_bits: number;
  reward_xp: number;
  claimed_at: Date | string;
}

/**
 * Tabla: xp_diario
 * Historial de experiencia diaria para control de racha y gráficas
 */
export interface DBXpDiario {
  id: string; // UUID v4
  user_id: string; // FK -> usuarios(id)
  date_slug: string; // YYYY-MM-DD
  xp_amount: number;
}

/**
 * Tabla: conversaciones_tutor
 * Historial conversacional pedagógico con Nodo Bot
 */
export interface DBConversacionTutor {
  id: string; // UUID v4
  user_id: string | null; // FK -> usuarios(id) ON DELETE SET NULL (anonimización)
  modulo_id: string | null;
  node_id: string | null;
  role: 'user' | 'assistant';
  content: string;
  mode: 'socratic' | 'debug' | 'challenge';
  emotion_detected: 'thinking' | 'explaining' | 'victory' | 'neutral' | null;
  created_at: Date | string;
}
