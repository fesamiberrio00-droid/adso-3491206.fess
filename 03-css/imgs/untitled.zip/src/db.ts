/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * POOL CENTRALIZADO DE CONEXIONES POSTGRESQL (Neon / pg)
 * Proyecto NODO — Fase 3
 */

import 'dotenv/config';
import pg from 'pg';

const { Pool } = pg;

// Determinación segura de la configuración SSL requerida por Neon Cloud
const databaseUrl = process.env.DATABASE_URL;
const isNeon = Boolean(databaseUrl && databaseUrl.includes('neon.tech'));
const requiresSsl = Boolean(
  isNeon || 
  process.env.NODE_ENV === 'production' || 
  (databaseUrl && databaseUrl.includes('sslmode=require'))
);

/**
 * Instancia única del pool de conexiones (Singleton).
 * Si DATABASE_URL no está configurada, el pool se instancia solo al momento
 * de requerir una conexión, evitando fallos en arranque si no hay credenciales.
 */
let poolInstance: pg.Pool | null = null;

export function getPool(): pg.Pool {
  if (!poolInstance) {
    const connectionString = process.env.DATABASE_URL;

    if (!connectionString) {
      throw new Error(
        'DATABASE_URL no está definida en las variables de entorno. ' +
        'Por favor configure DATABASE_URL en su archivo .env o en el panel de secretos.'
      );
    }

    poolInstance = new Pool({
      connectionString,
      ssl: requiresSsl ? { rejectUnauthorized: false } : undefined,
      max: 10, // Límite de conexiones simultáneas para entornos serverless
      idleTimeoutMillis: 30000, // Cerrar clientes inactivos tras 30 segundos
      connectionTimeoutMillis: 5000, // Tiempo límite para establecer conexión inicial
    });

    // Capturador de errores inesperados en clientes inactivos para prevenir caídas del servidor
    poolInstance.on('error', (err) => {
      console.error('[NODO DB] Error inesperado en cliente inactivo del pool:', err.message);
    });
  }

  return poolInstance;
}

/**
 * Función centralizada para ejecutar consultas parametrizadas.
 * Garantiza el uso del pool y previene inyecciones SQL mediante parámetros tipados.
 */
export async function query<T extends pg.QueryResultRow = any>(
  text: string,
  params?: any[]
): Promise<pg.QueryResult<T>> {
  const pool = getPool();
  return pool.query<T>(text, params);
}

/**
 * Comprueba el estado de la conexión contra PostgreSQL sin exponer credenciales.
 */
export async function testConnection(): Promise<{
  ok: boolean;
  message: string;
  serverTime?: string;
}> {
  if (!process.env.DATABASE_URL) {
    return {
      ok: false,
      message: 'DATABASE_URL no configurada en el entorno.',
    };
  }

  let client: pg.PoolClient | null = null;
  try {
    const pool = getPool();
    client = await pool.connect();
    const result = await client.query('SELECT NOW() AS server_time, current_database() AS db_name');
    const row = result.rows[0];
    return {
      ok: true,
      message: `Conexión exitosa a la base de datos "${row.db_name}".`,
      serverTime: row.server_time,
    };
  } catch (error: any) {
    return {
      ok: false,
      message: `Fallo al conectar con la base de datos: ${error?.message || String(error)}`,
    };
  } finally {
    if (client) {
      client.release();
    }
  }
}

/**
 * Cierre controlado del pool de conexiones para apagados limpios (graceful shutdown).
 */
export async function closePool(): Promise<void> {
  if (poolInstance) {
    await poolInstance.end();
    poolInstance = null;
  }
}

export default {
  getPool,
  query,
  testConnection,
  closePool,
};
