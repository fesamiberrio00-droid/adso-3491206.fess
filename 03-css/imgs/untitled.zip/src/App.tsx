import React, { useState, useEffect, useRef } from 'react';
import { 
  CheckCircle2, 
  ArrowRight, 
  Sparkles, 
  Code, 
  Check, 
  Award,
  BookOpen,
  Zap,
  Terminal,
  Brain,
  Volume2,
  VolumeX,
  LogOut,
  UserPlus,
  Sun,
  Moon,
  Flame,
  Trophy,
  Map,
  LayoutGrid,
  Compass,
  Menu,
  X,
  PanelRightClose,
  PanelRightOpen,
  Sidebar,
  MessageSquare,
  Bot
} from 'lucide-react';
import { STATIC_MODULES } from './data';
import { STATIC_ROADMAPS } from './data/roadmapsData';
import { Question, UserProfile, Module, LearningStyleResult, ModuleRoadmap, RoadmapNode, ModuleModality } from './types';
import SenaHelper from './components/SenaHelper';
import DiagnosticWizard from './components/DiagnosticWizard';
import LearningStyleAssessment from './components/LearningStyleAssessment';
import TutorDrawer from './components/TutorDrawer';
import NodoLogo from './components/NodoLogo';
import NodoTutorAvatar from './components/NodoTutorAvatar';
import DuolingoCompletionModal from './components/DuolingoCompletionModal';
import PathRoadmap from './components/PathRoadmap';
import ParsonsExercise, { ParsonsBlock } from './components/ParsonsExercise';
import LogicAnalysisExercise from './components/LogicAnalysisExercise';
import VisualCodeFlow from './components/VisualCodeFlow';
import { audioFx } from './utils/audioEffects';

// Synthesizer sounds for game experience using Web Audio API
const playSound = (type: 'success' | 'fail' | 'levelUp' | 'click' | 'correct' | 'error' | 'hint' | 'victory') => {
  if (type === 'success' || type === 'correct') {
    audioFx.play('correct');
  } else if (type === 'fail' || type === 'error') {
    audioFx.play('error');
  } else if (type === 'levelUp' || type === 'victory') {
    audioFx.play('victory');
  } else if (type === 'hint') {
    audioFx.play('hint');
  } else {
    audioFx.play('click');
  }
};

export default function App() {
  const [view, setView] = useState<'welcome' | 'verify' | 'diagnostic' | 'learning-style' | 'app'>('welcome');
  const [activeTab, setActiveTab] = useState<'aprender' | 'practica' | 'lideres'>('aprender');
  
  // Dark Mode State with persistent storage and system theme detection
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    try {
      const stored = localStorage.getItem('nodo_dark_mode');
      if (stored !== null) return stored === 'true';
      return window.matchMedia('(prefers-color-scheme: dark)').matches;
    } catch {
      return false;
    }
  });

  useEffect(() => {
    try {
      if (darkMode) {
        document.documentElement.classList.add('dark');
        localStorage.setItem('nodo_dark_mode', 'true');
      } else {
        document.documentElement.classList.remove('dark');
        localStorage.setItem('nodo_dark_mode', 'false');
      }
    } catch {}
  }, [darkMode]);

  // Learning Style Diagnostic State (Scoped per active user, starts clean for new registrants)
  const [learningStyleResult, setLearningStyleResult] = useState<LearningStyleResult | null>(null);

  // Clean up any stale un-scoped cache from previous sessions on mount
  useEffect(() => {
    try {
      localStorage.removeItem('nodo_learning_style');
      localStorage.removeItem('nodo_current_user');
    } catch {}
  }, []);

  // Auth Form State
  const [authMode, setAuthMode] = useState<'register' | 'login'>('register');
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [age, setAge] = useState<number>(20);
  const [password, setPassword] = useState('');
  const [verificationCode, setVerificationCode] = useState('');
  const [inputCode, setInputCode] = useState('');
  const [authError, setAuthError] = useState('');
  const [otpInfoMessage, setOtpInfoMessage] = useState('');
  const [otpCooldownSeconds, setOtpCooldownSeconds] = useState(0);
  const [resendLoading, setResendLoading] = useState(false);
  const [pendingAccountPrompt, setPendingAccountPrompt] = useState<{ source: 'register' | 'login'; email: string } | null>(null);
  const [resendPasswordPrompt, setResendPasswordPrompt] = useState(false);
  const [resendPasswordInput, setResendPasswordInput] = useState('');
  const [authLoading, setAuthLoading] = useState(false);
  const [diagnosticError, setDiagnosticError] = useState('');
  const [profileSyncError, setProfileSyncError] = useState('');
  const [progressSaveError, setProgressSaveError] = useState('');
  const [progressSaving, setProgressSaving] = useState(false);
  const diagnosticInFlightRef = useRef<boolean>(false);
  const progressSaveInFlightRef = useRef<boolean>(false);

  // Temporizador de cooldown (60s) para reenvío seguro de OTP
  useEffect(() => {
    if (otpCooldownSeconds <= 0) return;
    const timer = setInterval(() => {
      setOtpCooldownSeconds(prev => (prev > 1 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(timer);
  }, [otpCooldownSeconds]);

  // User Session State
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [sessionToken, setSessionToken] = useState<string>('');

  const getAuthHeaders = (): Record<string, string> => ({
    'Content-Type': 'application/json',
    ...(sessionToken ? { Authorization: `Bearer ${sessionToken}` } : {})
  });

  // Active Training Modules
  const [activeModule, setActiveModule] = useState<Module | null>(null);
  const [activeQuestions, setActiveQuestions] = useState<Question[]>([]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedOptionId, setSelectedOptionId] = useState<string | null>(null);
  const [codingAnswer, setCodingAnswer] = useState('');
  const [isAnswerChecked, setIsAnswerChecked] = useState(false);
  const [isAnswerCorrect, setIsAnswerCorrect] = useState(false);
  const [activeSenaMood, setActiveSenaMood] = useState<'neutral' | 'happy' | 'thinking' | 'victory' | 'sad'>('neutral');
  const [moduleFinished, setModuleFinished] = useState(false);
  const [isAIGenerated, setIsAIGenerated] = useState(false);
  const [activeLessonMode, setActiveLessonMode] = useState<ModuleModality>('offline');
  
  // Scoring indicators
  const [rightAnswersCount, setRightAnswersCount] = useState(0);
  const [gainedXPThisSession, setGainedXPThisSession] = useState(0);
  const [sessionBitsGained, setSessionBitsGained] = useState(0);
  const [feedbackText, setFeedbackText] = useState('');
  const [generateLoading, setGenerateLoading] = useState(false);

  // Store variables
  const [bits, setBits] = useState(300); // Saldo de Bits de Computación 💻
  const [purchasedDoubleXP, setPurchasedDoubleXP] = useState(false);

  // Live Coding Test Output State
  const [testResults, setTestResults] = useState<{ id: string; input: string; passed: boolean; got: string; expected: string }[]>([]);

  // Adaptive interactive challenge states
  const [parsonsOrder, setParsonsOrder] = useState<string[]>([]);
  const [selectedBugLine, setSelectedBugLine] = useState<number | null>(null);
  const [showCelebrationModal, setShowCelebrationModal] = useState<boolean>(false);

  // Path Roadmap State (Duolingo Style System)
  const [roadmapModuleId, setRoadmapModuleId] = useState<string>('python');
  const [roadmapViewMode, setRoadmapViewMode] = useState<'roadmap' | 'grid'>('roadmap');
  const [roadmapWithAI, setRoadmapWithAI] = useState<boolean>(false);
  const [isLoadingRoadmapAI, setIsLoadingRoadmapAI] = useState<boolean>(false);
  const [activeRoadmapNode, setActiveRoadmapNode] = useState<{ moduleId: string; node: RoadmapNode } | null>(null);
  const [claimedRoadmapNodes, setClaimedRoadmapNodes] = useState<Record<string, boolean>>({});
  const chestClaimInFlightRef = useRef<boolean>(false);
  const [roadmapsData, setRoadmapsData] = useState<Record<string, ModuleRoadmap>>(STATIC_ROADMAPS);

  useEffect(() => {
    if (!activeModule) {
      setActiveRoadmapNode(null);
    }
  }, [activeModule]);

  // AI Professor Adaptation State
  const [aiProfesorMessage, setAiProfesorMessage] = useState<string>('');
  const [adaptedStyleName, setAdaptedStyleName] = useState<string>('');
  const [adaptedStyleIcon, setAdaptedStyleIcon] = useState<string>('');
  const [isQuestionSpeaking, setIsQuestionSpeaking] = useState<boolean>(false);
  
  // Interactive AI Tutor Left Menu State
  const [isTutorOpen, setIsTutorOpen] = useState<boolean>(false);

  // Layout Sidebar & Right Panel State
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState<boolean>(false);
  const [showRightPanel, setShowRightPanel] = useState<boolean>(true);

  // Auditory learner speech synthesis
  const toggleQuestionSpeech = (q: Question) => {
    if (isQuestionSpeaking) {
      audioFx.stopSpeaking();
      setIsQuestionSpeaking(false);
      return;
    }

    const textToSpeak = q.speechText 
      ? q.speechText 
      : `${q.title}. ${q.description}. ${q.type === 'multiple_choice' && q.options ? `Opciones disponibles: ${q.options.map(o => `Opción ${o.id}: ${o.text}`).join('. ')}.` : ''} ${q.audioTip ? `Consejo auditivo: ${q.audioTip}` : ''}`;

    setIsQuestionSpeaking(true);
    audioFx.speak(
      textToSpeak,
      () => setIsQuestionSpeaking(false),
      () => setIsQuestionSpeaking(true)
    );
  };

  useEffect(() => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      setIsQuestionSpeaking(false);
    }
  }, [currentQuestionIndex, activeModule]);

  // Leaderboard Simulation
  const [leaderboard, setLeaderboard] = useState([
    { name: 'Ana Patricia (Dev)', xp: 1450, avatar: 'bg-[#007832] text-white' },
    { name: 'Marcos R. (Full-Stack)', xp: 980, avatar: 'bg-[#71277a] text-white' },
    { name: 'Sofía Gómez (Frontend)', xp: 600, avatar: 'bg-[#fdc300] text-[#00324D]' },
    { name: 'Daniel_Dev (Backend)', xp: 420, avatar: 'bg-[#00324D] text-white' },
    { name: 'Tú', xp: 50, avatar: 'bg-[#39a900] font-black text-white' }
  ]);

  // Synchronize leaderboard with real score
  useEffect(() => {
    if (profile) {
      const updated = [
        { name: 'Ana Patricia (Dev)', xp: 1450, avatar: 'bg-[#007832] text-white' },
        { name: 'Marcos R. (Full-Stack)', xp: 980, avatar: 'bg-[#71277a] text-white' },
        { name: 'Sofía Gómez (Frontend)', xp: 600, avatar: 'bg-[#fdc300] text-[#00324D]' },
        { name: 'Daniel_Dev (Backend)', xp: 420, avatar: 'bg-[#00324D] text-white' },
        { name: 'Tú', xp: profile.totalXP, avatar: 'bg-[#39a900] font-black text-white' }
      ].sort((a, b) => b.xp - a.xp);
      setLeaderboard(updated);
    }
  }, [profile?.totalXP]);

  // Protección defensiva: impedir vista 'app' o 'diagnostic' sin sesión activa
  useEffect(() => {
    if (!profile && (view === 'app' || view === 'diagnostic')) {
      setActiveModule(null);
      setView('welcome');
    }
  }, [profile, view]);

  // Reset session and form to cleanly log out or switch user
  const handleLogout = () => {
    playSound('click');
    setProfile(null);
    setSessionToken('');
    setLearningStyleResult(null);
    setIsTutorOpen(false);
    setUsername('');
    setEmail('');
    setPassword('');
    setInputCode('');
    setVerificationCode('');
    setAuthError('');
    setOtpInfoMessage('');
    setOtpCooldownSeconds(0);
    setPendingAccountPrompt(null);
    setResendPasswordPrompt(false);
    setResendPasswordInput('');
    setDiagnosticError('');
    setProfileSyncError('');
    setProgressSaveError('');
    setProgressSaving(false);
    setActiveLessonMode('offline');
    setActiveRoadmapNode(null);
    setClaimedRoadmapNodes({});
    setSessionBitsGained(0);
    setBits(300);
    diagnosticInFlightRef.current = false;
    progressSaveInFlightRef.current = false;
    chestClaimInFlightRef.current = false;
    try {
      localStorage.removeItem('nodo_current_user');
    } catch {}
    setActiveModule(null);
    setView('welcome');
    setAuthMode('login');
  };

  // Regresar desde la verificación OTP al login limpiando estados temporales de OTP y errores
  const handleReturnToLoginFromOtp = () => {
    playSound('click');
    setInputCode('');
    setVerificationCode('');
    setAuthError('');
    setOtpInfoMessage('');
    setPendingAccountPrompt(null);
    setResendPasswordPrompt(false);
    setResendPasswordInput('');
    setPassword('');
    setActiveModule(null);
    setAuthMode('login');
    setView('welcome');
  };

  // Navegación controlada al hacer clic en el logo NODO
  const handleLogoClick = () => {
    playSound('click');

    // Sin sesión activa: regresar siempre al login/bienvenida sin pantalla en blanco
    if (!profile) {
      setActiveModule(null);
      setInputCode('');
      setVerificationCode('');
      setAuthError('');
      setOtpInfoMessage('');
      setPendingAccountPrompt(null);
      setResendPasswordPrompt(false);
      setResendPasswordInput('');
      setPassword('');
      setAuthMode('login');
      setView('welcome');
      return;
    }

    // Durante el diagnóstico inicial obligatorio: impedir saltarse el diagnóstico mediante el logo
    if (view === 'diagnostic') {
      setDiagnosticError('Completa tu diagnóstico inicial antes de ingresar al panel principal de NODO.');
      return;
    }

    // Con sesión activa: cerrar módulo activo y volver al panel principal
    setActiveModule(null);
    setView('app');
  };

  // Switch to register mode and guarantee a 100% fresh learning style test
  const handleSwitchToRegister = () => {
    playSound('click');
    setAuthMode('register');
    setAuthError('');
    setOtpInfoMessage('');
    setPendingAccountPrompt(null);
    setResendPasswordPrompt(false);
    setResendPasswordInput('');
    setSessionToken('');
    setLearningStyleResult(null);
    setUsername('');
    setEmail('');
    setPassword('');
    setInputCode('');
    setVerificationCode('');
  };

  // Register Handler
  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim() || !email.trim() || !password) {
      setAuthError('Por favor completa todos los campos.');
      return;
    }
    if (password.length < 8) {
      setAuthError('La contraseña debe tener al menos 8 caracteres.');
      return;
    }
    if (new TextEncoder().encode(password).length > 72) {
      setAuthError('La contraseña no debe superar los 72 bytes.');
      return;
    }
    setAuthError('');
    setOtpInfoMessage('');
    setPendingAccountPrompt(null);
    setResendPasswordPrompt(false);
    setResendPasswordInput('');
    setAuthLoading(true);
    playSound('click');

    // Reset learning style state for this brand-new registrant
    setLearningStyleResult(null);

    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          nombre: username, 
          correo: email, 
          edad: age, 
          password,
          learningStyleProfile: null // Brand new user has not completed the learning test yet
        })
      });
      const data = await res.json();
      if (!res.ok) {
        setAuthError(data.error || 'Ocurrió un error al registrar.');
        if (data.code === 'ACCOUNT_PENDING_VERIFICATION') {
          setPendingAccountPrompt({
            source: 'register',
            email: (data.email || email).trim().toLowerCase()
          });
        }
      } else {
        setVerificationCode(typeof data.code === 'string' ? data.code : '');
        setInputCode('');
        setOtpCooldownSeconds(60);
        setOtpInfoMessage('Código OTP generado (vigencia de 15 minutos, máximo 5 intentos).');
        setView('verify');
      }
    } catch(err) {
      setAuthError('Error conectando al servidor de Nodo.');
    } finally {
      setAuthLoading(false);
    }
  };

  // Reenvío seguro de OTP previa validación de contraseña y cooldown de 60s
  const handleResendOtp = async (explicitPassword?: string) => {
    const targetEmail = (email || pendingAccountPrompt?.email || '').trim().toLowerCase();
    const passwordToVerify = explicitPassword !== undefined ? explicitPassword : password;

    if (!targetEmail) {
      setAuthError('No se encontró el correo electrónico para reenviar el código OTP.');
      return;
    }

    if (!passwordToVerify) {
      setResendPasswordPrompt(true);
      setAuthError('Por seguridad, introduce tu contraseña original para solicitar un nuevo código OTP.');
      return;
    }

    setAuthError('');
    setOtpInfoMessage('');
    setResendLoading(true);
    playSound('click');

    try {
      const res = await fetch('/api/auth/resend-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ correo: targetEmail, password: passwordToVerify })
      });
      const data = await res.json().catch(() => ({}));

      if (!res.ok) {
        if (typeof data.retryAfterSeconds === 'number') {
          setOtpCooldownSeconds(data.retryAfterSeconds);
        }
        if (data.code === 'PASSWORD_REQUIRED_FOR_RESEND' || data.code === 'INVALID_CREDENTIALS') {
          setResendPasswordPrompt(true);
        }
        setAuthError(data.error || 'No se pudo reenviar el código OTP.');
        return;
      }

      if (explicitPassword !== undefined) {
        setPassword(passwordToVerify);
      }
      setEmail(targetEmail);
      setVerificationCode(typeof data.code === 'string' ? data.code : '');
      setInputCode('');
      setPendingAccountPrompt(null);
      setResendPasswordPrompt(false);
      setResendPasswordInput('');
      setOtpCooldownSeconds(typeof data.cooldownSeconds === 'number' ? data.cooldownSeconds : 60);
      setOtpInfoMessage('Se emitió un nuevo código OTP válido por 15 minutos. El código anterior quedó invalidado.');
      setView('verify');
    } catch {
      setAuthError('Error de red al solicitar un nuevo código OTP.');
    } finally {
      setResendLoading(false);
    }
  };

  // Verification code validation
  const handleVerifySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    setOtpInfoMessage('');
    setAuthLoading(true);
    playSound('click');

    try {
      const res = await fetch('/api/auth/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ correo: email, codigo: inputCode })
      });
      const data = await res.json();
      if (!res.ok) {
        setAuthError(data.error || 'Código de verificación incorrecto.');
      } else if (password) {
        await handleAutoLogin();
      } else {
        setInputCode('');
        setVerificationCode('');
        setPendingAccountPrompt(null);
        setResendPasswordPrompt(false);
        setResendPasswordInput('');
        setAuthMode('login');
        setView('welcome');
        setOtpInfoMessage('¡Cuenta verificada con éxito! Ahora introduce tu contraseña para iniciar sesión.');
      }
    } catch (err) {
      setAuthError('Error de red al procesar el código.');
    } finally {
      setAuthLoading(false);
    }
  };

  // Auto Login action
  const handleAutoLogin = async () => {
    if (!password) {
      setInputCode('');
      setVerificationCode('');
      setPendingAccountPrompt(null);
      setAuthMode('login');
      setView('welcome');
      setOtpInfoMessage('¡Cuenta verificada con éxito! Introduce tu contraseña para iniciar sesión.');
      return;
    }

    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ correo: email, password })
      });
      const data = await res.json();
      if (res.ok) {
        setProfile(data.user);
        setSessionToken(data.sessionToken || '');
        setBits(typeof data.user?.tokens === 'number' ? data.user.tokens : 300);
        setClaimedRoadmapNodes(data.user?.claimedNodes || {});
        setPendingAccountPrompt(null);
        setOtpInfoMessage('');
        // PostgreSQL es la fuente autoritativa del perfil cognitivo
        const userStyle = data.user.learningStyleProfile || null;
        setLearningStyleResult(userStyle);
        setProfileSyncError('');
        setDiagnosticError('');
        setProgressSaveError('');
        try {
          const cacheKey = `nodo_learning_style_${data.user.email.toLowerCase()}`;
          if (userStyle) {
            localStorage.setItem(cacheKey, JSON.stringify(userStyle));
          } else {
            localStorage.removeItem(cacheKey);
          }
        } catch {}
        setView('diagnostic');
      } else {
        setAuthError('Cuenta verificada. Inicia sesión con tus credenciales para continuar.');
        setAuthMode('login');
        setView('welcome');
      }
    } catch (e) {
      setAuthError('Error de red.');
      setAuthMode('login');
      setView('welcome');
    }
  };

  // Direct Login handle
  const handleDirectLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !password) {
      setAuthError('Introduce correo y contraseña.');
      return;
    }
    if (new TextEncoder().encode(password).length > 72) {
      setAuthError('La contraseña excede el límite máximo permitido de 72 bytes.');
      return;
    }
    setAuthError('');
    setOtpInfoMessage('');
    setPendingAccountPrompt(null);
    setDiagnosticError('');
    setProfileSyncError('');
    setAuthLoading(true);
    playSound('click');

    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ correo: email, password })
      });
      const data = await res.json();
      if (!res.ok) {
        setAuthError(data.error || 'No fue posible iniciar sesión.');
        if (res.status === 403 && data.code === 'ACCOUNT_PENDING_VERIFICATION') {
          setEmail((data.email || email).trim().toLowerCase());
          setOtpCooldownSeconds(
            typeof data.cooldownRemainingSeconds === 'number' ? data.cooldownRemainingSeconds : 0
          );
          setPendingAccountPrompt({
            source: 'login',
            email: (data.email || email).trim().toLowerCase()
          });
        }
      } else {
        setProfile(data.user);
        setSessionToken(data.sessionToken || '');
        setBits(typeof data.user?.tokens === 'number' ? data.user.tokens : 300);
        setClaimedRoadmapNodes(data.user?.claimedNodes || {});
        // Usar estrictamente la información autoritativa de Neon PostgreSQL (sin resucitar caché obsoleto)
        const userStyle = data.user.learningStyleProfile || null;
        setLearningStyleResult(userStyle);
        try {
          const cacheKey = `nodo_learning_style_${data.user.email.toLowerCase()}`;
          if (userStyle) {
            localStorage.setItem(cacheKey, JSON.stringify(userStyle));
          } else {
            localStorage.removeItem(cacheKey);
          }
        } catch {}
        if (data.user.recommendedPlan) {
          setView('app');
        } else {
          setView('diagnostic');
        }
      }
    } catch (err) {
      setAuthError('Credenciales erróneas o servidor inactivo.');
    } finally {
      setAuthLoading(false);
    }
  };

  // Diagnostic questionnaire parsing
  const handleDiagnosticComplete = async (answers: string[]) => {
    const activeEmail = (profile?.email || email || '').trim();
    if (!activeEmail || diagnosticInFlightRef.current) return;

    diagnosticInFlightRef.current = true;
    setDiagnosticError('');
    setAuthLoading(true);
    playSound('click');

    try {
      const res = await fetch('/api/diagnostico/analizar', {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify({ email: activeEmail, respuestas: answers })
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        setDiagnosticError(data.error || 'No se pudo guardar tu diagnóstico en Neon PostgreSQL. Por favor intenta de nuevo.');
        return;
      }

      const updatedInterests = Array.isArray(data.interests) ? data.interests : undefined;
      setProfile(prev => prev ? {
        ...prev,
        recommendedPlan: data.perfil,
        interests: updatedInterests ?? prev.interests
      } : null);

      // Conservar el perfil cognitivo existente si el estudiante ya contaba con uno
      setLearningStyleResult(prev => prev || profile?.learningStyleProfile || null);
      setView('learning-style');
      playSound('levelUp');
    } catch (err) {
      setDiagnosticError('Error de conexión al guardar tu diagnóstico en el servidor. Verifica tu red e inténtalo de nuevo.');
    } finally {
      diagnosticInFlightRef.current = false;
      setAuthLoading(false);
    }
  };

  // Reset exercise state
  const resetQuizEnvironment = () => {
    setSelectedOptionId(null);
    setCodingAnswer('');
    setSelectedBugLine(null);
    setParsonsOrder([]);
    setIsAnswerChecked(false);
    setIsAnswerCorrect(false);
    setFeedbackText('');
    setTestResults([]);
  };

  // Launch Module Lesson: Modo Estándar (Offline preestablecidas) o Modo IA (Generación dinámica adaptada)
  const handleStartModule = async (module: Module, withAI: boolean = true) => {
    playSound('click');
    setActiveRoadmapNode(null);
    setActiveModule(module);
    setActiveLessonMode(withAI ? 'ia' : 'offline');
    resetQuizEnvironment();
    setProgressSaveError('');
    progressSaveInFlightRef.current = false;
    setRightAnswersCount(0);
    setModuleFinished(false);
    setGainedXPThisSession(0);
    setSessionBitsGained(0);
    setCurrentQuestionIndex(0);

    // MODO ESTÁNDAR: Preguntas 100% preestablecidas del currículo oficial (sin conexión a IA)
    if (!withAI) {
      setIsAIGenerated(false);
      setActiveQuestions(module.questions);
      setAiProfesorMessage('Modo Estándar sin conexión: Practica con el banco de preguntas oficial y preestablecido de Nodo.');
      setAdaptedStyleName('Currículo Estándar');
      setAdaptedStyleIcon('📘');
      if (module.questions[0]?.initialCode) {
        setCodingAnswer(module.questions[0].initialCode);
      }
      if (module.questions[0]?.type === 'parsons' && module.questions[0].parsonsBlocks) {
        setParsonsOrder(module.questions[0].parsonsBlocks.map(b => b.id));
      }
      setActiveSenaMood('neutral');
      setGenerateLoading(false);
      return;
    }

    // MODO CON IA: Generación dinámica adaptada al perfil del usuario
    setGenerateLoading(true);
    setActiveSenaMood('thinking');
    setAiProfesorMessage('Generando lección adaptada con Inteligencia Artificial...');

    try {
      const activeStyleProfile = profile?.learningStyleProfile || learningStyleResult;
      const res = await fetch(`/api/modulo/${module.id}/generar-preguntas-ia`, {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify({
          email: profile?.email,
          learningStyleProfile: activeStyleProfile
        })
      });
      const data = await res.json();
      if (res.ok && data.preguntas && data.preguntas.length > 0) {
        setIsAIGenerated(Boolean(data.generado_por_ia));
        setActiveQuestions(data.preguntas);
        setAiProfesorMessage(data.profesorAdvice || '');
        setAdaptedStyleName(data.estiloAdaptado || '');
        setAdaptedStyleIcon(data.estiloIcon || '⚡');
        if (data.preguntas[0]?.initialCode) {
          setCodingAnswer(data.preguntas[0].initialCode);
        }
        if (data.preguntas[0]?.type === 'parsons' && data.preguntas[0].parsonsBlocks) {
          setParsonsOrder(data.preguntas[0].parsonsBlocks.map((b: { id: string }) => b.id));
        }
        setActiveSenaMood('happy');
        setGenerateLoading(false);
        return;
      }
    } catch (e) {
      console.warn("Fallo cargando IA, iniciando fallback de inmediato.");
    }

    // Fallback if AI endpoint failed
    setIsAIGenerated(false);
    setActiveQuestions(module.questions);
    if (module.questions[0]?.initialCode) {
      setCodingAnswer(module.questions[0].initialCode);
    }
    if (module.questions[0]?.type === 'parsons' && module.questions[0].parsonsBlocks) {
      setParsonsOrder(module.questions[0].parsonsBlocks.map(b => b.id));
    }
    setActiveSenaMood('neutral');
    setGenerateLoading(false);
  };

  // Toggle AI Generation for Roadmap
  const handleToggleRoadmapAI = async (enabled: boolean) => {
    playSound('click');
    setRoadmapWithAI(enabled);
    if (!enabled) {
      if (STATIC_ROADMAPS[roadmapModuleId]) {
        setRoadmapsData(prev => ({
          ...prev,
          [roadmapModuleId]: STATIC_ROADMAPS[roadmapModuleId]
        }));
      }
      return;
    }

    setIsLoadingRoadmapAI(true);
    try {
      const res = await fetch(`/api/modulo/${roadmapModuleId}/roadmap`, {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify({
          email: profile?.email,
          generateWithAI: true,
          learningStyleProfile: profile?.learningStyleProfile || learningStyleResult
        })
      });
      if (res.ok) {
        const data = await res.json();
        if (data && data.roadmap && data.roadmap.nodes) {
          setRoadmapsData(prev => ({
            ...prev,
            [roadmapModuleId]: data
          }));
        }
      }
    } catch (err) {
      console.warn("Fallo cargando roadmap dinámico con IA:", err);
    } finally {
      setIsLoadingRoadmapAI(false);
    }
  };

  // Claim Chest Reward on the Path (confirmado por Neon PostgreSQL - recompensas_reclamadas)
  const handleClaimRoadmapChest = async (
    nodeId: string,
    rewardBits: number,
    rewardXP: number
  ): Promise<{ ok: boolean; error?: string; rewardBits?: number; rewardXP?: number }> => {
    if (!profile?.email) {
      return { ok: false, error: 'Debes iniciar sesión para reclamar recompensas.' };
    }
    if (chestClaimInFlightRef.current) {
      return { ok: false, error: 'Ya hay un reclamo de cofre en proceso.' };
    }

    chestClaimInFlightRef.current = true;
    try {
      const res = await fetch(`/api/modulo/${roadmapModuleId}/roadmap/claim-node`, {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify({
          email: profile.email,
          nodeId
        })
      });
      const data = await res.json().catch(() => ({}));

      if (!res.ok || !data?.success || !data?.user) {
        if (res.status === 409 || data?.alreadyClaimed) {
          setClaimedRoadmapNodes(prev => ({ ...prev, [nodeId]: true }));
        }
        return {
          ok: false,
          error: data?.error || 'No se pudo reclamar el cofre en Neon PostgreSQL.'
        };
      }

      playSound('levelUp');

      const persistedClaimed = data.user.claimedNodes || { ...claimedRoadmapNodes, [nodeId]: true };
      const persistedTokens = typeof data.user.tokens === 'number'
        ? data.user.tokens
        : (typeof data.user.bitsBalance === 'number' ? data.user.bitsBalance : bits);

      setClaimedRoadmapNodes(persistedClaimed);
      setBits(persistedTokens);
      setProfile(prev => prev ? {
        ...prev,
        totalXP: data.user.totalXP,
        points: data.user.totalXP,
        tokens: persistedTokens,
        level: data.user.level,
        title: data.user.title,
        streakDays: data.user.streakDays,
        streak: data.user.streakDays,
        xpDays: data.user.xpDays || prev.xpDays,
        roadmapProgress: data.user.roadmapProgress || prev.roadmapProgress,
        claimedNodes: persistedClaimed
      } : null);

      return {
        ok: true,
        rewardBits: typeof data.rewardBits === 'number' ? data.rewardBits : rewardBits,
        rewardXP: typeof data.rewardXP === 'number' ? data.rewardXP : rewardXP
      };
    } catch {
      return {
        ok: false,
        error: 'Error de conexión al intentar reclamar el cofre en PostgreSQL.'
      };
    } finally {
      chestClaimInFlightRef.current = false;
    }
  };

  // Launch lesson from specific Roadmap Node
  const handleStartRoadmapNode = async (node: RoadmapNode, withAI: boolean) => {
    playSound('click');
    const matchedModule = STATIC_MODULES.find(m => m.id === roadmapModuleId) || STATIC_MODULES[0];
    setActiveModule(matchedModule);
    setActiveLessonMode(withAI ? 'ia' : 'offline');
    resetQuizEnvironment();
    setProgressSaveError('');
    progressSaveInFlightRef.current = false;
    setRightAnswersCount(0);
    setModuleFinished(false);
    setGainedXPThisSession(0);
    setSessionBitsGained(0);
    setCurrentQuestionIndex(0);

    if (node.question) {
      setActiveRoadmapNode({ moduleId: roadmapModuleId, node });

      if (!withAI) {
        setIsAIGenerated(false);
        setActiveQuestions([node.question]);
        setAiProfesorMessage(`Nivel: ${node.title}. Desafío interactivo adaptado para ${profile?.username || 'el estudiante'}. Recompensa: +${node.rewardXP} XP y +${node.rewardBits} Bits.`);
        setAdaptedStyleName(learningStyleResult?.primaryStyle.name || 'Estándar');
        setAdaptedStyleIcon(learningStyleResult?.primaryStyle.icon || '📘');
        if (node.question.type === 'coding' && node.question.initialCode) {
          setCodingAnswer(node.question.initialCode);
        }
        if (node.question.type === 'parsons' && node.question.parsonsBlocks) {
          setParsonsOrder(node.question.parsonsBlocks.map(b => b.id));
        }
        setActiveSenaMood('neutral');
        setGenerateLoading(false);
        return;
      }

      setGenerateLoading(true);
      setActiveSenaMood('thinking');
      setAiProfesorMessage(`Generando reto adaptado con Inteligencia Artificial para el nodo "${node.title}"...`);
      try {
        const activeStyleProfile = profile?.learningStyleProfile || learningStyleResult;
        const res = await fetch(`/api/modulo/${roadmapModuleId}/generar-preguntas-ia`, {
          method: 'POST',
          headers: getAuthHeaders(),
          body: JSON.stringify({
            email: profile?.email,
            learningStyleProfile: activeStyleProfile,
            nodeTitle: node.title
          })
        });
        const data = await res.json();
        if (res.ok && data.preguntas && data.preguntas.length > 0) {
          setIsAIGenerated(Boolean(data.generado_por_ia));
          setActiveQuestions(data.preguntas);
          setAiProfesorMessage(data.profesorAdvice || `Reto generado por IA para ${node.title}`);
          setAdaptedStyleName(data.estiloAdaptado || '');
          setAdaptedStyleIcon(data.estiloIcon || '⚡');
          if (data.preguntas[0]?.initialCode) {
            setCodingAnswer(data.preguntas[0].initialCode);
          }
          if (data.preguntas[0]?.type === 'parsons' && data.preguntas[0].parsonsBlocks) {
            setParsonsOrder(data.preguntas[0].parsonsBlocks.map((b: { id: string }) => b.id));
          }
          setActiveSenaMood('happy');
          setGenerateLoading(false);
          return;
        }
      } catch (err) {
        console.warn("Fallo cargando pregunta IA del nodo:", err);
      }

      // Fallback to node.question
      setIsAIGenerated(false);
      setActiveQuestions([node.question]);
      if (node.question.initialCode) setCodingAnswer(node.question.initialCode);
      if (node.question.type === 'parsons' && node.question.parsonsBlocks) {
        setParsonsOrder(node.question.parsonsBlocks.map(b => b.id));
      }
      setActiveSenaMood('neutral');
      setGenerateLoading(false);
    } else {
      handleStartModule(matchedModule, withAI);
    }
  };

  // Update dynamic question values
  useEffect(() => {
    const q = activeQuestions[currentQuestionIndex];
    if (q) {
      if (q.type === 'coding' && q.initialCode) {
        setCodingAnswer(q.initialCode);
      } else {
        setCodingAnswer('');
      }
      if (q.type === 'parsons' && q.parsonsBlocks) {
        setParsonsOrder(q.parsonsBlocks.map(b => b.id));
      } else {
        setParsonsOrder([]);
      }
      setSelectedBugLine(null);
      setSelectedOptionId(null);
      setIsAnswerChecked(false);
      setIsAnswerCorrect(false);
      setFeedbackText('');
      setTestResults([]);
      setActiveSenaMood('neutral');
    }
  }, [currentQuestionIndex, activeQuestions]);

  // Helper to accurately compare multiple-choice option against correctOptionId
  const isOptionDesignatedCorrect = (
    opt: { id: string; text: string },
    correctOptionId?: string
  ): boolean => {
    if (!correctOptionId) return false;
    const rawTarget = String(correctOptionId).trim();
    // Normalize both: strip "opción", dots, parentheses, whitespace
    const cleanTargetId = rawTarget.replace(/^(opci[oó]n\s*)/i, '').replace(/[\.\)\:\s]/g, '').toUpperCase();
    const cleanOptId = opt.id.replace(/[\.\)\:\s]/g, '').toUpperCase();

    // 1. Direct or normalized letter match (e.g. 'A' === 'A', 'opcion B' === 'B')
    if (cleanTargetId && cleanOptId && cleanTargetId === cleanOptId) {
      return true;
    }
    if (opt.id.trim().toUpperCase() === rawTarget.toUpperCase()) {
      return true;
    }
    // 2. Text match (if AI returned option text as correctOptionId)
    if (opt.text.trim().toLowerCase() === rawTarget.toLowerCase()) {
      return true;
    }
    return false;
  };

  // Helper to normalize values for unit test comparison
  const normalizeForComparison = (val: any) => {
    if (val === undefined) return 'undefined';
    if (val === null) return 'null';
    let str = typeof val === 'object' ? JSON.stringify(val) : String(val);
    str = str.trim().replace(/\s+/g, '');
    // Unwrap nested stringified JSON if present (e.g. '"[1,3]"' or '\"[1,3]\"')
    if ((str.startsWith('"{') && str.endsWith('}"')) ||
        (str.startsWith('"[') && str.endsWith(']"')) ||
        (str.startsWith("'") && str.endsWith("'"))) {
      try {
        const unescaped = JSON.parse(str);
        if (typeof unescaped === 'string') {
          str = unescaped.trim().replace(/\s+/g, '');
        }
      } catch {}
    }
    // Remove outer quotes for string comparison
    str = str.replace(/^["']|["']$/g, '');
    return str;
  };

  // Execute and test coding exercise live
  const runAndCheckCode = (userCode: string, currentQuestion: Question) => {
    if (!currentQuestion.testCases || currentQuestion.testCases.length === 0) {
      return { overallPassed: true, results: [] };
    }
    
    const results = currentQuestion.testCases.map(tc => {
      let passed = false;
      let got = '';
      
      try {
        const wrapperFunction = new Function(`
          ${userCode}
          return ${tc.codeCheck};
        `);
        const executionResult = wrapperFunction();
        
        if (executionResult === undefined) {
          got = 'undefined';
        } else if (executionResult === null) {
          got = 'null';
        } else if (typeof executionResult === 'object') {
          got = JSON.stringify(executionResult);
        } else {
          got = String(executionResult);
        }
        
        const cleanGot = normalizeForComparison(executionResult);
        const cleanExpected = normalizeForComparison(tc.expectedOutput);
        
        passed = (cleanGot === cleanExpected) || 
                 (cleanGot.toLowerCase() === cleanExpected.toLowerCase());
      } catch (err: any) {
        got = `Error: ${err.message}`;
        passed = false;
      }
      
      return {
        id: tc.id,
        input: tc.input,
        passed,
        got,
        expected: tc.expectedOutput
      };
    });

    const overallPassed = results.every(r => r.passed);
    return { overallPassed, results };
  };

  // Check Answer Handler
  const handleCheckAnswer = () => {
    const currentQuestion = activeQuestions[currentQuestionIndex];
    if (!currentQuestion) return;

    let correct = false;

    if (currentQuestion.type === 'multiple_choice') {
      if (!selectedOptionId) {
        setFeedbackText('Por favor selecciona una opción antes de comprobar.');
        return;
      }

      const selectedOpt = currentQuestion.options?.find(o => o.id === selectedOptionId);
      if (selectedOpt && isOptionDesignatedCorrect(selectedOpt, currentQuestion.correctOptionId)) {
        correct = true;
      }
      setIsAnswerCorrect(correct);
    } else if (currentQuestion.type === 'parsons') {
      const solution = currentQuestion.parsonsSolutionOrder || currentQuestion.correctOrder || [];
      if (solution.length > 0 && parsonsOrder.length === solution.length) {
        correct = parsonsOrder.every((id, idx) => id === solution[idx]);
      } else {
        correct = false;
      }
      setIsAnswerCorrect(correct);
    } else if (currentQuestion.type === 'logic_analysis') {
      if (selectedBugLine === null) {
        setFeedbackText('Por favor selecciona la línea de código donde detectas el fallo lógico.');
        return;
      }
      correct = selectedBugLine === (currentQuestion.bugLineNumber ?? currentQuestion.bugLine);
      setIsAnswerCorrect(correct);
    } else {
      const { overallPassed, results } = runAndCheckCode(codingAnswer, currentQuestion);
      setTestResults(results);
      correct = overallPassed;
      setIsAnswerCorrect(correct);
    }

    if (correct) {
      playSound('correct');
      setActiveSenaMood('happy');
      setRightAnswersCount(prev => prev + 1);
      setFeedbackText(`🎉 ¡Excelente trabajo! Respuesta correcta validada.\n💡 Explicación: ${currentQuestion.explanation}`);
    } else {
      playSound('error');
      setActiveSenaMood('sad');
      if (currentQuestion.type === 'multiple_choice') {
        const correctOpt = currentQuestion.options?.find(o => 
          isOptionDesignatedCorrect(o, currentQuestion.correctOptionId)
        ) || currentQuestion.options?.find(o => o.id === currentQuestion.correctOptionId);

        const correctIdLabel = correctOpt?.id || currentQuestion.correctOptionId || 'Correcta';
        const correctTextLabel = correctOpt ? `: "${correctOpt.text}"` : '';
        setFeedbackText(`❌ Respuesta incorrecta.\n👉 La opción correcta es la ${correctIdLabel}${correctTextLabel}.\n💡 ¿Por qué? ${currentQuestion.explanation}`);
      } else if (currentQuestion.type === 'parsons') {
        setFeedbackText(`❌ El orden de los bloques aún no es el correcto para la ejecución del algoritmo.\n👉 Revisa la secuencia de pasos lógicos (inicialización ➔ evaluación ➔ retorno).\n💡 Pista: ${currentQuestion.explanation}`);
      } else if (currentQuestion.type === 'logic_analysis') {
        setFeedbackText(`❌ La línea seleccionada no es la causa del bug.\n👉 El error lógico se ubica en la línea ${currentQuestion.bugLineNumber ?? currentQuestion.bugLine}.\n💡 Causa: ${currentQuestion.bugExplanation || currentQuestion.explanation}`);
      } else {
        setFeedbackText(`❌ Tu código no superó todas las pruebas unitarias.\n👉 Revisa los casos de prueba esperados en consola.\n💡 ¿Por qué? ${currentQuestion.explanation}`);
      }
    }

    setIsAnswerChecked(true);
  };

  // Navigate to next question or evaluate finish status
  const handleNextQuestion = () => {
    if (currentQuestionIndex < activeQuestions.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
    } else {
      handleFinishSession();
    }
  };

  // Finished Session (confirmado por Neon PostgreSQL antes de celebrar o actualizar perfil)
  const handleFinishSession = async () => {
    if (!profile || !activeModule || progressSaveInFlightRef.current) return;

    progressSaveInFlightRef.current = true;
    setProgressSaveError('');
    setProgressSaving(true);

    try {
      if (activeRoadmapNode) {
        // Flujo individual de nodo del sendero (lección de 1 pregunta, lección IA o desafío de jefe) -> progreso_usuario
        const res = await fetch('/api/usuario/sendero/nodo/guardar', {
          method: 'POST',
          headers: getAuthHeaders(),
          body: JSON.stringify({
            email: profile.email,
            moduleId: activeRoadmapNode.moduleId,
            nodeId: activeRoadmapNode.node.id,
            score: rightAnswersCount,
            totalQuestions: activeQuestions.length
          })
        });
        const data = await res.json().catch(() => ({}));

        if (!res.ok || !data?.success || !data?.user) {
          setProgressSaveError(
            data?.error || 'No se pudo confirmar el guardado del nodo en Neon PostgreSQL. Inténtalo nuevamente.'
          );
          setActiveSenaMood('sad');
          playSound('error');
          return;
        }

        const persistedTokens = typeof data.user.tokens === 'number'
          ? data.user.tokens
          : (typeof data.user.bitsBalance === 'number' ? data.user.bitsBalance : profile.tokens);

        setProfile(prev => prev ? {
          ...prev,
          totalXP: data.user.totalXP,
          points: data.user.totalXP,
          tokens: persistedTokens,
          level: data.user.level,
          title: data.user.title,
          streakDays: data.user.streakDays,
          streak: data.user.streakDays,
          xpDays: data.user.xpDays || prev.xpDays,
          roadmapProgress: data.user.roadmapProgress || prev.roadmapProgress,
          claimedNodes: data.user.claimedNodes || prev.claimedNodes
        } : null);

        if (typeof persistedTokens === 'number') {
          setBits(persistedTokens);
        }
        if (data.user.claimedNodes) {
          setClaimedRoadmapNodes(data.user.claimedNodes);
        }

        const xpEarned = typeof data.xpGained === 'number' ? data.xpGained : (typeof data.user.xpGained === 'number' ? data.user.xpGained : 0);
        const bitsEarned = typeof data.bitsGained === 'number' ? data.bitsGained : (typeof data.user.bitsGained === 'number' ? data.user.bitsGained : 0);

        setGainedXPThisSession(xpEarned);
        setSessionBitsGained(bitsEarned);
        setModuleFinished(true);
        setActiveSenaMood(data.passed === false ? 'sad' : 'victory');
        setShowCelebrationModal(true);
        playSound(data.passed === false ? 'click' : 'victory');
        return;
      }

      // Flujo general de módulo completo (Estándar Offline o Clase con IA) -> progreso_modulos_usuario
      let baseXP = rightAnswersCount * 40;
      if (purchasedDoubleXP) {
        baseXP = baseXP * 2;
      }

      const res = await fetch('/api/usuario/progreso/guardar', {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify({
          email: profile.email,
          moduleId: activeModule.id,
          modality: activeLessonMode,
          score: rightAnswersCount,
          totalQuestions: activeQuestions.length,
          xpCount: baseXP,
          complete: rightAnswersCount >= 3
        })
      });
      const data = await res.json().catch(() => ({}));

      if (!res.ok || !data?.success || !data?.user) {
        setProgressSaveError(
          data?.error || 'No se pudo confirmar el guardado de tu progreso en Neon PostgreSQL. Inténtalo nuevamente.'
        );
        setActiveSenaMood('sad');
        playSound('error');
        return;
      }

      const persistedTokens = typeof data.user.tokens === 'number'
        ? data.user.tokens
        : (typeof data.user.bitsBalance === 'number' ? data.user.bitsBalance : profile.tokens);

      setProfile(prev => prev ? {
        ...prev,
        totalXP: data.user.totalXP,
        points: data.user.totalXP,
        tokens: persistedTokens,
        level: data.user.level,
        title: data.user.title,
        streakDays: data.user.streakDays,
        streak: data.user.streakDays,
        progress: data.user.progress,
        xpDays: data.user.xpDays
      } : null);

      if (typeof persistedTokens === 'number') {
        setBits(persistedTokens);
      }

      const xpEarned = typeof data.user.xpGained === 'number' ? data.user.xpGained : baseXP;
      const bitsEarned = typeof data.user.bitsGained === 'number' ? data.user.bitsGained : Math.floor(xpEarned / 2);

      setGainedXPThisSession(xpEarned);
      setSessionBitsGained(bitsEarned);
      setModuleFinished(true);
      setActiveSenaMood('victory');
      setShowCelebrationModal(true);
      playSound('victory');
    } catch {
      setProgressSaveError('Error de conexión al guardar tu progreso en el servidor. Tus resultados no han sido registrados aún.');
      setActiveSenaMood('sad');
      playSound('error');
    } finally {
      progressSaveInFlightRef.current = false;
      setProgressSaving(false);
    }
  };

  // Request help/hint on active question adapted to learning style
  const handleUseHint = () => {
    const currentQuestion = activeQuestions[currentQuestionIndex];
    if (!currentQuestion) return;
    playSound('click');
    setActiveSenaMood('thinking');
    setIsTutorOpen(true); // Open AI Tutor drawer on the left side!

    if (currentQuestion.audioTip) {
      setFeedbackText(`💡 Pista Auditiva: ${currentQuestion.audioTip}`);
    } else if (currentQuestion.visualDiagram) {
      setFeedbackText(`💡 Pista Visual: Observa el diagrama esquemático superior para rastrear el flujo de los datos.`);
    } else if (currentQuestion.logicPremise) {
      setFeedbackText(`💡 Pista Lógica: ${currentQuestion.logicPremise}`);
    } else if (currentQuestion.docSnippet) {
      setFeedbackText(`💡 Pista de Especificación: ${currentQuestion.docSnippet}`);
    } else if (currentQuestion.pairProgrammingPrompt) {
      setFeedbackText(`💡 Pista de Equipo: ${currentQuestion.pairProgrammingPrompt}`);
    } else {
      setFeedbackText(`💡 Pista del Profesor IA: ${currentQuestion.explanation.slice(0, 95)}...`);
    }
  };

  return (
    <div className="w-full min-h-screen bg-[#F4F6F9] dark:bg-[#070D14] text-[#00324D] dark:text-[#E2E8F0] flex flex-col antialiased transition-colors duration-200">
      
      {/* HEADER NODO (Solo visible en bienvenida, diagnóstico o cuando hay un módulo/reto activo) */}
      {!(profile && view === 'app' && !activeModule) && (
        <header className="h-16 border-b-2 border-slate-200 dark:border-slate-800 bg-white/95 dark:bg-[#0B131E]/95 backdrop-blur-md flex items-center justify-between px-4 sm:px-8 shrink-0 z-20 sticky top-0 shadow-xs transition-colors">
        <div className="flex items-center gap-4 sm:gap-8">
          {/* Logo Nodo Oficial (Navegación contextual segura sin pantalla en blanco) */}
          <div 
            onClick={handleLogoClick}
            className="cursor-pointer select-none group"
            title={profile ? "Ir al inicio de Nodo" : "Volver al inicio de sesión"}
          >
            <NodoLogo size="sm" theme={darkMode ? 'dark' : 'light'} showTagline={false} />
          </div>
        </div>

        {/* Profile top indicator status pills, Dark Mode Toggle & Auth navigation */}
        <div className="flex items-center gap-2.5 sm:gap-3.5">
          {/* Universal Dark Mode Toggle Button */}
          <button
            onClick={() => { playSound('click'); setDarkMode(!darkMode); }}
            className="p-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#131F2E] text-slate-600 dark:text-amber-300 hover:border-[#39a900] dark:hover:border-emerald-400 transition shadow-2xs flex items-center justify-center cursor-pointer"
            title={darkMode ? "Cambiar a modo claro" : "Cambiar a modo oscuro"}
            aria-label="Alternar modo oscuro"
          >
            {darkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-[#00324D]" />}
          </button>

          {profile ? (
            <>
              {/* Learning Style Pill */}
              {learningStyleResult && (
                <button
                  onClick={() => { playSound('click'); setActiveModule(null); setView('learning-style'); }}
                  title="Ver o repetir cuestionario de estilo de aprendizaje"
                  className="hidden md:flex items-center gap-1.5 px-3 py-1 rounded-full bg-white dark:bg-[#131F2E] border border-slate-200 dark:border-slate-700 hover:border-[#39a900] dark:hover:border-emerald-400 text-xs font-black text-[#00324D] dark:text-slate-100 shadow-2xs transition cursor-pointer"
                >
                  <span>{learningStyleResult.primaryStyle.icon}</span>
                  <span className="font-black text-[11px] text-[#007832] dark:text-[#2EE59D] uppercase">
                    {learningStyleResult.primaryStyle.shortName}
                  </span>
                  <span className="text-[10px] text-slate-400 dark:text-slate-500 font-bold">
                    {learningStyleResult.primaryStyle.percentage}%
                  </span>
                </button>
              )}

              {/* Streak flame with Amarillo #fdc300 */}
              <div className="flex items-center gap-1.5 bg-[#fdc300]/15 dark:bg-[#fdc300]/25 border border-[#fdc300]/40 px-3 py-1 rounded-full shadow-xs">
                <span className="text-[#fdc300] text-base drop-shadow-xs">🔥</span>
                <span className="font-black text-xs sm:text-sm text-[#00324D] dark:text-amber-200 tabular-nums">{profile.streakDays} DÍAS</span>
              </div>
              
              {/* Bits de Computación con Verde Principal #39a900 */}
              <div className="flex items-center gap-1.5 bg-[#39a900]/10 dark:bg-[#39a900]/25 border border-[#39a900]/30 px-3 py-1 rounded-full shadow-xs" title="Bits de computación acumulados">
                <span className="text-[#39a900] dark:text-[#2EE59D] text-base">💻</span>
                <span className="font-black text-xs sm:text-sm text-[#007832] dark:text-[#2EE59D] tabular-nums">{bits} BITS</span>
              </div>

              {/* User initials with Logout button */}
              <div className="flex items-center gap-2">
                <div 
                  className="w-9 h-9 rounded-xl bg-[#00324D] dark:bg-emerald-900/60 text-white font-black text-xs flex items-center justify-center uppercase shadow-xs ring-2 ring-[#39a900]/40"
                  title={`Conectado como: ${profile.username} (${profile.email})`}
                >
                  {profile.username.slice(0, 2)}
                </div>
                <button
                  onClick={handleLogout}
                  title="Cerrar sesión / Registrar nuevo usuario"
                  className="px-2.5 py-1.5 rounded-xl text-slate-500 dark:text-slate-400 hover:text-red-600 dark:hover:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/40 border border-slate-200 dark:border-slate-800 hover:border-red-200 dark:hover:border-red-900 transition text-xs font-bold flex items-center gap-1 cursor-pointer shadow-2xs"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline text-[11px] font-black uppercase">Salir</span>
                </button>
              </div>
            </>
          ) : view === 'learning-style' ? (
            <div className="flex items-center gap-2.5">
              <button
                onClick={() => { playSound('click'); setView('welcome'); setAuthMode('login'); }}
                className="text-xs font-black uppercase tracking-wider text-[#00324D] dark:text-slate-200 hover:text-[#007832] dark:hover:text-[#2EE59D] transition px-2 py-1 cursor-pointer"
              >
                Iniciar Sesión
              </button>
              <button
                onClick={handleSwitchToRegister}
                className="px-3.5 py-1.5 rounded-xl bg-[#00324D] dark:bg-[#39a900] hover:bg-[#002336] dark:hover:bg-[#329600] text-white text-xs font-black uppercase tracking-wider transition shadow-2xs cursor-pointer"
              >
                Crear Cuenta
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-2 text-xs font-bold text-[#007832] dark:text-[#2EE59D]">
              <span className="w-2 h-2 rounded-full bg-[#39a900] animate-pulse" />
              <span className="hidden sm:inline">Aprende Programación Gamificada</span>
            </div>
          )}
        </div>
        </header>
      )}

      {/* RENDER VIEW 0: LEARNING STYLE ASSESSMENT (ISOLADO Y NUEVO POR CADA USUARIO) */}
      {view === 'learning-style' && (
        <main className="flex-1 flex flex-col items-center justify-center p-3 sm:p-6 w-full max-w-5xl mx-auto">
          {profileSyncError && (
            <div className="w-full max-w-4xl mb-4 bg-red-50 dark:bg-red-950/60 border border-red-200 dark:border-red-800 text-red-700 dark:text-red-300 text-xs font-bold px-4 py-3 rounded-2xl">
              {profileSyncError}
            </div>
          )}
          <LearningStyleAssessment
            key={profile ? `ls-${profile.email.toLowerCase()}` : 'ls-new-user'}
            userEmail={profile?.email}
            userName={profile?.username}
            initialResult={learningStyleResult}
            onReset={async () => {
              setProfileSyncError('');
              if (!profile) {
                setLearningStyleResult(null);
                return;
              }
              const previousStyle = learningStyleResult;
              setLearningStyleResult(null);
              try {
                const response = await fetch('/api/usuario/estilo-aprendizaje', {
                  method: 'POST',
                  headers: getAuthHeaders(),
                  body: JSON.stringify({ email: profile.email, learningStyleProfile: null })
                });
                const data = await response.json().catch(() => ({}));
                if (!response.ok) {
                  setLearningStyleResult(previousStyle);
                  setProfileSyncError(data.error || 'No se pudo reiniciar tu perfil cognitivo en la base de datos. Inténtalo de nuevo.');
                  return;
                }
                try {
                  localStorage.removeItem(`nodo_learning_style_${profile.email.toLowerCase()}`);
                } catch {}
                setProfile(prev => prev ? { ...prev, learningStyleProfile: undefined } : null);
              } catch {
                setLearningStyleResult(previousStyle);
                setProfileSyncError('Error de conexión al intentar reiniciar tu perfil cognitivo en el servidor.');
              }
            }}
            onComplete={async (res) => {
              setProfileSyncError('');
              setLearningStyleResult(res);
              if (!profile) return;
              try {
                const response = await fetch('/api/usuario/estilo-aprendizaje', {
                  method: 'POST',
                  headers: getAuthHeaders(),
                  body: JSON.stringify({ email: profile.email, learningStyleProfile: res })
                });
                const data = await response.json().catch(() => ({}));
                if (!response.ok) {
                  setProfileSyncError(data.error || 'No se pudo guardar tu perfil cognitivo en Neon PostgreSQL. Verifica tu conexión e inténtalo de nuevo.');
                  return;
                }
                const persistedStyle = data.user?.learningStyleProfile || res;
                setLearningStyleResult(persistedStyle);
                setProfile(prev => prev ? { ...prev, learningStyleProfile: persistedStyle } : null);
                try {
                  localStorage.setItem(`nodo_learning_style_${profile.email.toLowerCase()}`, JSON.stringify(persistedStyle));
                } catch {}
              } catch {
                setProfileSyncError('No fue posible conectar con el servidor para guardar tu perfil cognitivo.');
              }
            }}
            onSkipOrContinue={() => {
              if (profile) {
                setView('app');
              } else {
                setView('welcome');
              }
            }}
          />
        </main>
      )}

      {/* RENDER VIEW 1: AUTH / SIGNUP SCREEN (También actúa como fallback defensivo si no hay sesión) */}
      {(view === 'welcome' || (!profile && (view === 'app' || view === 'diagnostic'))) && (
        <main className="flex-1 flex flex-col md:flex-row items-center justify-center p-4 sm:p-12 gap-8 max-w-6xl mx-auto w-full">
          {/* Logo, pitch & mascot presentation view */}
          <div className="flex-1 space-y-6 text-center md:text-left">
            <div className="flex justify-center md:justify-start">
              <NodoLogo size="lg" theme={darkMode ? 'dark' : 'light'} showTagline={true} />
            </div>
            
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black text-[#00283d] dark:text-white tracking-tight leading-tight">
              Aprende a <span className="text-[#2EE59D] bg-[#00283d] dark:bg-emerald-950/80 px-2.5 py-0.5 rounded-xl inline-block shadow-xs">programar</span> con tu nuevo Tutor IA
            </h1>
            
            <div className="p-1 max-w-md mx-auto md:mx-0">
              <SenaHelper 
                mood="happy" 
                text="¡Hola! Soy Nodo Bot 🤖, tu nuevo tutor personal de código. Estoy aquí para explicarte cada reto paso a paso, responder tus preguntas y acompañarte mientras subes de nivel." 
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 text-left max-w-lg mx-auto md:mx-0">
              <div className="flex items-center gap-2.5 text-xs font-bold text-[#00324D] dark:text-slate-200 bg-white dark:bg-[#0F172A] p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-2xs">
                <div className="w-6 h-6 rounded-lg bg-[#39a900]/15 dark:bg-[#39a900]/30 flex items-center justify-center shrink-0">
                  <Check className="w-3.5 h-3.5 text-[#39a900] dark:text-[#2EE59D]" />
                </div>
                <span>Playground de código en vivo</span>
              </div>
              <div className="flex items-center gap-2.5 text-xs font-bold text-[#00324D] dark:text-slate-200 bg-white dark:bg-[#0F172A] p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-2xs">
                <div className="w-6 h-6 rounded-lg bg-[#fdc300]/20 flex items-center justify-center shrink-0">
                  <Zap className="w-3.5 h-3.5 text-[#007832] dark:text-amber-300" />
                </div>
                <span>Racha diaria con XP y Bits de código</span>
              </div>
              <div className="flex items-center gap-2.5 text-xs font-bold text-[#00324D] dark:text-slate-200 bg-white dark:bg-[#0F172A] p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-2xs">
                <div className="w-6 h-6 rounded-lg bg-[#71277a]/15 dark:bg-[#71277a]/30 flex items-center justify-center shrink-0">
                  <Sparkles className="w-3.5 h-3.5 text-[#71277a] dark:text-purple-300" />
                </div>
                <span>Generación adaptativa con IA</span>
              </div>
              <div className="flex items-center gap-2.5 text-xs font-bold text-[#00324D] dark:text-slate-200 bg-white dark:bg-[#0F172A] p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-2xs">
                <div className="w-6 h-6 rounded-lg bg-[#00324D]/10 dark:bg-slate-800 flex items-center justify-center shrink-0">
                  <Terminal className="w-3.5 h-3.5 text-[#00324D] dark:text-slate-300" />
                </div>
                <span>Casos de prueba en vivo</span>
              </div>
            </div>
          </div>

          {/* Authentic register / login card */}
          <div className="w-full max-w-md bg-white dark:bg-[#0F172A] rounded-3xl border-2 border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-sm transition-colors">
            {/* Clean Tab Switcher */}
            <div className="mb-4 flex border-b-2 border-slate-200 dark:border-slate-800">
              <button 
                type="button"
                onClick={handleSwitchToRegister} 
                className={`flex-1 font-black text-xs sm:text-sm uppercase tracking-wider pb-3 transition relative text-center cursor-pointer ${
                  authMode === 'register' 
                    ? 'text-[#007832] dark:text-[#2EE59D] after:absolute after:-bottom-0.5 after:left-0 after:w-full after:h-1 after:bg-[#39a900] after:rounded-full' 
                    : 'text-slate-400 dark:text-slate-500 hover:text-[#00324D] dark:hover:text-white'
                }`}
              >
                Crear Cuenta
              </button>
              <button 
                type="button"
                onClick={() => { setAuthMode('login'); setAuthError(''); setOtpInfoMessage(''); setPendingAccountPrompt(null); }} 
                className={`flex-1 font-black text-xs sm:text-sm uppercase tracking-wider pb-3 transition relative text-center cursor-pointer ${
                  authMode === 'login' 
                    ? 'text-[#00324D] dark:text-white after:absolute after:-bottom-0.5 after:left-0 after:w-full after:h-1 after:bg-[#00324D] dark:after:bg-white after:rounded-full' 
                    : 'text-slate-400 dark:text-slate-500 hover:text-[#00324D] dark:hover:text-white'
                }`}
              >
                Iniciar Sesión
              </button>
            </div>

            {/* Informational badge when registering a new user */}
            {authMode === 'register' && (
              <div className="mb-4 p-2.5 rounded-xl bg-[#39a900]/10 dark:bg-[#39a900]/20 border border-[#39a900]/30 text-[#007832] dark:text-[#2EE59D] text-xs font-bold flex items-center gap-2">
                <Brain className="w-4 h-4 shrink-0 text-[#39a900] dark:text-[#2EE59D]" />
                <span>Cada nuevo usuario realiza un test de aprendizaje único y desde cero.</span>
              </div>
            )}

            {otpInfoMessage && (
              <div className="p-3.5 mb-4 bg-emerald-50 dark:bg-emerald-950/40 border-2 border-emerald-200 dark:border-emerald-800 text-[#007832] dark:text-[#2EE59D] text-xs font-bold rounded-xl">
                ✅ {otpInfoMessage}
              </div>
            )}

            {authError && (
              <div className="p-3.5 mb-4 bg-red-50 dark:bg-red-950/40 border-2 border-red-200 dark:border-red-800 text-red-700 dark:text-red-300 text-xs font-bold rounded-xl flex items-center gap-2">
                <span>⚠️</span>
                <span>{authError}</span>
              </div>
            )}

            {pendingAccountPrompt && (
              <div className="p-3.5 mb-4 bg-amber-50 dark:bg-amber-950/40 border-2 border-amber-200 dark:border-amber-800 rounded-xl space-y-2.5 text-xs">
                <p className="font-black text-[#00324D] dark:text-amber-200">
                  📩 Cuenta pendiente de verificación ({pendingAccountPrompt.email})
                </p>
                <p className="text-slate-600 dark:text-slate-300 font-medium">
                  {pendingAccountPrompt.source === 'login'
                    ? 'Tu contraseña ha sido validada. Puedes ingresar tu código OTP actual o solicitar uno nuevo.'
                    : 'Tus datos previos no fueron sobrescritos. Continúa verificando tu cuenta o solicita un nuevo código OTP validando tu contraseña.'}
                </p>
                <div className="flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      playSound('click');
                      setEmail(pendingAccountPrompt.email);
                      setAuthError('');
                      setVerificationCode('');
                      setInputCode('');
                      setOtpInfoMessage('Ingresa el código OTP de 6 dígitos emitido para tu cuenta o solicita un reenvío.');
                      setPendingAccountPrompt(null);
                      setView('verify');
                    }}
                    className="px-3 py-2 rounded-lg bg-[#39a900] hover:bg-[#329600] text-white font-black uppercase tracking-wide cursor-pointer"
                  >
                    Ingresar código OTP
                  </button>
                  {pendingAccountPrompt.source === 'login' && (
                    <button
                      type="button"
                      disabled={resendLoading || otpCooldownSeconds > 0}
                      onClick={() => handleResendOtp()}
                      className="px-3 py-2 rounded-lg bg-[#00324D] hover:bg-[#002336] text-white font-black uppercase tracking-wide disabled:opacity-50 cursor-pointer"
                    >
                      {resendLoading
                        ? 'Reenviando...'
                        : otpCooldownSeconds > 0
                          ? `Esperar ${otpCooldownSeconds}s`
                          : 'Solicitar nuevo OTP'}
                    </button>
                  )}
                  {pendingAccountPrompt.source === 'register' && (
                    <button
                      type="button"
                      onClick={() => {
                        playSound('click');
                        setEmail(pendingAccountPrompt.email);
                        setPassword('');
                        setAuthError('');
                        setPendingAccountPrompt(null);
                        setAuthMode('login');
                      }}
                      className="px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-600 text-[#00324D] dark:text-slate-200 font-black uppercase tracking-wide cursor-pointer"
                    >
                      Ir a Iniciar Sesión
                    </button>
                  )}
                </div>
              </div>
            )}

            {authMode === 'register' ? (
              // REGISTER FORM
              <form onSubmit={handleRegisterSubmit} className="space-y-4">
                <div>
                  <label className="block text-xs font-black uppercase tracking-wider text-[#00324D] dark:text-slate-300 mb-1.5">Nombre y Apellidos</label>
                  <input 
                    type="text" 
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="Ej. Juan Pérez" 
                    className="w-full p-3 font-semibold text-[#00324D] dark:text-white bg-[#F8FAFC] dark:bg-[#0B131E] border-2 border-slate-200 dark:border-slate-700 rounded-xl focus:border-[#39a900] dark:focus:border-emerald-500 focus:outline-none transition-all"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-black uppercase tracking-wider text-[#00324D] dark:text-slate-300 mb-1.5">Correo electrónico</label>
                  <input 
                    type="email" 
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="usuario@nodo.app" 
                    className="w-full p-3 font-semibold text-[#00324D] dark:text-white bg-[#F8FAFC] dark:bg-[#0B131E] border-2 border-slate-200 dark:border-slate-700 rounded-xl focus:border-[#39a900] dark:focus:border-emerald-500 focus:outline-none transition-all"
                    required
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-black uppercase tracking-wider text-[#00324D] dark:text-slate-300 mb-1.5">Edad</label>
                    <input 
                      type="number" 
                      value={age}
                      onChange={(e) => setAge(Number(e.target.value))}
                      min="1"
                      max="100"
                      placeholder="20" 
                      className="w-full p-3 font-semibold text-[#00324D] dark:text-white bg-[#F8FAFC] dark:bg-[#0B131E] border-2 border-slate-200 dark:border-slate-700 rounded-xl focus:border-[#39a900] dark:focus:border-emerald-500 focus:outline-none transition-all"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-black uppercase tracking-wider text-[#00324D] dark:text-slate-300 mb-1.5">Contraseña</label>
                    <input 
                      type="password" 
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      minLength={8}
                      maxLength={72}
                      placeholder="Mínimo 8 caracteres" 
                      className="w-full p-3 font-semibold text-[#00324D] dark:text-white bg-[#F8FAFC] dark:bg-[#0B131E] border-2 border-slate-200 dark:border-slate-700 rounded-xl focus:border-[#39a900] dark:focus:border-emerald-500 focus:outline-none transition-all"
                      required
                    />
                  </div>
                </div>

                <button 
                  type="submit" 
                  disabled={authLoading}
                  className="w-full py-4 rounded-2xl bg-[#39a900] hover:bg-[#329600] border-b-4 border-[#007832] text-white font-black uppercase tracking-wider shadow-sm transition active:translate-y-0.5 active:border-b-2 disabled:opacity-50 cursor-pointer"
                >
                  {authLoading ? 'Creando cuenta...' : 'Registrarme Gratis en Nodo'}
                </button>

                <div className="pt-2 text-center">
                  <p className="text-xs text-slate-500 dark:text-slate-400 font-semibold">
                    ¿Ya tienes cuenta activa?{' '}
                    <button 
                      type="button" 
                      onClick={() => { setAuthMode('login'); setAuthError(''); }}
                      className="text-[#007832] dark:text-[#2EE59D] hover:underline font-black cursor-pointer"
                    >
                      Inicia sesión aquí
                    </button>
                  </p>
                </div>
              </form>
            ) : (
              // LOGIN FORM
              <form onSubmit={handleDirectLogin} className="space-y-4">
                <div>
                  <label className="block text-xs font-black uppercase tracking-wider text-[#00324D] dark:text-slate-300 mb-1.5">Correo registrado</label>
                  <input 
                    type="email" 
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="usuario@nodo.app" 
                    className="w-full p-3 font-semibold text-[#00324D] dark:text-white bg-[#F8FAFC] dark:bg-[#0B131E] border-2 border-slate-200 dark:border-slate-700 rounded-xl focus:border-[#39a900] dark:focus:border-emerald-500 focus:outline-none transition-all"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-black uppercase tracking-wider text-[#00324D] dark:text-slate-300 mb-1.5">Contraseña</label>
                  <input 
                    type="password" 
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    maxLength={72}
                    placeholder="Introduce tu contraseña" 
                    className="w-full p-3 font-semibold text-[#00324D] dark:text-white bg-[#F8FAFC] dark:bg-[#0B131E] border-2 border-slate-200 dark:border-slate-700 rounded-xl focus:border-[#39a900] dark:focus:border-emerald-500 focus:outline-none transition-all"
                    required
                  />
                </div>

                <button 
                  type="submit" 
                  disabled={authLoading}
                  className="w-full py-4 rounded-2xl bg-[#00324D] dark:bg-[#39a900] hover:bg-[#002336] dark:hover:bg-[#329600] border-b-4 border-[#001724] dark:border-[#007832] text-white font-black uppercase tracking-wider shadow-sm transition active:translate-y-0.5 active:border-b-2 disabled:opacity-50 flex items-center justify-center gap-2 cursor-pointer"
                >
                  {authLoading ? 'Verificando...' : 'Ingresar a Nodo'}
                  <ArrowRight className="w-4 h-4 text-[#39a900] dark:text-white" />
                </button>

                <div className="pt-2 text-center">
                  <p className="text-xs text-slate-500 dark:text-slate-400 font-semibold">
                    ¿No tienes una cuenta aún?{' '}
                    <button 
                      type="button" 
                      onClick={handleSwitchToRegister}
                      className="text-[#007832] dark:text-[#2EE59D] hover:underline font-black cursor-pointer"
                    >
                      Regístrate gratis
                    </button>
                  </p>
                </div>
              </form>
            )}
          </div>
        </main>
      )}

      {/* RENDER VIEW 2: VERIFICATION OTP CODE VIEW */}
      {view === 'verify' && (
        <main className="flex-1 flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-white dark:bg-[#0F172A] rounded-3xl border-2 border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-sm transition-colors">
            <div className="text-center space-y-3 mb-6">
              <div className="w-16 h-16 bg-[#39a900]/15 text-[#007832] dark:text-[#2EE59D] rounded-2xl flex items-center justify-center text-3xl mx-auto shadow-inner border border-[#39a900]/30">
                🔐
              </div>
              <h2 className="text-2xl font-black text-[#00324D] dark:text-white">Verifica tu Cuenta</h2>
              <p className="text-sm text-slate-500 dark:text-slate-400 font-bold">
                Hemos emitido tu código de verificación OTP para validar tu acceso{email ? ` (${email})` : ''}:
              </p>
            </div>

            {verificationCode ? (
              <div className="p-4 bg-[#fdc300]/15 dark:bg-[#fdc300]/25 border-2 border-[#fdc300]/50 rounded-2xl mb-6 text-center text-xs">
                <span className="font-black text-[#00324D] dark:text-amber-200 block mb-1">🛠️ MODO PREVIEW LOCAL (DESARROLLO):</span>
                <p className="text-[#00324D] dark:text-slate-200 mb-2 font-medium">Código OTP habilitado explícitamente para pruebas locales:</p>
                <div className="inline-block px-4 py-2 bg-[#fdc300] text-[#00324D] font-mono text-xl font-black tracking-widest rounded-xl shadow-xs border border-[#d9a500]">
                  {verificationCode}
                </div>
              </div>
            ) : (
              <div className="p-3.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-2xl mb-6 text-center text-xs text-slate-600 dark:text-slate-300 font-semibold">
                Por seguridad, el código OTP no se muestra en pantalla por defecto. Ingresa el código de 6 dígitos asignado a tu verificación (vigencia de 15 minutos, máximo 5 intentos).
              </div>
            )}

            {otpInfoMessage && (
              <div className="p-3 mb-4 bg-emerald-50 dark:bg-emerald-950/40 border-2 border-emerald-200 dark:border-emerald-800 text-[#007832] dark:text-[#2EE59D] text-xs font-bold rounded-xl">
                ✅ {otpInfoMessage}
              </div>
            )}

            <form onSubmit={handleVerifySubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-black uppercase tracking-wider text-[#00324D] dark:text-slate-300 mb-1.5">Introduce el código de 6 dígitos</label>
                <input 
                  type="text" 
                  maxLength={6}
                  value={inputCode}
                  onChange={(e) => setInputCode(e.target.value)}
                  placeholder="Ejemplo: 123456" 
                  className="w-full p-3 font-mono text-center text-xl tracking-widest font-black text-[#00324D] dark:text-white bg-[#F8FAFC] dark:bg-[#0B131E] border-2 border-slate-200 dark:border-slate-700 rounded-xl focus:border-[#39a900] dark:focus:border-emerald-500 focus:outline-none transition-all"
                  required
                />
              </div>

              {authError && (
                <div className="p-3 bg-red-50 dark:bg-red-950/40 border-2 border-red-200 dark:border-red-900 text-red-700 dark:text-red-300 text-xs font-bold rounded-xl">
                  ⚠️ {authError}
                </div>
              )}

              <button 
                type="submit" 
                disabled={authLoading}
                className="w-full py-4 rounded-2xl bg-[#39a900] hover:bg-[#329600] border-b-4 border-[#007832] text-white font-black uppercase tracking-wider shadow-sm transition active:translate-y-0.5 active:border-b-2 disabled:opacity-50 cursor-pointer"
              >
                {authLoading ? 'Verificando...' : 'Verificar y Continuar'}
              </button>
            </form>

            {/* Reenvío controlado de OTP y regreso seguro al inicio de sesión */}
            <div className="mt-5 pt-4 border-t border-slate-200 dark:border-slate-800 space-y-3">
              {resendPasswordPrompt && (
                <div className="p-3 rounded-xl bg-slate-50 dark:bg-[#0B131E] border border-slate-200 dark:border-slate-700 space-y-2">
                  <label className="block text-[11px] font-black uppercase tracking-wider text-[#00324D] dark:text-slate-300">
                    Confirma tu contraseña para reenviar el código
                  </label>
                  <input
                    type="password"
                    value={resendPasswordInput}
                    onChange={(e) => setResendPasswordInput(e.target.value)}
                    maxLength={72}
                    placeholder="Introduce tu contraseña original"
                    className="w-full p-2.5 text-sm font-semibold text-[#00324D] dark:text-white bg-white dark:bg-[#0F172A] border border-slate-300 dark:border-slate-700 rounded-lg focus:border-[#39a900] focus:outline-none"
                  />
                  <button
                    type="button"
                    disabled={resendLoading || otpCooldownSeconds > 0 || !resendPasswordInput}
                    onClick={() => handleResendOtp(resendPasswordInput)}
                    className="w-full py-2.5 rounded-xl bg-[#00324D] dark:bg-[#39a900] hover:bg-[#002336] dark:hover:bg-[#329600] text-white text-xs font-black uppercase tracking-wider disabled:opacity-50 cursor-pointer"
                  >
                    {resendLoading
                      ? 'Validando y reenviando...'
                      : otpCooldownSeconds > 0
                        ? `Reenviar código (${otpCooldownSeconds}s)`
                        : 'Confirmar y Reenviar código'}
                  </button>
                </div>
              )}

              {!resendPasswordPrompt && (
                <button
                  type="button"
                  disabled={resendLoading || otpCooldownSeconds > 0}
                  onClick={() => handleResendOtp()}
                  className="w-full py-3 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-[#00324D] dark:text-slate-200 text-xs font-black uppercase tracking-wider transition disabled:opacity-50 cursor-pointer"
                >
                  {resendLoading
                    ? 'Generando nuevo código...'
                    : otpCooldownSeconds > 0
                      ? `Reenviar código (${otpCooldownSeconds}s)`
                      : 'Reenviar código'}
                </button>
              )}

              <button
                type="button"
                onClick={handleReturnToLoginFromOtp}
                className="w-full py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800/60 text-slate-600 dark:text-slate-300 text-xs font-black uppercase tracking-wider transition cursor-pointer"
              >
                Volver al inicio de sesión
              </button>
            </div>
          </div>
        </main>
      )}

      {/* RENDER VIEW 3: DYNAMIC AI DIAGNOSTIC SURVEY */}
      {view === 'diagnostic' && (
        <main className="flex-1 p-6 sm:p-12">
          <div className="max-w-2xl mx-auto text-center mb-8">
            <span className="text-[#007832] dark:text-[#2EE59D] bg-[#39a900]/15 dark:bg-[#39a900]/25 border border-[#39a900]/30 font-black text-xs px-3.5 py-1.5 rounded-full uppercase tracking-wider">
              Diagnóstico Inicial Nodo
            </span>
            <h1 className="text-2xl sm:text-3xl font-black text-[#00324D] dark:text-white tracking-tight mt-3">
              Personalizando tu Ruta de Aprendizaje con IA
            </h1>
            <p className="text-sm text-slate-500 dark:text-slate-400 font-bold mt-1">
              Nodo Bot analizará tus respuestas para trazar metas de racha y programar retos en tiempo real.
            </p>
          </div>

          {diagnosticError && (
            <div className="max-w-2xl mx-auto mb-6 bg-red-50 dark:bg-red-950/60 border border-red-200 dark:border-red-800 text-red-700 dark:text-red-300 text-xs font-bold px-4 py-3 rounded-2xl">
              {diagnosticError}
            </div>
          )}

          <DiagnosticWizard 
            loading={authLoading} 
            onComplete={handleDiagnosticComplete} 
          />
        </main>
      )}

      {/* RENDER VIEW 4: ACTIVE CORE APP PLATFORM */}
      {view === 'app' && profile && (
        activeModule ? (
          /* FOCUSED EXERCISE RUNNER WORKSPACE */
          <main className="flex-1 max-w-4xl mx-auto w-full p-4 sm:p-6 flex flex-col justify-center">
            <div className="bg-white dark:bg-[#0F172A] rounded-3xl border-2 border-slate-200 dark:border-slate-800 p-6 sm:p-8 flex flex-col shadow-xs duration-200">
              
              {/* Visual Progress Bar */}
              <div className="flex items-center gap-4 mb-6">
                <button 
                  onClick={() => { playSound('click'); setActiveModule(null); }}
                  className="text-slate-400 hover:text-[#00324D] dark:hover:text-white font-black text-xl px-2.5 py-1 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition cursor-pointer"
                  title="Salir de la sesión y volver al panel"
                >
                  ✕
                </button>

                <div className="flex-1 h-3.5 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden border border-slate-200 dark:border-slate-700">
                  <div 
                    className="h-full bg-[#39a900] transition-all duration-300"
                    style={{ width: `${((currentQuestionIndex + 1) / activeQuestions.length) * 100}%` }}
                  />
                </div>

                <span className="font-black text-xs tracking-wider text-[#007832] dark:text-[#2EE59D] tabular-nums">
                  {currentQuestionIndex + 1} / {activeQuestions.length} RETOS
                </span>

                {/* AI Tutor Toggle Button in top toolbar with animated Nodo Bot avatar */}
                <button
                  onClick={() => { playSound('click'); setIsTutorOpen(!isTutorOpen); }}
                  className="flex items-center gap-2 px-3 py-1.5 rounded-2xl border-2 border-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 hover:bg-emerald-100 dark:hover:bg-emerald-950/80 text-[#00283d] dark:text-emerald-300 font-black text-xs transition shadow-2xs group cursor-pointer"
                  title="Abrir menú de Nodo Bot en la parte izquierda"
                >
                  <div className="w-5 h-5 flex items-center justify-center">
                    <NodoTutorAvatar size="xs" emotion="happy" showHoloTablet={false} />
                  </div>
                  <span className="hidden sm:inline font-black">Nodo Bot</span>
                  <span className="w-2 h-2 rounded-full bg-[#2EE59D] animate-ping" />
                </button>
              </div>

              {generateLoading ? (
                // Custom IA Loading State
                <div className="flex-1 flex flex-col items-center justify-center text-center p-8 space-y-4">
                  <div className="relative">
                    <div className="w-16 h-16 border-4 border-[#71277a]/20 border-t-[#71277a] rounded-full animate-spin"></div>
                    <div className="absolute inset-0 flex items-center justify-center font-bold text-xs text-[#71277a]">NODO</div>
                  </div>
                  <div>
                    <h4 className="font-black text-lg text-[#00324D] dark:text-white">Inteligencia Artificial Nodo Generando...</h4>
                    <p className="text-sm text-slate-500 dark:text-slate-400 mt-1 max-w-sm">Estamos modelando preguntas y pruebas unitarias adaptadas a tu nivel.</p>
                  </div>
                </div>
              ) : activeQuestions[currentQuestionIndex] ? (
                // THE EXERCISE PANEL
                <div className="flex-1 flex flex-col">
                  
                  {/* Robot state feedback indicator */}
                  <div className="mb-4">
                    <SenaHelper 
                      mood={activeSenaMood} 
                      onOpenTutor={() => setIsTutorOpen(true)}
                      isVisualLearner={Boolean(
                        (profile?.learningStyleProfile?.primaryStyle?.type || learningStyleResult?.primaryStyle?.type) === 'visual' ||
                        (profile?.learningStyleProfile?.secondaryStyle?.type || learningStyleResult?.secondaryStyle?.type) === 'visual' ||
                        profile?.learningStyleProfile?.isBimodal ||
                        learningStyleResult?.isBimodal
                      )}
                      text={
                        feedbackText 
                          ? feedbackText 
                          : aiProfesorMessage
                            ? `Nodo Bot: ${aiProfesorMessage}`
                            : `Reto actual de dificultad: [${activeQuestions[currentQuestionIndex].difficulty.toUpperCase()}]. Haz clic aquí o en "Pista & Tutor" si necesitas una explicación paso a paso.`
                      } 
                    />
                  </div>

                  {/* Adaptation Banner: Modo Estándar (Offline) vs Modo IA */}
                  <div className={`mb-5 border-2 rounded-2xl p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-2xs ${
                    isAIGenerated
                      ? 'bg-gradient-to-r from-purple-50/50 via-cyan-50/30 to-white dark:from-purple-950/30 dark:via-cyan-950/20 dark:to-slate-800/40 border-purple-300/40 dark:border-purple-800/50'
                      : 'bg-gradient-to-r from-slate-50 via-slate-100/50 to-white dark:from-slate-800/60 dark:via-slate-800/40 dark:to-slate-900 border-slate-200 dark:border-slate-700'
                  }`}>
                    <div className="flex items-center gap-3">
                      <span className="text-2xl shrink-0 p-1.5 bg-white dark:bg-slate-700 rounded-xl shadow-2xs border border-slate-200 dark:border-slate-700">
                        {isAIGenerated ? (adaptedStyleIcon || (learningStyleResult?.primaryStyle.icon || '⚡')) : '📘'}
                      </span>
                      <div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className={`text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full ${
                            isAIGenerated 
                              ? 'text-purple-700 dark:text-purple-300 bg-purple-100/70 dark:bg-purple-950/60 border border-purple-300 dark:border-purple-800'
                              : 'text-slate-600 dark:text-slate-300 bg-slate-200 dark:bg-slate-700 border border-slate-300 dark:border-slate-600'
                          }`}>
                            {isAIGenerated ? 'Clase con IA Adaptativa' : 'Modo Estándar (Sin Conexión)'}
                          </span>
                          <span className="text-xs font-bold text-[#00324D] dark:text-slate-200">
                            {isAIGenerated 
                              ? `Adaptado a: ${adaptedStyleName || (learningStyleResult?.bimodalTitle || learningStyleResult?.primaryStyle.name || 'Práctico')}`
                              : 'Currículo Oficial Preestablecido'}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-500 dark:text-slate-400 font-medium mt-0.5 line-clamp-1">
                          {isAIGenerated 
                            ? (aiProfesorMessage || "Preguntas y explicaciones generadas en tiempo real para tu estilo.")
                            : "Preguntas preestablecidas de la currícula estándar. Sin consumo ni conexión a IA."}
                        </p>
                      </div>
                    </div>

                    {/* Auditory Speech Narration Button */}
                    <button
                      type="button"
                      onClick={() => toggleQuestionSpeech(activeQuestions[currentQuestionIndex])}
                      title="Escuchar la pregunta explicada con voz (Ideal para estilo auditivo y bimodal)"
                      className={`px-3 py-1.5 rounded-xl border text-xs font-bold flex items-center gap-1.5 transition self-start sm:self-auto cursor-pointer ${
                        isQuestionSpeaking
                          ? 'bg-[#71277a] text-white border-[#71277a] shadow-xs'
                          : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 hover:border-[#71277a] text-[#71277a] dark:text-purple-300'
                      }`}
                    >
                      {isQuestionSpeaking ? (
                        <>
                          <VolumeX className="w-3.5 h-3.5 animate-pulse" />
                          <span>Pausar voz</span>
                        </>
                      ) : (
                        <>
                          <Volume2 className="w-3.5 h-3.5" />
                          <span>🔊 Escuchar Reto</span>
                        </>
                      )}
                    </button>
                  </div>

                  <div className="mb-6">
                    <div className="flex items-center gap-2 mb-2 flex-wrap">
                      {/* Difficulty Badges */}
                      <span className={`text-[10px] font-black uppercase tracking-wider py-1 px-2.5 rounded-full ${
                        activeQuestions[currentQuestionIndex].difficulty === 'basico'
                          ? 'bg-[#39a900]/15 dark:bg-[#39a900]/30 text-[#007832] dark:text-[#2EE59D] border border-[#39a900]/30'
                          : activeQuestions[currentQuestionIndex].difficulty === 'intermedio'
                            ? 'bg-[#fdc300]/20 text-[#00324D] dark:text-amber-200 border border-[#fdc300]/40'
                            : 'bg-[#71277a]/15 text-[#71277a] dark:text-purple-300 border border-[#71277a]/30'
                      }`}>
                        NIVEL {activeQuestions[currentQuestionIndex].difficulty}
                      </span>

                      {isAIGenerated ? (
                        <span className="text-[10px] font-black uppercase tracking-wider py-1 px-2.5 rounded-full bg-[#71277a]/15 text-[#71277a] dark:text-purple-300 border border-[#71277a]/30 flex items-center gap-1 shadow-xs">
                          <Sparkles className="w-3 h-3 text-[#71277a] dark:text-purple-300 animate-pulse" />
                          Generado con Gemini IA
                        </span>
                      ) : (
                        <span className="text-[10px] font-black uppercase tracking-wider py-1 px-2.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-300 dark:border-slate-700 flex items-center gap-1 shadow-xs">
                          <span>📘 Estándar Offline</span>
                        </span>
                      )}
                      
                      <span className="text-xs text-slate-400 dark:text-slate-500 font-bold">
                        Tipo: {
                          activeQuestions[currentQuestionIndex].type === 'coding' 
                            ? 'Playground de Código en Vivo' 
                            : activeQuestions[currentQuestionIndex].type === 'parsons'
                              ? 'Reto Kinestésico: Ordenar Bloques (Parsons)'
                              : activeQuestions[currentQuestionIndex].type === 'logic_analysis'
                                ? 'Reto Lógico: Análisis Paso a Paso & Depuración'
                                : 'Selección Múltiple'
                        }
                      </span>
                    </div>

                    <h2 className="text-xl sm:text-2xl font-black text-[#00324D] dark:text-white leading-tight">
                      {activeQuestions[currentQuestionIndex].title}
                    </h2>
                    <p className="text-slate-600 dark:text-slate-300 font-medium text-sm sm:text-base mt-2 whitespace-pre-line leading-relaxed">
                      {activeQuestions[currentQuestionIndex].description}
                    </p>

                    {/* ADAPTIVE COMPONENT: Visual Diagram, Flow Maps & Semantic Colors for Visual Learners */}
                    {(activeQuestions[currentQuestionIndex].visualDiagram || 
                      activeQuestions[currentQuestionIndex].codeFlowMap || 
                      activeQuestions[currentQuestionIndex].semanticHighlights) && (
                      <VisualCodeFlow
                        visualDiagram={activeQuestions[currentQuestionIndex].visualDiagram}
                        flowSteps={activeQuestions[currentQuestionIndex].codeFlowMap}
                        semanticHighlights={activeQuestions[currentQuestionIndex].semanticHighlights}
                      />
                    )}

                    {/* ADAPTIVE COMPONENT: Audio Tip for Auditory Learners */}
                    {activeQuestions[currentQuestionIndex].audioTip && (
                      <div className="mt-3.5 p-3.5 rounded-2xl bg-[#71277a]/10 dark:bg-[#71277a]/20 border border-[#71277a]/30 text-[#71277a] dark:text-purple-300 text-xs font-bold flex items-center gap-3">
                        <span className="text-xl shrink-0">🦆</span>
                        <div className="flex-1">
                          <span className="text-[10px] font-black uppercase tracking-wider block text-[#71277a] dark:text-purple-300 mb-0.5">
                            Técnica del Patito de Goma (Refuerzo Auditivo)
                          </span>
                          <span className="text-[#00324D] dark:text-slate-200 font-medium">{activeQuestions[currentQuestionIndex].audioTip}</span>
                        </div>
                      </div>
                    )}

                    {/* ADAPTIVE COMPONENT: Doc Snippet for Read/Write Learners */}
                    {activeQuestions[currentQuestionIndex].docSnippet && (
                      <div className="mt-3.5 p-3.5 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-300/80 dark:border-amber-800 text-amber-950 dark:text-amber-200 text-xs font-medium flex items-center gap-3">
                        <span className="text-xl shrink-0">📚</span>
                        <div className="flex-1">
                          <span className="text-[10px] font-black uppercase tracking-wider block text-amber-900 dark:text-amber-300 mb-0.5">
                            Referencia Técnica Formal (Lectoescritura)
                          </span>
                          <span className="font-mono text-amber-950 dark:text-amber-200">{activeQuestions[currentQuestionIndex].docSnippet}</span>
                        </div>
                      </div>
                    )}

                    {/* ADAPTIVE COMPONENT: Logic Premise for Analytical Learners */}
                    {activeQuestions[currentQuestionIndex].logicPremise && (
                      <div className="mt-3.5 p-3.5 rounded-2xl bg-sky-50 dark:bg-sky-950/40 border border-sky-300/80 dark:border-sky-800 text-sky-950 dark:text-sky-200 text-xs font-medium flex items-center gap-3">
                        <span className="text-xl shrink-0">🧩</span>
                        <div className="flex-1">
                          <span className="text-[10px] font-black uppercase tracking-wider block text-sky-900 dark:text-sky-300 mb-0.5">
                            Premisa Lógica & Complejidad Algorítmica
                          </span>
                          <span className="text-sky-950 dark:text-sky-200 font-bold">{activeQuestions[currentQuestionIndex].logicPremise}</span>
                        </div>
                      </div>
                    )}

                    {/* ADAPTIVE COMPONENT: Pair Programming for Social Learners */}
                    {activeQuestions[currentQuestionIndex].pairProgrammingPrompt && (
                      <div className="mt-3.5 p-3.5 rounded-2xl bg-rose-50 dark:bg-rose-950/40 border border-rose-300/80 dark:border-rose-800 text-rose-950 dark:text-rose-200 text-xs font-medium flex items-center gap-3">
                        <span className="text-xl shrink-0">👥</span>
                        <div className="flex-1">
                          <span className="text-[10px] font-black uppercase tracking-wider block text-rose-900 dark:text-rose-300 mb-0.5">
                            Escenario de Equipo & Code Review
                          </span>
                          <span className="text-rose-950 dark:text-rose-200 font-medium">{activeQuestions[currentQuestionIndex].pairProgrammingPrompt}</span>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* INTERACTIVE COMPONENT 1: MULTIPLE CHOICE OPTION ARRAYS */}
                  {activeQuestions[currentQuestionIndex].type === 'multiple_choice' && (
                    <div className="space-y-3 mb-6">
                      {activeQuestions[currentQuestionIndex].options?.map((opt) => {
                        const isSelected = selectedOptionId === opt.id;
                        const isCorrectOption = isOptionDesignatedCorrect(opt, activeQuestions[currentQuestionIndex].correctOptionId);
                        const isSelectedWrong = isSelected && !isAnswerCorrect;

                        let buttonStyle = 'border-slate-200 dark:border-slate-700 hover:border-[#39a900]/40 dark:hover:border-emerald-500/50 hover:bg-[#39a900]/5 text-[#00324D] dark:text-slate-100 bg-white dark:bg-[#131F2E]';
                        let badgeStyle = 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300';

                        if (!isAnswerChecked) {
                          if (isSelected) {
                            buttonStyle = 'border-[#39a900] bg-[#39a900]/10 dark:bg-[#39a900]/20 text-[#00324D] dark:text-white font-bold ring-2 ring-[#39a900]/25';
                            badgeStyle = 'bg-[#39a900] text-white';
                          }
                        } else {
                          if (isCorrectOption) {
                            buttonStyle = 'border-[#39a900] bg-[#39a900]/15 dark:bg-[#39a900]/25 text-[#007832] dark:text-[#2EE59D] font-black ring-2 ring-[#39a900]/30 shadow-xs';
                            badgeStyle = 'bg-[#39a900] text-white';
                          } else if (isSelectedWrong) {
                            buttonStyle = 'border-rose-500 bg-rose-50 dark:bg-rose-950/40 text-rose-950 dark:text-rose-200 font-bold ring-2 ring-rose-500/20 shadow-xs';
                            badgeStyle = 'bg-rose-600 text-white';
                          } else {
                            buttonStyle = 'opacity-40 border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 text-slate-400';
                          }
                        }

                        return (
                          <button
                            key={opt.id}
                            disabled={isAnswerChecked}
                            onClick={() => { playSound('click'); setSelectedOptionId(opt.id); }}
                            className={`w-full text-left p-4 rounded-2xl border-2 transition-all flex items-center gap-4 cursor-pointer ${buttonStyle}`}
                          >
                            <div className={`w-8 h-8 rounded-xl font-black text-xs flex items-center justify-center shrink-0 transition-all ${badgeStyle}`}>
                              {opt.id}
                            </div>
                            <span className="text-xs sm:text-sm font-bold flex-1 leading-snug">{opt.text}</span>
                            {isAnswerChecked && isCorrectOption && (
                              <span className="ml-auto text-[10px] font-black uppercase text-[#007832] dark:text-[#2EE59D] bg-[#39a900]/20 dark:bg-[#39a900]/40 border border-[#39a900]/40 px-2.5 py-0.5 rounded-full shrink-0">
                                ✓ Correcta
                              </span>
                            )}
                            {isAnswerChecked && isSelectedWrong && (
                              <span className="ml-auto text-[10px] font-black uppercase text-rose-800 dark:text-rose-300 bg-rose-100 dark:bg-rose-950/60 border border-rose-300 px-2.5 py-0.5 rounded-full shrink-0">
                                ✗ Tu respuesta
                              </span>
                            )}
                          </button>
                        );
                      })}
                    </div>
                  )}

                  {/* INTERACTIVE COMPONENT 2: INTERACTIVE CODING INTERACTIVE WORKSPACE */}
                  {activeQuestions[currentQuestionIndex].type === 'coding' && (
                    <div className="space-y-4 mb-6">
                      <div className="bg-[#001724] rounded-2xl p-4 font-mono text-sm shadow-inner relative border border-slate-700">
                        <div className="flex items-center justify-between mb-3 pb-2 border-b border-slate-700/80">
                          <div className="flex items-center gap-1.5">
                            <span className="w-3 h-3 rounded-full bg-rose-500" />
                            <span className="w-3 h-3 rounded-full bg-[#fdc300]" />
                            <span className="w-3 h-3 rounded-full bg-[#39a900]" />
                            <span className="text-xs text-slate-400 font-bold ml-2">editor.js — Nodo Code Playground</span>
                          </div>

                          <div className="text-[10px] text-white uppercase tracking-wider font-black flex items-center gap-1 bg-[#007832] py-1 px-2.5 rounded-lg">
                            <Code className="w-3 h-3 text-[#fdc300]" />
                            <span>JavaScript v2026</span>
                          </div>
                        </div>

                        <div className="text-slate-400 text-xs mb-2">
                          // Escribe la implementación de tu función en JavaScript:<br/>
                          // Nodo evaluará cada caso de prueba unitario en tiempo real.
                        </div>

                        <textarea
                          disabled={isAnswerChecked}
                          value={codingAnswer}
                          onChange={(e) => setCodingAnswer(e.target.value)}
                          rows={6}
                          className="w-full bg-transparent font-mono text-[#2EE59D] focus:outline-none focus:ring-0 text-sm leading-relaxed tracking-wide resize-y"
                          placeholder="function miFuncion() { ... }"
                        />
                      </div>

                      {/* Test Cases checklist status */}
                      {testResults.length > 0 && (
                        <div className="p-4 bg-slate-100 dark:bg-[#131F2E] rounded-2xl border border-slate-200 dark:border-slate-800">
                          <h5 className="text-xs font-black uppercase text-[#00324D] dark:text-white tracking-wider mb-2">
                            Resultado de Pruebas Unitarias:
                          </h5>
                          <div className="space-y-2">
                            {testResults.map((tr, index) => (
                              <div key={tr.id || index} className="flex items-center justify-between text-xs font-bold bg-white dark:bg-slate-800 p-2.5 rounded-xl border border-slate-200 dark:border-slate-700">
                                <div className="flex items-center gap-2">
                                  <span className={`w-2.5 h-2.5 rounded-full ${tr.passed ? 'bg-[#39a900]' : 'bg-red-500'}`} />
                                  <span className="text-[#00324D] dark:text-slate-200">Prueba #{index + 1}: <code className="bg-slate-100 dark:bg-slate-900 px-1 rounded text-emerald-600 dark:text-emerald-400">{tr.input}</code></span>
                                </div>
                                <div className="flex gap-2 text-xs">
                                  <span className="text-slate-400">Obtenido: <strong className={tr.passed ? 'text-[#007832] dark:text-[#2EE59D]' : 'text-red-600'}>{tr.got}</strong></span>
                                  <span className="text-slate-300 dark:text-slate-600">|</span>
                                  <span className="text-slate-400">Esperado: <strong>{tr.expected}</strong></span>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  )}

                  {/* INTERACTIVE COMPONENT 3: KINESTHETIC PARSONS REORDER PROBLEM */}
                  {activeQuestions[currentQuestionIndex].type === 'parsons' && (
                    <div className="mb-6">
                      <ParsonsExercise
                        initialBlocks={activeQuestions[currentQuestionIndex].parsonsBlocks || []}
                        solutionOrder={activeQuestions[currentQuestionIndex].parsonsSolutionOrder || activeQuestions[currentQuestionIndex].correctOrder || []}
                        onOrderChange={(ids) => setParsonsOrder(ids)}
                        isCompleted={isAnswerChecked && isAnswerCorrect}
                      />
                    </div>
                  )}

                  {/* INTERACTIVE COMPONENT 4: LOGIC STEP-BY-STEP & BUG DETECTOR */}
                  {activeQuestions[currentQuestionIndex].type === 'logic_analysis' && (
                    <div className="mb-6">
                      <LogicAnalysisExercise
                        codeLines={activeQuestions[currentQuestionIndex].codeLines || []}
                        bugLineNumber={activeQuestions[currentQuestionIndex].bugLineNumber ?? activeQuestions[currentQuestionIndex].bugLine ?? 1}
                        bugExplanation={activeQuestions[currentQuestionIndex].bugExplanation || activeQuestions[currentQuestionIndex].explanation}
                        variableTrace={activeQuestions[currentQuestionIndex].variableTrace}
                        selectedLine={selectedBugLine}
                        onSelectLine={(line) => setSelectedBugLine(line)}
                        isAnswerChecked={isAnswerChecked}
                        isCorrect={isAnswerCorrect}
                      />
                    </div>
                  )}

                  {/* EXPLANATION & ACCURACY FEEDBACK BANNER */}
                  {isAnswerChecked && (
                    <div className={`p-4 sm:p-5 rounded-2xl border-2 mb-6 duration-200 ${
                      isAnswerCorrect 
                        ? 'bg-[#39a900]/10 dark:bg-[#39a900]/20 border-[#39a900]/40 text-[#00324D] dark:text-white' 
                        : 'bg-rose-50 dark:bg-rose-950/40 border-rose-300 dark:border-rose-800 text-rose-950 dark:text-rose-200'
                    }`}>
                      <div className="flex items-start gap-3.5">
                        <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 text-base font-black ${
                          isAnswerCorrect ? 'bg-[#39a900] text-white shadow-xs' : 'bg-rose-600 text-white shadow-xs'
                        }`}>
                          {isAnswerCorrect ? '✓' : '✗'}
                        </div>
                        <div className="flex-1 space-y-2">
                          <h4 className="font-black text-sm uppercase tracking-wide flex items-center gap-2">
                            {isAnswerCorrect ? '¡Excelente! Respuesta correcta validada' : 'Respuesta Incorrecta'}
                          </h4>

                          {!isAnswerCorrect && activeQuestions[currentQuestionIndex].type === 'multiple_choice' && (
                            <div className="text-xs sm:text-sm bg-white dark:bg-slate-800 p-3 rounded-xl border border-rose-200 dark:border-rose-900 text-rose-900 dark:text-rose-200 shadow-xs">
                              <span className="font-black text-rose-950 dark:text-rose-300 block text-[11px] uppercase tracking-wider mb-0.5">
                                La opción correcta es:
                              </span>
                              <span className="font-bold text-[#00324D] dark:text-white">
                                {activeQuestions[currentQuestionIndex].correctOptionId}) {
                                  activeQuestions[currentQuestionIndex].options?.find(o => o.id === activeQuestions[currentQuestionIndex].correctOptionId)?.text
                                }
                              </span>
                            </div>
                          )}

                          <div className="text-xs sm:text-sm leading-relaxed text-slate-700 dark:text-slate-300 bg-white dark:bg-slate-800 p-3 rounded-xl border border-slate-200 dark:border-slate-700">
                            <strong className="text-[#007832] dark:text-[#2EE59D] font-black block text-[11px] uppercase tracking-wider mb-0.5">
                              ¿Por qué? Explicación detallada:
                            </strong>
                            <span className="font-medium">{activeQuestions[currentQuestionIndex].explanation}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  {progressSaveError && (
                    <div className="mb-4 p-3.5 rounded-2xl bg-red-50 dark:bg-red-950/60 border border-red-200 dark:border-red-800 text-red-700 dark:text-red-300 text-xs font-bold">
                      ⚠️ {progressSaveError}
                    </div>
                  )}

                  {/* ACTION FOOTER BAR WITH NODO BUTTONS */}
                  <div className="mt-auto pt-6 border-t-2 border-slate-100 dark:border-slate-800 flex justify-between items-center gap-4">
                    {!isAnswerChecked ? (
                      <>
                        <button 
                          onClick={handleUseHint}
                          className="px-4 sm:px-6 py-3 rounded-2xl border-2 border-emerald-400 bg-emerald-50/90 dark:bg-emerald-950/40 hover:bg-emerald-100 dark:hover:bg-emerald-950/80 font-black text-xs sm:text-sm text-[#00283d] dark:text-emerald-300 hover:border-emerald-500 uppercase tracking-wider transition flex items-center gap-2.5 group shadow-2xs cursor-pointer"
                          title="Despliega el menú de Nodo Bot en la izquierda para explicar el ejercicio y responder dudas"
                        >
                          <div className="w-6 h-6 flex items-center justify-center group-hover:scale-110 transition-transform">
                            <NodoTutorAvatar size="xs" emotion="happy" showHoloTablet={false} />
                          </div>
                          <span>Pista & Tutor Nodo</span>
                          <span className="hidden sm:inline bg-[#2EE59D] text-[#00283d] text-[9px] px-1.5 py-0.5 rounded-full font-black">
                            Interactivo
                          </span>
                        </button>
                        
                        <button 
                          onClick={handleCheckAnswer}
                          disabled={
                            (activeQuestions[currentQuestionIndex].type === 'multiple_choice' && !selectedOptionId) ||
                            (activeQuestions[currentQuestionIndex].type === 'coding' && !codingAnswer.trim()) ||
                            (activeQuestions[currentQuestionIndex].type === 'parsons' && parsonsOrder.length === 0) ||
                            (activeQuestions[currentQuestionIndex].type === 'logic_analysis' && selectedBugLine === null)
                          }
                          className="px-8 sm:px-12 py-3.5 rounded-2xl bg-[#39a900] hover:bg-[#329600] border-b-4 border-[#007832] font-black text-xs sm:text-sm text-white uppercase tracking-wider shadow-sm transition active:translate-y-0.5 active:border-b-2 disabled:opacity-40 disabled:pointer-events-none cursor-pointer"
                        >
                          Comprobar Desafío
                        </button>
                      </>
                    ) : (
                      <div className="w-full flex items-center justify-between gap-4">
                        <div className="flex items-center gap-3">
                          <span className={`text-lg ${isAnswerCorrect ? 'text-[#007832] dark:text-[#2EE59D]' : 'text-red-600'}`}>
                            {isAnswerCorrect ? '✨ ' : '❌ '}
                          </span>
                          <span className={`font-black text-xs uppercase tracking-wider ${isAnswerCorrect ? 'text-[#007832] dark:text-[#2EE59D]' : 'text-red-600'}`}>
                            {isAnswerCorrect ? '¡Bien logrado!' : 'Inténtalo de nuevo'}
                          </span>
                          <button
                            onClick={() => { playSound('click'); setIsTutorOpen(true); }}
                            className="text-xs font-bold text-[#007832] dark:text-[#2EE59D] hover:underline flex items-center gap-1 cursor-pointer bg-emerald-50 dark:bg-emerald-950/50 px-2.5 py-1 rounded-lg border border-emerald-200 dark:border-emerald-800"
                            title="Preguntarle al Tutor IA más detalles sobre este reto"
                          >
                            <span>🤖 Preguntar al Tutor</span>
                          </button>
                        </div>

                        <button 
                          onClick={handleNextQuestion}
                          disabled={progressSaving}
                          className="px-8 sm:px-10 py-3.5 rounded-2xl bg-[#39a900] hover:bg-[#329600] border-b-4 border-[#007832] font-black text-xs sm:text-sm text-white uppercase tracking-wider shadow-sm transition active:translate-y-0.5 active:border-b-2 disabled:opacity-50 disabled:pointer-events-none cursor-pointer"
                        >
                          {progressSaving
                            ? 'Guardando Progreso...'
                            : currentQuestionIndex < activeQuestions.length - 1
                              ? 'Siguiente Desafío'
                              : 'Finalizar Lección'}
                        </button>
                      </div>
                    )}
                  </div>

                </div>
              ) : (
                <div className="flex-1 flex items-center justify-center p-8 text-slate-400 font-bold">
                  Ocurrió un error cargando las preguntas del módulo. Regresa para reintentar.
                </div>
              )}
              
            </div>
          </main>
        ) : moduleFinished ? (
          /* MODULE FINISHED SUMMARY BOARD */
          <main className="flex-1 max-w-2xl mx-auto w-full p-4 sm:p-6 flex flex-col items-center justify-center">
            <div className="bg-white dark:bg-[#0F172A] rounded-3xl border-2 border-slate-200 dark:border-slate-800 p-8 flex flex-col items-center justify-center text-center shadow-xs w-full transition-colors">
              {/* Trophy with Amarillo #fdc300 */}
              <div className="w-24 h-24 bg-[#fdc300] text-[#00324D] rounded-3xl flex items-center justify-center text-4xl mb-6 shadow-md border-4 border-white dark:border-slate-800">
                🏆
              </div>

              <div className="space-y-2 mb-6 max-w-lg">
                <h1 className="text-3xl font-black text-[#00324D] dark:text-white">¡Lección Finalizada!</h1>
                <p className="text-slate-500 dark:text-slate-400 font-bold">Has validado tus habilidades en la consola interactiva de Nodo.</p>
              </div>

              {/* Score breakdown stats */}
              <div className="grid grid-cols-3 gap-4 my-6 w-full max-w-md">
                <div className="p-4 bg-[#39a900]/10 dark:bg-[#39a900]/20 border-2 border-[#39a900]/30 rounded-2xl">
                  <span className="block text-[#007832] dark:text-[#2EE59D] font-black text-[10px] uppercase">Aciertos</span>
                  <span className="text-xl font-black text-[#00324D] dark:text-white tabular-nums">{rightAnswersCount} / {activeQuestions.length}</span>
                </div>
                
                <div className="p-4 bg-[#fdc300]/15 dark:bg-[#fdc300]/25 border-2 border-[#fdc300]/40 rounded-2xl">
                  <span className="block text-[#00324D] dark:text-amber-200 font-black text-[10px] uppercase">XP Ganado</span>
                  <span className="text-xl font-black text-[#00324D] dark:text-white tabular-nums">+{gainedXPThisSession} XP</span>
                </div>

                <div className="p-4 bg-[#007832]/10 dark:bg-[#007832]/20 border-2 border-[#007832]/30 rounded-2xl">
                  <span className="block text-[#007832] dark:text-[#2EE59D] font-black text-[10px] uppercase">Bits</span>
                  <span className="text-xl font-black text-[#007832] dark:text-[#2EE59D] tabular-nums">+{sessionBitsGained} 💻</span>
                </div>
              </div>

              <div className="w-full max-w-md mb-8">
                <SenaHelper mood="victory" text="¡Soberbio desempeño! He sumado el XP y los Bits de computación a tu terminal digital 🔥. Sigue practicando a diario para escalar en la tabla de líderes." />
              </div>

              <div className="flex gap-4 w-full max-w-md">
                <button 
                  onClick={() => { playSound('click'); setModuleFinished(false); setActiveModule(null); setActiveRoadmapNode(null); }}
                  className="flex-1 py-4 bg-[#39a900] border-b-4 border-[#007832] hover:bg-[#329600] text-white font-black uppercase tracking-wider rounded-2xl shadow-sm transition active:translate-y-0.5 active:border-b-2 cursor-pointer"
                >
                  Volver al Panel
                </button>
              </div>
            </div>
          </main>
        ) : (
          /* UNCLUTTERED, ERGONOMIC APP LAYOUT WITH LATERAL SIDEBAR */
          <div className="flex-1 flex w-full h-[calc(100vh-0px)] overflow-hidden bg-[#F4F6F9] dark:bg-[#070D14] relative">
            
            {/* BACKDROP FOR MOBILE SIDEBAR */}
            {isMobileSidebarOpen && (
              <div 
                onClick={() => setIsMobileSidebarOpen(false)}
                className="fixed inset-0 bg-black/60 backdrop-blur-xs z-40 lg:hidden"
              />
            )}

            {/* 1. PERSISTENT LATERAL SIDEBAR (DESKTOP + MOBILE DRAWER) */}
            <aside className={`
              fixed lg:static top-0 bottom-0 left-0 z-50 lg:z-10
              w-72 bg-white dark:bg-[#0B131E] border-r-2 border-slate-200 dark:border-slate-800
              flex flex-col justify-between shrink-0 select-none transition-transform duration-300 ease-in-out
              ${isMobileSidebarOpen ? 'translate-x-0 shadow-2xl' : '-translate-x-full lg:translate-x-0'}
            `}>
              {/* TOP: LOGO & USER PROFILE CAPSULE */}
              <div className="p-5 flex flex-col gap-4 border-b border-slate-100 dark:border-slate-800/80">
                <div className="flex items-center justify-between">
                  <div 
                    onClick={() => { playSound('click'); setActiveModule(null); setView('app'); setIsMobileSidebarOpen(false); }}
                    className="cursor-pointer"
                  >
                    <NodoLogo size="sm" theme={darkMode ? 'dark' : 'light'} showTagline={false} />
                  </div>
                  {/* Close button on mobile */}
                  <button 
                    onClick={() => setIsMobileSidebarOpen(false)}
                    className="p-1.5 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 lg:hidden text-slate-400"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                {/* USER STATUS CAPSULE */}
                <div className="bg-slate-50 dark:bg-[#131F2E] border border-slate-200/80 dark:border-slate-800 p-3 rounded-2xl flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-[#00324D] to-[#007832] dark:from-[#39a900] dark:to-[#2EE59D] text-white font-black text-xs flex items-center justify-center uppercase shadow-xs shrink-0 ring-2 ring-[#39a900]/30">
                    {profile.username.slice(0, 2)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <p className="text-xs font-black text-[#00324D] dark:text-white truncate">
                        {profile.username}
                      </p>
                      <span className="text-[10px] font-black bg-[#39a900]/15 dark:bg-[#39a900]/30 text-[#007832] dark:text-[#2EE59D] px-1.5 py-0.5 rounded-md">
                        Nv. {profile.level}
                      </span>
                    </div>
                    {/* Compact XP bar */}
                    <div className="mt-1.5">
                      <div className="w-full h-1.5 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-gradient-to-r from-[#39a900] to-[#2EE59D] rounded-full transition-all"
                          style={{ width: `${Math.min((profile.totalXP / (profile.level * 150)) * 100, 100)}%` }}
                        />
                      </div>
                      <div className="flex justify-between text-[9px] font-bold text-slate-400 mt-0.5">
                        <span>XP {profile.totalXP}</span>
                        <span>{profile.level * 150}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* CENTER: NAVIGATION TABS */}
              <div className="flex-1 p-4 flex flex-col gap-1.5 overflow-y-auto">
                <span className="text-[10px] font-black uppercase tracking-wider text-slate-400 dark:text-slate-500 px-3 py-1">
                  Navegación
                </span>

                <button
                  onClick={() => { playSound('click'); setActiveTab('aprender'); setIsMobileSidebarOpen(false); }}
                  className={`w-full flex items-center gap-3 px-3.5 py-3 rounded-2xl font-black text-xs uppercase tracking-wider transition cursor-pointer ${
                    activeTab === 'aprender'
                      ? 'bg-[#39a900] text-white shadow-sm'
                      : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800/80 hover:text-[#00324D] dark:hover:text-white'
                  }`}
                >
                  <Map className="w-4 h-4 shrink-0" />
                  <span className="flex-1 text-left">Sendero de Niveles</span>
                  {activeTab === 'aprender' && <span className="w-2 h-2 rounded-full bg-white animate-pulse" />}
                </button>

                <button
                  onClick={() => { playSound('click'); setActiveTab('practica'); setIsMobileSidebarOpen(false); }}
                  className={`w-full flex items-center gap-3 px-3.5 py-3 rounded-2xl font-black text-xs uppercase tracking-wider transition cursor-pointer ${
                    activeTab === 'practica'
                      ? 'bg-[#71277a] text-white shadow-sm'
                      : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800/80 hover:text-[#71277a] dark:hover:text-purple-300'
                  }`}
                >
                  <Sparkles className="w-4 h-4 shrink-0" />
                  <span className="flex-1 text-left">Práctica IA</span>
                  <span className="text-[9px] bg-[#fdc300] text-[#00324D] font-black px-1.5 py-0.5 rounded-md">IA</span>
                </button>

                <button
                  onClick={() => { playSound('click'); setActiveTab('lideres'); setIsMobileSidebarOpen(false); }}
                  className={`w-full flex items-center gap-3 px-3.5 py-3 rounded-2xl font-black text-xs uppercase tracking-wider transition cursor-pointer ${
                    activeTab === 'lideres'
                      ? 'bg-[#fdc300] text-[#00324D] shadow-sm'
                      : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800/80 hover:text-[#00324D] dark:hover:text-white'
                  }`}
                >
                  <Trophy className="w-4 h-4 shrink-0" />
                  <span className="flex-1 text-left">Tabla de Líderes</span>
                </button>

                <div className="my-2 border-t border-slate-100 dark:border-slate-800" />

                <span className="text-[10px] font-black uppercase tracking-wider text-slate-400 dark:text-slate-500 px-3 py-1">
                  Herramientas Pedagógicas
                </span>

                <button
                  onClick={() => { playSound('click'); setActiveModule(null); setView('learning-style'); setIsMobileSidebarOpen(false); }}
                  className="w-full flex items-center gap-3 px-3.5 py-2.5 rounded-2xl font-black text-xs uppercase tracking-wider transition text-slate-600 dark:text-slate-400 hover:bg-emerald-50 dark:hover:bg-emerald-950/30 hover:text-[#007832] dark:hover:text-[#2EE59D] cursor-pointer"
                >
                  <Brain className="w-4 h-4 shrink-0 text-[#007832] dark:text-[#2EE59D]" />
                  <span className="flex-1 text-left">Test Cognitivo</span>
                  <span className="text-xs">{learningStyleResult?.primaryStyle.icon || '🧠'}</span>
                </button>

                <button
                  onClick={() => {
                    playSound('click');
                    if (activeModule) {
                      setIsTutorOpen(true);
                    } else {
                      handleStartModule(STATIC_MODULES[0], false);
                      setIsTutorOpen(true);
                    }
                    setIsMobileSidebarOpen(false);
                  }}
                  className="w-full flex items-center gap-3 px-3.5 py-2.5 rounded-2xl font-black text-xs uppercase tracking-wider transition text-slate-600 dark:text-slate-400 hover:bg-cyan-50 dark:hover:bg-cyan-950/30 hover:text-cyan-600 dark:hover:text-cyan-400 cursor-pointer"
                >
                  <Bot className="w-4 h-4 shrink-0 text-cyan-500" />
                  <span className="flex-1 text-left">Tutor Nodo Bot</span>
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                </button>
              </div>

              {/* BOTTOM: THEME TOGGLE & LOGOUT */}
              <div className="p-4 border-t border-slate-100 dark:border-slate-800 flex flex-col gap-2">
                <button
                  onClick={() => { playSound('click'); setDarkMode(!darkMode); }}
                  className="w-full flex items-center justify-between px-3.5 py-2 rounded-xl text-xs font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
                >
                  <span className="flex items-center gap-2">
                    {darkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-[#00324D]" />}
                    <span>{darkMode ? 'Modo Claro' : 'Modo Oscuro'}</span>
                  </span>
                  <span className="text-[10px] text-slate-400 uppercase font-black">{darkMode ? 'Oscuro' : 'Claro'}</span>
                </button>

                <button
                  onClick={handleLogout}
                  className="w-full flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold text-slate-500 dark:text-slate-400 hover:text-red-600 dark:hover:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/30 transition cursor-pointer"
                >
                  <LogOut className="w-4 h-4" />
                  <span>Cerrar Sesión</span>
                </button>
              </div>
            </aside>

            {/* 2. MAIN WORKSPACE COLUMN */}
            <div className="flex-1 flex flex-col min-w-0 h-full overflow-hidden">
              
              {/* SLIM TOP CONTROL BAR */}
              <header className="h-16 shrink-0 bg-white/95 dark:bg-[#0B131E]/95 border-b-2 border-slate-200 dark:border-slate-800 px-4 sm:px-6 flex items-center justify-between gap-3 z-10">
                {/* Left: Mobile hamburger + Area Switcher pills */}
                <div className="flex items-center gap-2 sm:gap-3 overflow-x-auto py-1">
                  {/* Hamburger toggle for mobile */}
                  <button
                    onClick={() => setIsMobileSidebarOpen(true)}
                    className="p-2 rounded-xl border border-slate-200 dark:border-slate-700 lg:hidden text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 shrink-0 cursor-pointer"
                    aria-label="Abrir menú lateral"
                  >
                    <Menu className="w-5 h-5" />
                  </button>

                  {/* Area Switcher Pills in topbar */}
                  <div className="flex items-center gap-1.5 p-1 bg-slate-100 dark:bg-[#131F2E] rounded-2xl border border-slate-200/80 dark:border-slate-800 shrink-0">
                    {[
                      { id: 'python', label: 'Python', icon: '🐍' },
                      { id: 'javascript', label: 'JavaScript', icon: '⚡' },
                      { id: 'logica', label: 'Lógica', icon: '🤖' },
                      { id: 'algoritmos', label: 'Algoritmos', icon: '🧠' },
                      { id: 'basesdatos', label: 'Bases de Datos', icon: '🗄️' },
                    ].map(area => (
                      <button
                        key={area.id}
                        onClick={() => {
                          playSound('click');
                          setRoadmapModuleId(area.id);
                        }}
                        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-black transition cursor-pointer whitespace-nowrap ${
                          roadmapModuleId === area.id
                            ? 'bg-white dark:bg-[#0284c7] text-[#00324D] dark:text-white shadow-xs font-black ring-1 ring-slate-200 dark:ring-sky-400'
                            : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                        }`}
                      >
                        <span className="text-sm">{area.icon}</span>
                        <span className="hidden sm:inline">{area.label}</span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Right: Streak, Bits, View Toggle, Right Panel Toggle */}
                <div className="flex items-center gap-2 shrink-0">
                  {/* Streak */}
                  <div 
                    className="flex items-center gap-1.5 bg-amber-500/10 dark:bg-amber-500/20 text-amber-600 dark:text-amber-400 font-black text-xs px-3 py-1.5 rounded-xl border border-amber-500/30"
                    title="Racha de días de estudio continuo"
                  >
                    <Flame className="w-3.5 h-3.5 fill-amber-500 text-amber-500 animate-bounce" />
                    <span>{profile.streak} <span className="hidden md:inline">DÍAS</span></span>
                  </div>

                  {/* Bits */}
                  <div 
                    className="flex items-center gap-1.5 bg-[#39a900]/10 dark:bg-[#39a900]/20 text-[#007832] dark:text-[#2EE59D] font-black text-xs px-3 py-1.5 rounded-xl border border-[#39a900]/30"
                    title="Bits de computación ganados"
                  >
                    <span className="text-sm">💻</span>
                    <span>{profile.tokens} <span className="hidden md:inline">BITS</span></span>
                  </div>

                  {/* View switcher (only on 'aprender' tab) */}
                  {activeTab === 'aprender' && (
                    <div className="hidden sm:flex items-center p-0.5 bg-slate-100 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700">
                      <button
                        onClick={() => { playSound('click'); setRoadmapViewMode('roadmap'); }}
                        className={`p-1.5 rounded-lg transition cursor-pointer ${
                          roadmapViewMode === 'roadmap'
                            ? 'bg-white dark:bg-slate-700 text-[#007832] dark:text-[#2EE59D] shadow-xs'
                            : 'text-slate-400 hover:text-slate-600'
                        }`}
                        title="Ver Sendero de Niveles"
                      >
                        <Map className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => { playSound('click'); setRoadmapViewMode('grid'); }}
                        className={`p-1.5 rounded-lg transition cursor-pointer ${
                          roadmapViewMode === 'grid'
                            ? 'bg-white dark:bg-slate-700 text-[#007832] dark:text-[#2EE59D] shadow-xs'
                            : 'text-slate-400 hover:text-slate-600'
                        }`}
                        title="Ver Cuadrícula de Módulos"
                      >
                        <LayoutGrid className="w-4 h-4" />
                      </button>
                    </div>
                  )}

                  {/* Right Panel Toggle Button */}
                  <button
                    onClick={() => { playSound('click'); setShowRightPanel(!showRightPanel); }}
                    className={`p-2 rounded-xl border transition cursor-pointer ${
                      showRightPanel
                        ? 'border-slate-300 dark:border-slate-700 bg-slate-100 dark:bg-slate-800 text-[#00324D] dark:text-white'
                        : 'border-slate-200 dark:border-slate-800 text-slate-400 hover:text-slate-600'
                    }`}
                    title={showRightPanel ? "Ocultar panel lateral derecho" : "Mostrar panel lateral derecho"}
                  >
                    {showRightPanel ? <PanelRightClose className="w-4 h-4" /> : <PanelRightOpen className="w-4 h-4" />}
                  </button>
                </div>
              </header>

              {/* SCROLLABLE WORKSPACE & OPTIONAL RIGHT PANEL */}
              <div className="flex-1 flex overflow-hidden">
                
                {/* CENTER SCROLLABLE CANVAS (Sendero / Práctica / Líderes) */}
                <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 flex flex-col items-center">
                  <div className="w-full max-w-4xl">
                    
                    {/* TAB 1: APRENDER */}
                    {activeTab === 'aprender' && (
                      roadmapViewMode === 'roadmap' ? (
                        (() => {
                          const baseMap = roadmapsData[roadmapModuleId] || STATIC_ROADMAPS[roadmapModuleId] || STATIC_ROADMAPS.python;
                          const sourceLevels = (baseMap.levels && baseMap.levels.length > 0)
                            ? baseMap.levels
                            : (baseMap.roadmap?.nodes || []);
                          const roadmapProgMap = profile.roadmapProgress || {};
                          const hydratedLevels: RoadmapNode[] = sourceLevels.map((lvl, idx) => {
                            const orderIndex = idx + 1;
                            const isChest = lvl.type === 'chest' || lvl.nodeType === 'chest_reward';
                            const prog = roadmapProgMap[lvl.id];
                            const isClaimed = Boolean(claimedRoadmapNodes[lvl.id]);
                            const isCompleted = isChest ? isClaimed : Boolean(prog?.completed);
                            const stars = isChest ? 0 : (prog?.stars ?? 0);

                            let isLocked = false;
                            if (orderIndex > 3) {
                              const prevNonChest = sourceLevels
                                .slice(0, idx)
                                .reverse()
                                .find(prev => prev.type !== 'chest' && prev.nodeType !== 'chest_reward');
                              if (prevNonChest) {
                                isLocked = !Boolean(roadmapProgMap[prevNonChest.id]?.completed);
                              }
                            }

                            return {
                              ...lvl,
                              isLocked,
                              isCompleted,
                              isClaimed,
                              stars
                            };
                          });

                          const hydratedRoadmap: ModuleRoadmap = {
                            ...baseMap,
                            levels: hydratedLevels,
                            roadmap: {
                              sectionTitle: baseMap.unitTitle || baseMap.roadmap?.sectionTitle || 'Unidad de Aprendizaje',
                              nodes: hydratedLevels
                            }
                          };

                          return (
                            <PathRoadmap
                              roadmapData={hydratedRoadmap}
                              activeModuleId={roadmapModuleId}
                              hideModuleTabs={true}
                              onSelectModule={(modId) => {
                                playSound('click');
                                setRoadmapModuleId(modId);
                              }}
                              onStartLessonNode={handleStartRoadmapNode}
                              onClaimChest={handleClaimRoadmapChest}
                              userClaimedNodes={claimedRoadmapNodes}
                              learningStyleProfile={profile?.learningStyleProfile || learningStyleResult}
                              withAI={roadmapWithAI}
                              onToggleAI={handleToggleRoadmapAI}
                              isLoadingAI={isLoadingRoadmapAI}
                            />
                          );
                        })()
                      ) : (
                        /* GRID VIEW */
                        <div className="space-y-4">
                          <div className="flex items-center justify-between px-1 flex-wrap gap-2">
                            <h3 className="text-sm font-black text-[#00324D] dark:text-white flex items-center gap-2 flex-wrap">
                              <span>Módulos de Formación</span>
                              <span className="text-xs bg-[#39a900]/15 dark:bg-[#39a900]/30 text-[#007832] dark:text-[#2EE59D] font-black px-2.5 py-0.5 rounded-full">
                                {STATIC_MODULES.reduce((acc, m) => {
                                  const modProg = profile.progress?.[m.id];
                                  return acc + (modProg?.offline?.completed ? 1 : 0) + (modProg?.ia?.completed ? 1 : 0);
                                }, 0)} / {STATIC_MODULES.length * 2} Modalidades Completadas
                              </span>
                            </h3>
                          </div>

                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            {STATIC_MODULES.map((mod) => {
                              const modProgress = profile.progress?.[mod.id];
                              const offlineProg = modProgress?.offline;
                              const iaProg = modProgress?.ia;

                              const offlineScore = offlineProg?.score ?? 0;
                              const iaScore = iaProg?.score ?? 0;
                              const offlineCompleted = Boolean(offlineProg?.completed);
                              const iaCompleted = Boolean(iaProg?.completed);
                              const bothCompleted = offlineCompleted && iaCompleted;
                              const anyCompleted = offlineCompleted || iaCompleted;

                              return (
                                <div 
                                  key={mod.id}
                                  className="bg-white dark:bg-[#0F172A] rounded-3xl border-2 border-slate-200 dark:border-slate-800 p-5 hover:border-[#39a900] dark:hover:border-emerald-500 transition-all flex flex-col justify-between shadow-xs group"
                                >
                                  <div>
                                    <div className="flex items-start justify-between gap-3 mb-3">
                                      <div className="w-12 h-12 rounded-2xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-2xl shrink-0 group-hover:scale-105 transition-transform shadow-2xs">
                                        {mod.emoji}
                                      </div>
                                      <span className={`text-[10px] font-black uppercase tracking-wider px-2.5 py-1 rounded-full ${
                                        bothCompleted
                                          ? 'bg-[#39a900]/15 dark:bg-[#39a900]/25 text-[#007832] dark:text-[#2EE59D] border border-[#39a900]/30'
                                          : anyCompleted
                                            ? 'bg-amber-500/15 dark:bg-amber-500/25 text-amber-700 dark:text-amber-300 border border-amber-500/30'
                                            : 'bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400'
                                      }`}>
                                        {bothCompleted ? '✓ Ambas Completadas' : anyCompleted ? '1 / 2 Completada' : 'Disponible'}
                                      </span>
                                    </div>

                                    <h3 className="text-base font-black text-[#00324D] dark:text-white group-hover:text-[#007832] dark:group-hover:text-[#2EE59D] transition-colors">
                                      {mod.title}
                                    </h3>
                                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 leading-relaxed line-clamp-2">
                                      {mod.description}
                                    </p>
                                  </div>

                                  <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800/80 space-y-3">
                                    {/* Progreso independiente: Estándar (Offline) */}
                                    <div>
                                      <div className="flex justify-between items-center text-[10px] font-black uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1 gap-2">
                                        <span className="flex items-center gap-1.5">
                                          <span>📘 Estándar (Offline)</span>
                                          {offlineProg && (
                                            <span className="text-[9px] px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                                              {offlineProg.level}
                                            </span>
                                          )}
                                        </span>
                                        <span className={`tabular-nums ${offlineCompleted ? 'text-[#007832] dark:text-[#2EE59D]' : 'text-slate-600 dark:text-slate-300'}`}>
                                          {offlineCompleted ? `✓ ${offlineScore}%` : `${offlineScore}%`}
                                        </span>
                                      </div>
                                      <div className="w-full h-2 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                                        <div 
                                          className="h-full bg-[#39a900] rounded-full transition-all"
                                          style={{ width: `${offlineScore}%` }}
                                        />
                                      </div>
                                    </div>

                                    {/* Progreso independiente: Clase con IA */}
                                    <div>
                                      <div className="flex justify-between items-center text-[10px] font-black uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1 gap-2">
                                        <span className="flex items-center gap-1.5">
                                          <span>✨ Clase con IA</span>
                                          {iaProg && (
                                            <span className="text-[9px] px-1.5 py-0.5 rounded bg-[#71277a]/10 dark:bg-purple-950/50 text-[#71277a] dark:text-purple-300">
                                              {iaProg.level}
                                            </span>
                                          )}
                                        </span>
                                        <span className={`tabular-nums ${iaCompleted ? 'text-[#71277a] dark:text-purple-300' : 'text-slate-600 dark:text-slate-300'}`}>
                                          {iaCompleted ? `✓ ${iaScore}%` : `${iaScore}%`}
                                        </span>
                                      </div>
                                      <div className="w-full h-2 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                                        <div 
                                          className="h-full bg-[#71277a] dark:bg-purple-500 rounded-full transition-all"
                                          style={{ width: `${iaScore}%` }}
                                        />
                                      </div>
                                    </div>

                                    <div className="flex gap-2 pt-1">
                                      <button
                                        onClick={() => handleStartModule(mod, false)}
                                        className="flex-1 py-2.5 px-3 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-[#00324D] dark:text-slate-200 font-black text-xs uppercase tracking-wider rounded-xl transition cursor-pointer text-center border border-slate-200 dark:border-slate-700 flex items-center justify-center gap-1.5"
                                        title="Iniciar lección con preguntas oficiales preestablecidas (sin conexión a IA)"
                                      >
                                        <span>📘 Estándar (Offline)</span>
                                      </button>
                                      <button
                                        onClick={() => handleStartModule(mod, true)}
                                        className="flex-1 py-2.5 px-3 bg-[#71277a] hover:bg-[#52185a] text-white font-black text-xs uppercase tracking-wider rounded-xl shadow-xs transition flex items-center justify-center gap-1.5 cursor-pointer active:translate-y-0.5 border-b-2 border-[#3d1243]"
                                        title="Generar preguntas dinámicas adaptadas con Inteligencia Artificial"
                                      >
                                        <Sparkles className="w-3.5 h-3.5 text-[#fdc300]" />
                                        <span>Clase con IA</span>
                                      </button>
                                    </div>
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        </div>
                      )
                    )}

                    {/* TAB 2: PRÁCTICA IA */}
                    {activeTab === 'practica' && (
                      <div className="bg-white dark:bg-[#0F172A] rounded-3xl border-2 border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-xs space-y-6 transition-colors">
                        <div className="max-w-xl space-y-3">
                          <div className="w-12 h-12 bg-[#71277a]/15 text-[#71277a] dark:text-purple-400 rounded-2xl flex items-center justify-center text-2xl shadow-inner border border-[#71277a]/30">
                            🤖
                          </div>
                          <h2 className="text-2xl font-black text-[#00324D] dark:text-white">Profesor Inteligente Nodo IA Adaptativo</h2>
                          <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed font-medium">
                            El Profesor IA adapta automáticamente cada reto, diagrama interactivo, formato y código a la forma exacta en que tu mente retiene mejor la programación.
                          </p>
                        </div>

                        {/* Active Cognitive Style Info */}
                        <div className="p-4 bg-[#39a900]/10 dark:bg-[#39a900]/20 border-2 border-[#39a900]/30 rounded-2xl text-xs flex items-start gap-3.5">
                          <span className="text-2xl shrink-0 p-2 bg-white dark:bg-slate-800 rounded-xl shadow-2xs border border-[#39a900]/30">
                            {learningStyleResult?.primaryStyle.icon || '⚡'}
                          </span>
                          <div>
                            <span className="font-black text-[#007832] dark:text-[#2EE59D] uppercase tracking-wider block text-[10px]">
                              PERFIL COGNITIVO ACTIVO
                            </span>
                            <p className="font-bold text-[#00324D] dark:text-white mt-0.5 text-sm">
                              Estilo principal: <strong className="text-[#007832] dark:text-[#2EE59D]">{learningStyleResult?.primaryStyle.name || 'Práctico / Kinestésico'}</strong> ({learningStyleResult?.primaryStyle.percentage || 85}%)
                            </p>
                            <p className="text-slate-500 dark:text-slate-400 font-medium mt-1">
                              {learningStyleResult?.primaryStyle.type === 'visual'
                                ? '🎨 El Profesor genera diagramas de flujo y esquemas espaciales en cada reto.'
                                : learningStyleResult?.primaryStyle.type === 'auditivo'
                                  ? '🎧 El Profesor genera retos con técnica del patito de goma y narración por voz.'
                                  : learningStyleResult?.primaryStyle.type === 'practico'
                                    ? '⚡ El Profesor genera playgrounds con código interactivo vivo y casos unitarios.'
                                    : learningStyleResult?.primaryStyle.type === 'lectoescritor'
                                      ? '📚 El Profesor genera notas técnicas formales y referencias de especificación.'
                                      : learningStyleResult?.primaryStyle.type === 'logico'
                                        ? '🧩 El Profesor genera análisis de premisas deductivas y complejidad algorítmica.'
                                        : '👥 El Profesor genera retos de equipo y dinámicas de Code Review.'}
                            </p>
                          </div>
                        </div>

                        <div className="p-3.5 bg-[#fdc300]/15 dark:bg-[#fdc300]/25 border border-[#fdc300]/40 text-[#00324D] dark:text-amber-200 rounded-xl text-xs font-bold flex items-center gap-2">
                          <span>💡</span>
                          <span>CONSEJO NODO: Las clases con el Profesor IA otorgan bonificación extra de XP y Bits de computación.</span>
                        </div>

                        <div className="pt-2">
                          <h4 className="text-xs font-black uppercase tracking-wider text-slate-400 dark:text-slate-500 mb-3">Iniciar Sesión de Práctica Adaptada:</h4>
                          <div className="flex flex-wrap gap-3">
                            {STATIC_MODULES.map(m => (
                              <button
                                key={m.id}
                                onClick={() => handleStartModule(m, true)}
                                className="bg-[#71277a] hover:bg-[#52185a] border-b-4 border-[#3d1243] text-white font-black text-xs uppercase tracking-wider py-3 px-4 rounded-xl shadow-xs transition active:translate-y-0.5 active:border-b-2 flex items-center gap-2 cursor-pointer"
                              >
                                <Sparkles className="w-3.5 h-3.5 text-[#fdc300]" />
                                <span>{m.title}</span>
                              </button>
                            ))}
                          </div>
                        </div>
                      </div>
                    )}

                    {/* TAB 3: LÍDERES */}
                    {activeTab === 'lideres' && (
                      <div className="bg-white dark:bg-[#0F172A] rounded-3xl border-2 border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-xs space-y-6 transition-colors">
                        <div className="flex items-center justify-between flex-wrap gap-2">
                          <div>
                            <h2 className="text-xl font-black text-[#00324D] dark:text-white">Tabla de Líderes · Liga Global Nodo</h2>
                            <p className="text-xs text-slate-400 dark:text-slate-500 font-medium mt-0.5">Compite con desarrolladores y sube posiciones ganando XP diario.</p>
                          </div>
                          <span className="text-xs font-black text-[#007832] dark:text-[#2EE59D] bg-[#39a900]/15 dark:bg-[#39a900]/30 px-3 py-1 rounded-full">
                            En Tiempo Real
                          </span>
                        </div>

                        {/* Top 3 Podium */}
                        <div className="grid grid-cols-3 gap-3 pt-2">
                          {leaderboard[1] && (
                            <div className="bg-slate-50 dark:bg-[#131F2E] border-2 border-slate-200 dark:border-slate-800 rounded-2xl p-4 flex flex-col items-center text-center">
                              <span className="text-2xl mb-1">🥈</span>
                              <span className="text-xs font-black text-[#00324D] dark:text-white truncate max-w-full">{leaderboard[1].name}</span>
                              <span className="text-[11px] font-bold text-slate-400 mt-1">{leaderboard[1].xp} XP</span>
                            </div>
                          )}
                          {leaderboard[0] && (
                            <div className="bg-[#fdc300]/15 dark:bg-[#fdc300]/25 border-2 border-[#fdc300]/50 rounded-2xl p-4 flex flex-col items-center text-center shadow-xs">
                              <span className="text-3xl mb-1">👑</span>
                              <span className="text-xs font-black text-[#00324D] dark:text-amber-200 truncate max-w-full">{leaderboard[0].name}</span>
                              <span className="text-xs font-black text-[#fdc300] mt-1">{leaderboard[0].xp} XP</span>
                            </div>
                          )}
                          {leaderboard[2] && (
                            <div className="bg-slate-50 dark:bg-[#131F2E] border-2 border-slate-200 dark:border-slate-800 rounded-2xl p-4 flex flex-col items-center text-center">
                              <span className="text-2xl mb-1">🥉</span>
                              <span className="text-xs font-black text-[#00324D] dark:text-white truncate max-w-full">{leaderboard[2].name}</span>
                              <span className="text-[11px] font-bold text-slate-400 mt-1">{leaderboard[2].xp} XP</span>
                            </div>
                          )}
                        </div>
                        
                        <div className="space-y-2.5">
                          {leaderboard.map((user, idx) => (
                            <div 
                              key={idx}
                              className={`flex items-center justify-between p-3.5 rounded-2xl border-2 transition-all ${
                                user.name === 'Tú' 
                                  ? 'border-[#39a900] bg-[#39a900]/10 dark:bg-[#39a900]/20 text-[#00324D] dark:text-white font-black ring-2 ring-[#39a900]/25' 
                                  : 'border-slate-100 dark:border-slate-800 bg-[#F8FAFC] dark:bg-[#131F2E] text-[#00324D] dark:text-slate-200'
                              }`}
                            >
                              <div className="flex items-center gap-3">
                                <span className={`font-black text-sm tabular-nums w-6 ${idx === 0 ? 'text-[#fdc300]' : 'text-slate-400'}`}>
                                  #{idx + 1}
                                </span>
                                <div className={`w-8 h-8 rounded-xl ${user.avatar} flex items-center justify-center font-bold text-xs uppercase shadow-xs`}>
                                  {user.name.slice(0, 2)}
                                </div>
                                <span className="font-bold text-sm">{user.name}</span>
                              </div>
                              
                              <div className="flex items-center gap-1.5">
                                <span className="font-black text-sm text-[#007832] dark:text-[#2EE59D] tabular-nums">{user.xp}</span>
                                <span className="text-[10px] text-slate-400 font-black uppercase">XP</span>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                  </div>
                </main>

                {/* 3. OPTIONAL COLLAPSIBLE RIGHT PANEL */}
                {showRightPanel && (
                  <aside className="w-80 shrink-0 border-l-2 border-slate-200 dark:border-slate-800 bg-white/70 dark:bg-[#0B131E]/70 backdrop-blur-xs hidden xl:flex flex-col gap-4 p-5 overflow-y-auto">
                    
                    {/* WIDGET 1: RETO DIARIO */}
                    <div className="bg-white dark:bg-[#0F172A] rounded-2xl border-2 border-slate-200 dark:border-slate-800 p-4 shadow-xs">
                      <div className="flex items-center justify-between mb-2.5">
                        <h4 className="font-black text-[11px] uppercase tracking-wider text-[#00324D] dark:text-white flex items-center gap-1.5">
                          <span className="w-2 h-2 rounded-full bg-[#fdc300]" />
                          RETO DIARIO
                        </h4>
                        <span className="text-[10px] font-black uppercase text-[#fdc300] bg-[#fdc300]/15 dark:bg-[#fdc300]/25 px-2 py-0.5 rounded-full">
                          +25 💻 Bits
                        </span>
                      </div>

                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-[#fdc300] text-[#00324D] rounded-xl flex items-center justify-center text-xl shadow-xs shrink-0">
                          🏆
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-xs font-black text-[#00324D] dark:text-white">Meta: 150 XP hoy</p>
                          <div className="w-full h-2 bg-slate-100 dark:bg-slate-800 rounded-full mt-1.5 border border-slate-200 dark:border-slate-700 overflow-hidden">
                            <div 
                              className="h-full bg-[#fdc300] rounded-full transition-all"
                              style={{ width: `${Math.min((profile.totalXP / 150) * 100, 100)}%` }}
                            />
                          </div>
                          <p className="text-[9px] text-right mt-1 font-black text-[#007832] dark:text-[#2EE59D] tabular-nums">
                            {profile.totalXP} / 150 XP
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* WIDGET 2: NODO BOT - TU TUTOR PERSONAL */}
                    <div className="bg-gradient-to-tr from-[#021824] via-[#052b3d] to-[#043d4d] border-2 border-[#2EE59D]/40 rounded-2xl p-4 text-white shadow-md relative overflow-hidden">
                      <div className="flex items-start gap-3">
                        <div className="w-12 h-12 rounded-xl bg-black/30 border border-[#2EE59D]/50 p-1 flex items-center justify-center shrink-0">
                          <NodoTutorAvatar
                            size="sm"
                            emotion="happy"
                            showFloatingParticles={true}
                            isAnimated={true}
                          />
                        </div>

                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-1.5 mb-1">
                            <span className="font-black text-xs text-white">Nodo Bot</span>
                            <span className="text-[8px] bg-[#2EE59D]/20 text-[#2EE59D] border border-[#2EE59D]/40 px-1.5 py-0.5 rounded-full font-black uppercase">
                              Tutor IA
                            </span>
                          </div>
                          <p className="text-[10px] text-slate-200 leading-relaxed">
                            Acompañándote paso a paso en tu sendero formativo.
                          </p>
                        </div>
                      </div>

                      <div className="mt-3 pt-2.5 border-t border-white/10 flex items-center justify-between">
                        <span className="text-[9px] text-emerald-400 font-bold flex items-center gap-1">
                          <span className="w-1.5 h-1.5 rounded-full bg-[#2EE59D] animate-ping" />
                          Activo
                        </span>
                        <button
                          onClick={() => {
                            playSound('click');
                            if (activeModule) {
                              setIsTutorOpen(true);
                            } else {
                              handleStartModule(STATIC_MODULES[0], false);
                              setIsTutorOpen(true);
                            }
                          }}
                          className="px-2.5 py-1 bg-[#2EE59D] hover:bg-[#20ce8a] text-[#00283d] font-black text-[11px] rounded-lg shadow-xs transition cursor-pointer"
                        >
                          Abrir Tutor
                        </button>
                      </div>
                    </div>

                    {/* WIDGET 3: MI PERFIL COGNITIVO */}
                    {learningStyleResult ? (
                      <div className="bg-white dark:bg-[#0F172A] rounded-2xl border-2 border-slate-200 dark:border-slate-800 p-4 shadow-xs">
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="font-black text-[11px] uppercase tracking-wider text-[#00324D] dark:text-white flex items-center gap-1.5">
                            <Brain className="w-3.5 h-3.5 text-[#007832] dark:text-[#2EE59D]" />
                            ESTILO COGNITIVO
                          </h4>
                          <span className="text-sm">{learningStyleResult.primaryStyle.icon}</span>
                        </div>

                        {learningStyleResult.isBimodal && (
                          <span className="inline-block text-[9px] font-black uppercase tracking-wider text-cyan-600 dark:text-cyan-300 bg-cyan-50 dark:bg-cyan-950/50 px-2 py-0.5 rounded-full border border-cyan-300 dark:border-cyan-800 mb-1">
                            ✨ {learningStyleResult.bimodalTitle || 'Bimodal'}
                          </span>
                        )}

                        <p className="font-black text-xs text-[#00324D] dark:text-white">
                          {learningStyleResult.isBimodal 
                            ? `${learningStyleResult.primaryStyle.name} + ${learningStyleResult.secondaryStyle.shortName}` 
                            : learningStyleResult.primaryStyle.name}
                        </p>
                        <p className="text-[11px] text-[#007832] dark:text-[#2EE59D] font-bold">
                          Afinidad: {learningStyleResult.primaryStyle.percentage}%
                        </p>

                        <div className="grid grid-cols-2 gap-1.5 mt-3 pt-2.5 border-t border-slate-100 dark:border-slate-800">
                          <button
                            onClick={() => { playSound('click'); setActiveModule(null); setView('learning-style'); }}
                            className="py-1.5 px-2 bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 text-[#00324D] dark:text-slate-200 text-[9px] font-black uppercase rounded-lg border border-slate-200 dark:border-slate-700 cursor-pointer text-center"
                          >
                            Ver Informe
                          </button>
                          <button
                            onClick={() => { 
                              playSound('click'); 
                              setProfileSyncError('');
                              setLearningStyleResult(null); 
                              setActiveModule(null); 
                              setView('learning-style'); 
                            }}
                            className="py-1.5 px-2 bg-[#39a900] hover:bg-[#329600] text-white text-[9px] font-black uppercase rounded-lg cursor-pointer text-center"
                          >
                            Repetir
                          </button>
                        </div>
                      </div>
                    ) : (
                      <div className="bg-white dark:bg-[#0F172A] rounded-2xl border-2 border-slate-200 dark:border-slate-800 p-4 shadow-xs">
                        <h4 className="font-black text-[11px] uppercase tracking-wider text-[#00324D] dark:text-white mb-1.5 flex items-center gap-1.5">
                          <Brain className="w-3.5 h-3.5 text-[#007832] dark:text-[#2EE59D]" />
                          DIAGNÓSTICO
                        </h4>
                        <p className="text-[11px] text-slate-500 dark:text-slate-400">
                          Descubre cómo retienes mejor el código.
                        </p>
                        <button
                          onClick={() => { playSound('click'); setActiveModule(null); setView('learning-style'); }}
                          className="w-full mt-2.5 py-2 bg-[#39a900] hover:bg-[#329600] text-white text-[10px] font-black uppercase tracking-wider rounded-lg transition cursor-pointer"
                        >
                          Hacer Test
                        </button>
                      </div>
                    )}
                  </aside>
                )}

              </div>
            </div>

          </div>
        )
      )}

      {/* INTERACTIVE AI TUTOR DRAWER (Left Side Menu) */}
      {activeModule && activeQuestions[currentQuestionIndex] && (
        <TutorDrawer
          isOpen={isTutorOpen}
          onClose={() => setIsTutorOpen(false)}
          question={activeQuestions[currentQuestionIndex]}
          questionIndex={currentQuestionIndex}
          totalQuestions={activeQuestions.length}
          moduleTitle={activeModule.title}
          currentCode={codingAnswer}
          learningStyleProfile={learningStyleResult}
        />
      )}

      {/* DUOLINGO STYLE CELEBRATION MODAL WITH NODO */}
      <DuolingoCompletionModal
        isOpen={showCelebrationModal}
        onClose={() => {
          setShowCelebrationModal(false);
          setModuleFinished(false);
          setActiveModule(null);
          setActiveRoadmapNode(null);
        }}
        onReview={() => {
          setShowCelebrationModal(false);
          // Keep on the review finished board
        }}
        score={rightAnswersCount}
        totalQuestions={activeQuestions.length}
        xpEarned={gainedXPThisSession}
        bitsEarned={sessionBitsGained}
        streakDays={profile?.streakDays || 1}
        learningStyle={profile?.learningStyleProfile?.primaryStyle?.type || learningStyleResult?.primaryStyle?.type || 'visual'}
        secondaryStyle={profile?.learningStyleProfile?.secondaryStyle?.type || learningStyleResult?.secondaryStyle?.type}
        isBimodal={Boolean(profile?.learningStyleProfile?.isBimodal || learningStyleResult?.isBimodal)}
        bimodalTitle={profile?.learningStyleProfile?.bimodalTitle || learningStyleResult?.bimodalTitle}
        styleName={profile?.learningStyleProfile?.bimodalTitle || profile?.learningStyleProfile?.primaryStyle?.name || learningStyleResult?.bimodalTitle || learningStyleResult?.primaryStyle?.name || 'Visual / Espacial'}
        moduleTitle={activeModule?.title || 'Lógica de Programación'}
      />

      {/* FOOTER NODO */}
      <footer className="mt-auto py-6 border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0B131E] text-center text-xs text-slate-500 dark:text-slate-400 select-none transition-colors">
        <div className="max-w-4xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <NodoLogo size="xs" theme={darkMode ? 'dark' : 'light'} showTagline={true} />
          <div className="flex items-center gap-4 text-[11px] font-bold text-slate-500 dark:text-slate-400">
            <span>Playgrounds Interactivos</span>
            <span>·</span>
            <span>Tutor IA Nodo Bot</span>
            <span>·</span>
            <span>2026</span>
          </div>
        </div>
      </footer>

    </div>
  );
}
