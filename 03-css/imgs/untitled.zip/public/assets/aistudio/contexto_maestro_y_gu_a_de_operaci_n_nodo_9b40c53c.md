# DOCUMENTO DE CONTEXTO TÉCNICO Y ARQUITECTURA MAESTRA: PROYECTO NODO

> **Destinatario de este documento**: Asistente de Desarrollo / Agente de Código en Google AI Studio.  
> **Propósito**: Proveer el contexto arquitectónico, funcional, de dependencias y de diseño para ejecutar refactorizaciones, correcciones y extensiones sobre el código base del archivo comprimido `nodo.zip`.

---

## 1. Visión General del Producto y Propósito Funcional

**Nodo** es una plataforma educativa web interactiva y gamificada orientada al aprendizaje de programación, pensamiento computacional, algoritmos y bases de datos.

El proyecto fusiona neurodidáctica y gamificación a través de cuatro subsistemas principales:
1. **Sendero de Progresión Gamificado (Estilo Duolingo)**: Un mapa de aprendizaje vectorial interactivo con nodos interconectados (lecciones regulares, cofres de recompensas y retos de fin de unidad o *Boss Challenges*), rachas de estudio diarias (*streaks*), saldo de "Bits" y puntos de experiencia (XP).
2. **Laboratorio Cognitivo y Detección Bimodal (7 Fases)**: Un sistema de diagnóstico interactivo que mide las afinidades de aprendizaje (Visual, Auditivo, Kinestésico/Práctico, Lectoescritura, Lógico-Analítico y Social) mediante dinámicas interactivas. Detecta perfiles bimodales (especialmente **Audiovisual**) activando dinámicas adaptativas simultáneas.
3. **Tutor Inteligente "Nodo Bot" con IA Socrática**: Un asistente conversacional integrado tanto en un panel lateral interactivo (*Tutor Drawer*) como en los flujos de clase, gobernado por directivas pedagógicas socráticas que guían sin entregar la respuesta de golpe. Utiliza el SDK `@google/genai` con un motor semántico de respaldo local para más de 12 temáticas clave de código.
4. **Playgrounds y Tipologías de Reto en Vivo**:
   - `coding`: Evaluación de código del estudiante en tiempo real contrastado contra casos de prueba unitarios.
   - `multiple_choice`: Preguntas conceptuales con normalización estricta de IDs.
   - `parsons`: Ordenamiento de bloques de código desordenados (foco kinestésico).
   - `logic_analysis`: Depuración paso a paso en línea de error con seguimiento de variables en memoria (*variable trace*).

---

## 2. Stack Tecnológico y Entorno de Ejecución

### Frontend
- **React 19** (`react`, `react-dom` ^19.0.1).
- **TypeScript 5.8** con tipado centralizado en `src/types.ts`.
- **Tailwind CSS v4** con integración `@tailwindcss/vite` y paleta de tokens semánticos:
  - Verde Menta / Éxito: `#2EE59D` y `#39A900`.
  - Azul Noche Profundo / Contenedores: `#001724`, `#00283D`, `#070D14`.
  - Cian Eléctrico: `#00E5FF` y `#38BDF8`.
  - Amarillo Ámbar / Racha / Recompensas: `#FDC300` y `#F59E0B`.
- **Motion (Framer Motion v12)**: Animaciones de avatar, partículas de recompensa, modales de finalización y transiciones fluidas.
- **Lucide React**: Biblioteca de iconos vectoriales.

### Backend y Servidor
- **Node.js + Express 4.21** (`server.ts`).
- **Vite 6** en modo middleware (`createViteServer`) para servir el frontend SPA en desarrollo con HMR.
- **Esbuild / TSX**: Ejecución en tiempo de desarrollo (`npm run dev` ejecuta `tsx server.ts`) y empaquetado a `dist/server.cjs` para producción.

### Inteligencia Artificial
- **SDK `@google/genai` (v2.4.0)**:
  - Invocación con `responseSchema` estricto en JSON para generación de preguntas y senderos.
  - Generación de texto conversacional con timeouts controlados (7.5s).

### Motores Nativos del Navegador (Zero External Assets)
- **Web Audio API (`src/utils/audioEffects.ts`)**: Motor de síntesis procedural con `AudioContext` y osciladores (`sine`, `triangle`, `sawtooth`) para generar fanfarrias, alertas de errores, sonidos de cofres y niveles sin requerir archivos de audio externos.
- **Web Speech API (`SpeechSynthesis`)**: Síntesis vocal en español para narrar preguntas, consejos y soporte para el perfil auditivo.

---

## 3. Topología de Archivos Clave del Repositorio

```
nodo/
├── server.ts                             # Servidor Express, endpoints API, lógica Gemini y persistencia en memoria
├── package.json                          # Dependencias y scripts de ejecución
├── vite.config.ts                        # Configuración de Vite + Tailwind v4
├── index.html                            # Punto de entrada HTML con tipografías y metadatos
├── src/
│   ├── App.tsx                           # Orquestador principal de estado, vistas, auth y layouts
│   ├── main.tsx                          # Punto de montaje React 19
│   ├── index.css                         # Estilos globales y tokens Tailwind v4
│   ├── types.ts                          # Interfaces TS (UserProfile, Question, LearningStyle, RoadmapNode, etc.)
│   ├── data.ts                           # Módulos y banco de preguntas estáticas iniciales
│   ├── components/
│   │   ├── DiagnosticWizard.tsx          # Cuestionario inicial de nivel y disponibilidad
│   │   ├── DuolingoCompletionModal.tsx   # Modal de felicitaciones, XP, bits y racha
│   │   ├── LearningStyleAssessment.tsx   # Laboratorio cognitivo interactivo (7 fases)
│   │   ├── LogicAnalysisExercise.tsx     # Reto de análisis lógico y traza de memoria
│   │   ├── NodoLogo.tsx                  # Logotipo SVG con nodo orbital
│   │   ├── NodoTutorAvatar.tsx           # Avatar SVG interactivo del robot tutor con estados emocionales
│   │   ├── ParsonsExercise.tsx           # Dinámica de reordenamiento de bloques de código
│   │   ├── PathRoadmap.tsx               # Sendero gamificado Duolingo con trazado vectorial Bézier
│   │   ├── SenaHelper.tsx                # Globo de diálogo y asistencia rápida de Nodo Bot
│   │   ├── ThemeMascotCompanion.tsx      # Mascota temática lateral (Pythie, Voltio, Nodo, Cylo)
│   │   ├── TutorDrawer.tsx               # Drawer lateral izquierdo con chat interactivo con IA
│   │   └── VisualCodeFlow.tsx            # Componente de mapas de flujo, diagramas ASCII y colores semánticos
│   ├── data/
│   │   ├── learningStylesData.ts         # Datos de estilos de aprendizaje y preguntas de afinidad
│   │   └── roadmapsData.ts               # Senderos estáticos de los módulos (python, javascript, logica, etc.)
│   └── utils/
│       └── audioEffects.ts               # Sintetizador procedural Web Audio y Web Speech
```

---

## 4. Dinámicas y Algoritmos Cruciales del Sistema

### 4.1. Cálculo Bézier en el Sendero Gamificado (`PathRoadmap.tsx`)
Para evitar líneas quebradas en el mapa, los nodos se organizan con paso vertical $\Delta Y = 120\text{px}$ y coordenadas horizontales $X \in \{85, 180, 275\}$ según `curveOffset` $\in \{-1, 0, 1\}$.
La conexión entre nodos adyacentes $(x_1, y_1)$ y $(x_2, y_2)$ utiliza una curva cúbica con tangentes estrictamente verticales en los puntos de anclaje:
$$C(t) = (1-t)^3 \mathbf{P}_0 + 3(1-t)^2 t \mathbf{P}_1 + 3(1-t) t^2 \mathbf{P}_2 + t^3 \mathbf{P}_3$$
donde $\mathbf{P}_0 = (x_1, y_1)$, $\mathbf{P}_1 = (x_1, \text{midY})$, $\mathbf{P}_2 = (x_2, \text{midY})$ y $\mathbf{P}_3 = (x_2, y_2)$ con $\text{midY} = \frac{y_1 + y_2}{2}$.

### 4.2. Umbral de Detección Bimodal (`LearningStyleAssessment.tsx`)
Tras completar las 7 pruebas del laboratorio cognitivo, si el porcentaje visual ($P_v$) y auditivo ($P_a$) cumplen:
$$P_v \ge 18\%, \quad P_a \ge 18\%, \quad |P_v - P_a| \le 8\%$$
Se clasifica al usuario en el perfil **Bimodal Audiovisual**, activando simultáneamente en el frontend los diagramas visuales (`VisualCodeFlow.tsx`) y los disparadores de narración por voz y técnica del patito de goma.

---

## 5. Puntos Críticos a Resolver / Áreas de Refactorización

Al trabajar con este repositorio, las prioridades de mejora técnica son:
1. **Persistencia**: `server.ts` utiliza actualmente `const USERS_DB: { [email: string]: any } = {}`. Debe migrarse a almacenamiento estructurado persistente (MongoDB/Mongoose o SQLite/PostgreSQL) para evitar la pérdida de datos ante reinicios.
2. **Seguridad y Autenticación**:
   - Reemplazar la validación de contraseñas en texto plano por `bcrypt.hash` y `bcrypt.compare`.
   - Implementar tokens JWT (`jsonwebtoken`) para autenticación basada en cabeceras o cookies seguras.
   - Dejar de exponer el código OTP en la respuesta JSON `/api/auth/register` en entornos no demostrativos.
3. **Aislamiento en Playgrounds (`new Function`)**:
   - Aislar la evaluación de pruebas unitarias en un Web Worker dedicado (`codeRunner.worker.ts`) con límite de tiempo (*watchdog timer* de $1500\,\text{ms}$) para impedir que bucles infinitos (`while(true)`) congelen el hilo principal de la interfaz.
4. **Estandarización de Modelos Gemini en `server.ts`**:
   - Usar identificadores estables y vigentes del SDK (`gemini-2.5-flash`, `gemini-2.0-flash`), evitando modelos con identificadores no reconocidos que acumulen retardos por reintentos fallidos.
5. **Homologación de Esquemas TypeScript**:
   - Unificar `parsonsSolutionOrder` vs `correctOrder`.
   - Unificar `rewardBits` vs `gemsEarned`.